/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.block.BlockLeaves
 *  net.minecraft.block.properties.IProperty
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.init.Blocks
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.world.World
 */
package net.tangotek.tektopia.blockfinder;

import javax.annotation.Nullable;
import net.minecraft.block.BlockLeaves;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.tangotek.tektopia.Village;
import net.tangotek.tektopia.blockfinder.BlockScanner;

public class TreeScanner
extends BlockScanner {
    public TreeScanner(Village v, int scansPerTick) {
        super(Blocks.LOG, v, scansPerTick);
    }

    @Override
    public BlockPos testBlock(World w, BlockPos bp) {
        IBlockState blockState = w.getBlockState(bp);
        if (TreeScanner.isLeaf(blockState)) {
            return this.findTreeFromLeaf(w, bp);
        }
        return null;
    }

    @Override
    public void scanNearby(BlockPos bp) {
        for (BlockPos scanPos : BlockPos.getAllInBox((int)(bp.getX() - 7), (int)(bp.getY() + 2), (int)(bp.getZ() - 7), (int)(bp.getX() + 7), (int)(bp.getY() + 2), (int)(bp.getZ() + 7))) {
            this.scanBlock(scanPos);
        }
    }

    @Nullable
    protected BlockPos findTreeFromLeaf(World world, BlockPos leafPos) {
        for (BlockPos bp : BlockPos.getAllInBox((int)(leafPos.getX() - 2), (int)(leafPos.getY() - 1), (int)(leafPos.getZ() - 2), (int)(leafPos.getX() + 2), (int)(leafPos.getY() - 1), (int)(leafPos.getZ() + 2))) {
            BlockPos treePos = TreeScanner.treeTest(world, bp);
            if (treePos == null) continue;
            return treePos;
        }
        return null;
    }

    public static BlockPos treeTest(World world, BlockPos bp) {
        while (TreeScanner.isLog(world.getBlockState(bp))) {
            if (world.getBlockState(bp = bp.down()).getBlock() != Blocks.DIRT) continue;
            BlockPos treePos = bp.up();
            bp = bp.up(3);
            for (int i = 0; i < 9; ++i) {
                IBlockState westBlock = world.getBlockState(bp.west());
                IBlockState eastBlock = world.getBlockState(bp.east());
                if ((TreeScanner.isLeaf(westBlock) || TreeScanner.isLog(westBlock)) && (TreeScanner.isLeaf(eastBlock) || TreeScanner.isLog(eastBlock))) {
                    return treePos;
                }
                bp = bp.up();
            }
            return null;
        }
        return null;
    }

    public static boolean isLog(IBlockState blockState) {
        return blockState.getBlock() == Blocks.LOG || blockState.getBlock() == Blocks.LOG2;
    }

    public static boolean isLeaf(IBlockState blockState) {
        return (blockState.getBlock() == Blocks.LEAVES || blockState.getBlock() == Blocks.LEAVES2) && (Boolean)blockState.getValue((IProperty)BlockLeaves.DECAYABLE) != false;
    }
}

