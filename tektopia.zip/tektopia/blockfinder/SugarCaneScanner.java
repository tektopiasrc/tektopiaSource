/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.init.Blocks
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.world.World
 */
package net.tangotek.tektopia.blockfinder;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.tangotek.tektopia.Village;
import net.tangotek.tektopia.blockfinder.BlockScanner;

public class SugarCaneScanner
extends BlockScanner {
    public SugarCaneScanner(Village v, int scansPerTick) {
        super((Block)Blocks.REEDS, v, scansPerTick);
    }

    public static BlockPos getCaneStalk(World w, BlockPos bp) {
        if (SugarCaneScanner.isCane(w.getBlockState(bp))) {
            while (SugarCaneScanner.isCane(w.getBlockState(bp = bp.down()))) {
            }
            Block downBlock = w.getBlockState(bp.down()).getBlock();
            if (downBlock == Blocks.GLOWSTONE) {
                return null;
            }
            if (SugarCaneScanner.isCane(w.getBlockState(bp.up(2)))) {
                return bp.up();
            }
        }
        return null;
    }

    @Override
    public BlockPos testBlock(World w, BlockPos bp) {
        return SugarCaneScanner.getCaneStalk(w, bp);
    }

    @Override
    public void scanNearby(BlockPos bp) {
        for (BlockPos scanPos : BlockPos.getAllInBox((int)(bp.getX() - 2), (int)bp.getY(), (int)(bp.getZ() - 2), (int)(bp.getX() + 2), (int)bp.getY(), (int)(bp.getZ() + 2))) {
            this.scanBlock(scanPos);
        }
    }

    public static boolean isCane(IBlockState blockState) {
        return blockState.getBlock() == Blocks.REEDS;
    }
}

