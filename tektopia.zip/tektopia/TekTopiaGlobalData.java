/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.nbt.NBTBase
 *  net.minecraft.nbt.NBTTagCompound
 *  net.minecraft.nbt.NBTTagList
 *  net.minecraft.nbt.NBTTagString
 *  net.minecraft.world.World
 *  net.minecraft.world.storage.MapStorage
 *  net.minecraft.world.storage.WorldSavedData
 */
package net.tangotek.tektopia;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.nbt.NBTTagString;
import net.minecraft.world.World;
import net.minecraft.world.storage.MapStorage;
import net.minecraft.world.storage.WorldSavedData;

public class TekTopiaGlobalData
extends WorldSavedData {
    private static final String DATA_NAME = "tektopia_GlobalData";
    private Map<PatreonSupportTier, Set<UUID>> patreonTiers = new HashMap<PatreonSupportTier, Set<UUID>>();
    private Map<UUID, String> licenseMap = new HashMap<UUID, String>();

    public TekTopiaGlobalData() {
        super(DATA_NAME);
    }

    public TekTopiaGlobalData(String s) {
        super(s);
    }

    public static TekTopiaGlobalData get(World world) {
        MapStorage storage = world.getMapStorage();
        TekTopiaGlobalData instance = (TekTopiaGlobalData)storage.getOrLoadData(TekTopiaGlobalData.class, DATA_NAME);
        if (instance == null) {
            instance = new TekTopiaGlobalData();
            storage.setData(DATA_NAME, (WorldSavedData)instance);
        }
        return instance;
    }

    public void readFromNBT(NBTTagCompound nbt) {
        for (PatreonSupportTier tier : PatreonSupportTier.values()) {
            NBTTagList tagList = nbt.getTagList(tier.name(), 8);
            if (tagList.hasNoTags()) continue;
            HashSet<UUID> tierSet = new HashSet<UUID>();
            for (int i = 0; i < tagList.tagCount(); ++i) {
                tierSet.add(UUID.fromString(tagList.getStringTagAt(i)));
            }
            this.patreonTiers.put(tier, tierSet);
        }
    }

    public NBTTagCompound writeToNBT(NBTTagCompound compound) {
        this.patreonTiers.forEach((key, value) -> {
            NBTTagList tagList = new NBTTagList();
            value.forEach(uuid -> tagList.appendTag((NBTBase)new NBTTagString(uuid.toString())));
            compound.setTag(key.name(), (NBTBase)tagList);
        });
        return compound;
    }

    public String getPatreonLicense(UUID uuid) {
        return this.licenseMap.get(uuid);
    }

    public void submitPatreonLicense(UUID uuid, String licData) {
        this.licenseMap.put(uuid, licData);
    }

    public static enum PatreonSupportTier {
        Level1,
        Level2,
        Level3,
        Level4;

    }
}

