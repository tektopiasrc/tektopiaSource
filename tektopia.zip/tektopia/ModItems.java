/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.init.Blocks
 *  net.minecraft.init.Items
 *  net.minecraft.init.SoundEvents
 *  net.minecraft.inventory.IInventory
 *  net.minecraft.item.Item
 *  net.minecraft.item.Item$ToolMaterial
 *  net.minecraft.item.ItemStack
 *  net.minecraft.nbt.NBTTagCompound
 *  net.minecraft.util.text.TextFormatting
 *  net.minecraft.world.World
 *  net.minecraftforge.event.entity.player.ItemTooltipEvent
 *  net.minecraftforge.fml.common.gameevent.PlayerEvent$ItemCraftedEvent
 *  net.minecraftforge.registries.IForgeRegistry
 *  net.minecraftforge.registries.IForgeRegistryEntry
 */
package net.tangotek.tektopia;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent;
import net.minecraftforge.registries.IForgeRegistry;
import net.minecraftforge.registries.IForgeRegistryEntry;
import net.tangotek.tektopia.ItemTagType;
import net.tangotek.tektopia.ProfessionType;
import net.tangotek.tektopia.Village;
import net.tangotek.tektopia.caps.IVillageData;
import net.tangotek.tektopia.entities.EntityBard;
import net.tangotek.tektopia.entities.EntityBlacksmith;
import net.tangotek.tektopia.entities.EntityButcher;
import net.tangotek.tektopia.entities.EntityChef;
import net.tangotek.tektopia.entities.EntityChild;
import net.tangotek.tektopia.entities.EntityCleric;
import net.tangotek.tektopia.entities.EntityDruid;
import net.tangotek.tektopia.entities.EntityEnchanter;
import net.tangotek.tektopia.entities.EntityFarmer;
import net.tangotek.tektopia.entities.EntityGuard;
import net.tangotek.tektopia.entities.EntityLumberjack;
import net.tangotek.tektopia.entities.EntityMiner;
import net.tangotek.tektopia.entities.EntityNitwit;
import net.tangotek.tektopia.entities.EntityNomad;
import net.tangotek.tektopia.entities.EntityRancher;
import net.tangotek.tektopia.entities.EntityTeacher;
import net.tangotek.tektopia.items.ItemBeer;
import net.tangotek.tektopia.items.ItemHammer;
import net.tangotek.tektopia.items.ItemHeart;
import net.tangotek.tektopia.items.ItemProfessionToken;
import net.tangotek.tektopia.items.ItemRancherHat;
import net.tangotek.tektopia.items.ItemStructureToken;
import net.tangotek.tektopia.structures.VillageStructureType;

public class ModItems {
    public static ItemHammer ironHammer = new ItemHammer(Item.ToolMaterial.IRON, "iron_hammer");
    public static ItemBeer beer = new ItemBeer("beer");
    public static ItemHeart heart = new ItemHeart("heart");
    public static ItemRancherHat rancherHat = new ItemRancherHat("rancher_hat");
    public static ItemStructureToken structureTavern = new ItemStructureToken("structure_tavern", 45);
    public static ItemStructureToken structureTownHall = new ItemStructureToken("structure_townhall", 0);
    public static ItemStructureToken structureSchool = new ItemStructureToken("structure_school", 35);
    public static ItemStructureToken structureStorage = new ItemStructureToken("structure_storage", 0);
    public static ItemStructureToken structureSheepPen = new ItemStructureToken("structure_sheeppen", 18);
    public static ItemStructureToken structureMineshaft = new ItemStructureToken("structure_mineshaft", 3);
    public static ItemStructureToken structurePigPen = new ItemStructureToken("structure_pigpen", 18);
    public static ItemStructureToken structureHome2 = new ItemStructureToken("structure_home2", 6);
    public static ItemStructureToken structureHome4 = new ItemStructureToken("structure_home4", 13);
    public static ItemStructureToken structureHome6 = new ItemStructureToken("structure_home6", 20);
    public static ItemStructureToken structureCowPen = new ItemStructureToken("structure_cowpen", 20);
    public static ItemStructureToken structureLibrary = new ItemStructureToken("structure_library", 30);
    public static ItemStructureToken structureChickenCoop = new ItemStructureToken("structure_chickencoop", 16);
    public static ItemStructureToken structureButcher = new ItemStructureToken("structure_butcher", 25);
    public static ItemStructureToken structureBlacksmith = new ItemStructureToken("structure_blacksmith", 30);
    public static ItemStructureToken structureGuardPost = new ItemStructureToken("structure_guard_post", 2);
    public static ItemStructureToken structureMerchantStall = new ItemStructureToken("structure_merchant_stall", 20);
    public static ItemStructureToken structureKitchen = new ItemStructureToken("structure_kitchen", 18);
    public static ItemStructureToken structureBarracks = new ItemStructureToken("structure_barracks", 35);
    public static ItemProfessionToken itemBard = new ItemProfessionToken("prof_bard", ProfessionType.BARD, (w, v) -> new EntityBard((World)w), 15);
    public static ItemProfessionToken itemBlacksmith = new ItemProfessionToken("prof_blacksmith", ProfessionType.BLACKSMITH, (w, v) -> new EntityBlacksmith((World)w), 5);
    public static ItemProfessionToken itemButcher = new ItemProfessionToken("prof_butcher", ProfessionType.BUTCHER, (w, v) -> new EntityButcher((World)w), 4);
    public static ItemProfessionToken itemChef = new ItemProfessionToken("prof_chef", ProfessionType.CHEF, (w, v) -> new EntityChef((World)w), 7);
    public static ItemProfessionToken itemCleric = new ItemProfessionToken("prof_cleric", ProfessionType.CLERIC, (w, v) -> new EntityCleric((World)w), 12);
    public static ItemProfessionToken itemDruid = new ItemProfessionToken("prof_druid", ProfessionType.DRUID, (w, v) -> new EntityDruid((World)w), 12);
    public static ItemProfessionToken itemEnchanter = new ItemProfessionToken("prof_enchanter", ProfessionType.ENCHANTER, (w, v) -> new EntityEnchanter((World)w), 15);
    public static ItemProfessionToken itemFarmer = new ItemProfessionToken("prof_farmer", ProfessionType.FARMER, (w, v) -> new EntityFarmer((World)w), 3);
    public static ItemProfessionToken itemGuard = new ItemProfessionToken("prof_guard", ProfessionType.GUARD, (w, v) -> new EntityGuard((World)w), 5);
    public static ItemProfessionToken itemLumberjack = new ItemProfessionToken("prof_lumberjack", ProfessionType.LUMBERJACK, (w, v) -> new EntityLumberjack((World)w), 3);
    public static ItemProfessionToken itemMiner = new ItemProfessionToken("prof_miner", ProfessionType.MINER, (w, v) -> new EntityMiner((World)w), 4);
    public static ItemProfessionToken itemRancher = new ItemProfessionToken("prof_rancher", ProfessionType.RANCHER, (w, v) -> new EntityRancher((World)w), 4);
    public static ItemProfessionToken itemTeacher = new ItemProfessionToken("prof_teacher", ProfessionType.TEACHER, (w, v) -> new EntityTeacher((World)w), 8);
    public static ItemProfessionToken itemChild = new ItemProfessionToken("prof_child", ProfessionType.CHILD, (w, v) -> new EntityChild((World)w), 0);
    public static ItemProfessionToken itemNitWit = new ItemProfessionToken("prof_nitwit", ProfessionType.NITWIT, (w, v) -> new EntityNitwit((World)w), 0);
    public static ItemProfessionToken itemNomad = new ItemProfessionToken("prof_nomad", ProfessionType.NOMAD, (w, v) -> new EntityNomad((World)w), 0);
    public static ItemProfessionToken itemCaptain = new ItemProfessionToken("prof_captain", ProfessionType.CAPTAIN, (w, v) -> {
        EntityGuard guard;
        if (v instanceof EntityGuard && v.hasVillage() && !(guard = (EntityGuard)(v)).isCaptain()) {
            List<EntityGuard> otherGuards = w.getEntitiesWithinAABB(EntityGuard.class, v.getVillage().getAABB().grow(50.0));
            otherGuards.stream().filter(g -> g.isCaptain() && g.getVillage() == v.getVillage()).forEach(g -> g.setCaptain(false));
            guard.setCaptain(true);
            guard.modifyHappy(100);
            guard.playSound(SoundEvents.ENTITY_ILLAGER_CAST_SPELL, 1.0f, 1.0f);
        }
        return null;
    }, 3){

        @Override
        public int getCost(Village v) {
            if (v.getStructures(VillageStructureType.BARRACKS).isEmpty()) {
                return 0;
            }
            return super.getCost(v);
        }
    };
    public static ItemStructureToken[] structureTokens = new ItemStructureToken[]{structureTavern, structureTownHall, structureSchool, structureStorage, structureSheepPen, structureMineshaft, structurePigPen, structureHome2, structureHome4, structureHome6, structureCowPen, structureLibrary, structureChickenCoop, structureButcher, structureBlacksmith, structureGuardPost, structureMerchantStall, structureKitchen, structureBarracks};
    public static Map<ProfessionType, ItemProfessionToken> professionTokens = new HashMap<ProfessionType, ItemProfessionToken>();
    public static ItemStack EMPTY_HAND_ITEM;

    private static void addProfessionToken(ItemProfessionToken token) {
        professionTokens.put(token.getProfessionType(), token);
    }

    public static void register(IForgeRegistry<Item> registry) {
        System.out.println("Registering Items");
        registry.registerAll(new Item[]{ironHammer, beer, heart, rancherHat});
        professionTokens.values().forEach(pt -> registry.register(pt));
        registry.registerAll(structureTokens);
    }

    public static void registerModels() {
        ironHammer.registerItemModel();
        beer.registerItemModel();
        heart.registerItemModel();
        rancherHat.registerItemModel();
        for (ItemStructureToken token : structureTokens) {
            token.registerItemModel();
        }
        professionTokens.values().forEach(pt -> pt.registerItemModel());
    }

    public static ItemProfessionToken getProfessionToken(ProfessionType pt) {
        return professionTokens.get((Object)pt);
    }

    public static String getSkullAnimal(ItemStack skull) {
        if (skull.hasTagCompound()) {
            return skull.getTagCompound().getString("SkullName");
        }
        return "";
    }

    private static boolean isAllVillager(IInventory inv) {
        for (int i = 0; i < inv.getSizeInventory(); ++i) {
            ItemStack itemStack = inv.getStackInSlot(i);
            if (itemStack.isEmpty() || ModItems.isTaggedItem(itemStack, ItemTagType.VILLAGER)) continue;
            return false;
        }
        return true;
    }

    public static boolean isCompressionCraft(PlayerEvent.ItemCraftedEvent event) {
        Item item = event.crafting.getItem();
        return item == Items.IRON_INGOT || item == Items.REDSTONE || item == Items.EMERALD || item == Items.WHEAT || item == Items.GOLD_INGOT || item == Item.getItemFromBlock((Block)Blocks.EMERALD_BLOCK) || item == Item.getItemFromBlock((Block)Blocks.IRON_BLOCK) || item == Item.getItemFromBlock((Block)Blocks.REDSTONE_BLOCK) || item == Item.getItemFromBlock((Block)Blocks.GOLD_BLOCK) || item == Item.getItemFromBlock((Block)Blocks.HAY_BLOCK);
    }

    public static void onPlayerCraftedEvent(PlayerEvent.ItemCraftedEvent event) {
        if (ModItems.isAllVillager(event.craftMatrix) && ModItems.isCompressionCraft(event)) {
            ModItems.makeTaggedItem(event.crafting, ItemTagType.VILLAGER);
        }
    }

    public static ItemStack makeTaggedItem(ItemStack itemStack, ItemTagType tag, String displayName) {
        return ModItems.makeTaggedItemInternal(itemStack, tag, displayName);
    }

    public static ItemStack makeTaggedItem(ItemStack itemStack, ItemTagType tag) {
        return ModItems.makeTaggedItemInternal(itemStack, tag, itemStack.getDisplayName());
    }

    public static ItemStack createTaggedItem(Item item, int qty, ItemTagType tag) {
        ItemStack itemStack = new ItemStack(item, qty);
        return ModItems.makeTaggedItemInternal(itemStack, tag, itemStack.getDisplayName());
    }

    public static ItemStack createTaggedItem(Item item, ItemTagType tag) {
        return ModItems.createTaggedItem(item, 1, tag);
    }

    public static ItemStack untagItem(ItemStack itemStack, ItemTagType tag) {
        if (ModItems.isTaggedItem(itemStack, tag)) {
            itemStack.getOrCreateSubCompound("village").setBoolean(tag.tag, false);
        }
        return itemStack;
    }

    private static ItemStack makeTaggedItemInternal(ItemStack itemStack, ItemTagType tag, String displayName) {
        if (!ModItems.isTaggedItem(itemStack, tag)) {
            itemStack.getOrCreateSubCompound("village").setBoolean(tag.tag, true);
        }
        return itemStack;
    }

    public static boolean isVillagerItemsEnabled() {
        return false;
    }

    public static boolean isTaggedItem(ItemStack itemStack, ItemTagType tag) {
        NBTTagCompound tagCompound = itemStack.getSubCompound("village");
        if (tagCompound != null) {
            return tagCompound.getBoolean(tag.tag);
        }
        return false;
    }

    public static boolean canVillagerSee(ItemStack itemStack) {
        return !ModItems.isVillagerItemsEnabled() || ModItems.isTaggedItem(itemStack, ItemTagType.VILLAGER);
    }

    public static void bindItemToVillage(ItemStack itemStack, Village v) {
        itemStack.getOrCreateSubCompound("village").setUniqueId("villageId", v.getTownData().getUUID());
    }

    public static boolean isItemVillageBound(ItemStack itemStack, Village v) {
        IVillageData townData = v.getTownData();
        if (itemStack.getOrCreateSubCompound("village").hasUniqueId("villageId") && townData != null) {
            return itemStack.getOrCreateSubCompound("village").getUniqueId("villageId").equals(townData.getUUID());
        }
        return false;
    }

    public static boolean isItemVillageBound(ItemStack itemStack) {
        return itemStack.getOrCreateSubCompound("village").hasUniqueId("villageId");
    }

    public static void onItemToolTip(ItemTooltipEvent event) {
        if (ModItems.isTaggedItem(event.getItemStack(), ItemTagType.VILLAGER) && !event.getToolTip().isEmpty()) {
            event.getToolTip().set(0, TextFormatting.GREEN + (String)event.getToolTip().get(0));
        }
    }

    static {
        ModItems.addProfessionToken(itemBard);
        ModItems.addProfessionToken(itemBlacksmith);
        ModItems.addProfessionToken(itemButcher);
        ModItems.addProfessionToken(itemChef);
        ModItems.addProfessionToken(itemCleric);
        ModItems.addProfessionToken(itemDruid);
        ModItems.addProfessionToken(itemEnchanter);
        ModItems.addProfessionToken(itemFarmer);
        ModItems.addProfessionToken(itemGuard);
        ModItems.addProfessionToken(itemLumberjack);
        ModItems.addProfessionToken(itemMiner);
        ModItems.addProfessionToken(itemRancher);
        ModItems.addProfessionToken(itemTeacher);
        ModItems.addProfessionToken(itemChild);
        ModItems.addProfessionToken(itemNitWit);
        ModItems.addProfessionToken(itemNomad);
        ModItems.addProfessionToken(itemCaptain);
        EMPTY_HAND_ITEM = new ItemStack(Items.RECORD_11);
    }
}

