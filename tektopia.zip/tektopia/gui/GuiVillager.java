/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.client.gui.inventory.GuiContainer
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.resources.I18n
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.inventory.Container
 *  net.minecraft.item.EnumDyeColor
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.ResourceLocation
 *  net.minecraftforge.fml.client.config.HoverChecker
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 */
package net.tangotek.tektopia.gui;

import java.io.IOException;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.inventory.Container;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.client.config.HoverChecker;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.tangotek.tektopia.ModItems;
import net.tangotek.tektopia.ProfessionType;
import net.tangotek.tektopia.VillagerRole;
import net.tangotek.tektopia.entities.EntityVillagerTek;
import net.tangotek.tektopia.gui.ContainerVillager;
import net.tangotek.tektopia.gui.GuiVillagerAI;

@SideOnly(value=Side.CLIENT)
public class GuiVillager
extends GuiContainer {
    private static final ResourceLocation GUI_TEXTURE = new ResourceLocation("tektopia", "textures/gui/container/villager_main.png");
    private final EntityVillagerTek villager;
    private Map<HoverChecker, String> hoverChecks = new HashMap<HoverChecker, String>();

    public GuiVillager(EntityVillagerTek villager) {
        super((Container)new ContainerVillager(villager.getInventory()));
        this.villager = villager;
        this.xSize = 178;
        this.ySize = 157;
    }

    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        if (this.villager.isRole(VillagerRole.VILLAGER) && this.isPointInRegion(43, 0, 28, 29, mouseX, mouseY)) {
            this.mc.displayGuiScreen((GuiScreen)new GuiVillagerAI(this.villager));
        }
        super.mouseClicked(mouseX, mouseY, mouseButton);
    }

    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.drawDefaultBackground();
        super.drawScreen(mouseX, mouseY, partialTicks);
        this.renderHoveredToolTip(mouseX, mouseY);
        for (Map.Entry<HoverChecker, String> entry : this.hoverChecks.entrySet()) {
            if (!entry.getKey().checkHover(mouseX, mouseY)) continue;
            this.drawHoveringText(entry.getValue(), mouseX, mouseY);
        }
    }

    protected void drawGuiContainerForegroundLayer(int mouseX, int mouseY) {
        GlStateManager.disableLighting();
        GlStateManager.disableBlend();
        boolean firstDraw = this.hoverChecks.isEmpty();
        this.itemRender.renderItemAndEffectIntoGUI((EntityLivingBase)this.mc.player, new ItemStack((Item)ModItems.getProfessionToken(this.villager.getProfessionType())), 20, 10);
        this.itemRender.renderItemAndEffectIntoGUI((EntityLivingBase)this.mc.player, new ItemStack((Item)ModItems.getProfessionToken(this.villager.getProfessionType())), 5, 34);
        if (firstDraw) {
            HoverChecker hoverChecker = new HoverChecker(this.guiTop + 34, this.guiTop + 34 + 16, this.guiLeft + 5, this.guiLeft + 5 + 16, 350);
            this.hoverChecks.put(hoverChecker, I18n.format((String)("item.prof_" + this.villager.getProfessionType().name + ".name"), (Object[])new Object[0]));
        }
        this.fontRenderer.drawString(this.villager.getDisplayName().getFormattedText(), 27, 39, 0x404040);
        this.drawStat("ui.villager.health", 185, 29, 2, 52, this.villager.getHealth(), this.villager.getMaxHealth(), firstDraw);
        this.drawStat("ui.villager.hunger", 196, 29, 6, 63, this.villager.getHunger(), this.villager.getMaxHunger(), firstDraw);
        this.drawStat("ui.villager.happy", 207, 29, 4, 74, this.villager.getHappy(), this.villager.getMaxHappy(), firstDraw);
        this.drawStat("ui.villager.intelligence", 218, 29, 0, 85, this.villager.getIntelligence(), this.villager.getMaxIntelligence(), firstDraw);
        this.drawProfessions(firstDraw);
        GlStateManager.enableLighting();
    }

    protected void drawGuiContainerBackgroundLayer(float partialTicks, int mouseX, int mouseY) {
        GlStateManager.color((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        this.mc.getTextureManager().bindTexture(GUI_TEXTURE);
        int i = (this.width - this.xSize) / 2;
        int j = (this.height - this.ySize) / 2;
        this.drawTexturedModalRect(i, j, 0, 0, this.xSize, this.ySize);
    }

    private void drawProfessions(boolean firstDraw) {
        ArrayList<AbstractMap.SimpleEntry<ProfessionType, Integer>> skillList = new ArrayList<AbstractMap.SimpleEntry<ProfessionType, Integer>>();
        for (ProfessionType pt : ProfessionType.values()) {
            int skill = this.villager.getSkill(pt);
            if (skill <= 0 || !pt.canCopy) continue;
            skillList.add(new AbstractMap.SimpleEntry<ProfessionType, Integer>(pt, skill));
        }
    //    Comparator<AbstractMap.SimpleEntry> comp = (Comparator<AbstractMap.SimpleEntry>) Comparator.comparing(AbstractMap.SimpleEntry::getValue);
        Collections.sort(skillList,(o1, o2)->{return o1.getValue().compareTo(o2.getValue()); });
        Collections.reverse(skillList);
        this.drawProfession(skillList, 0, 110, 55, firstDraw);
        this.drawProfession(skillList, 1, 110, 73, firstDraw);
        this.drawProfession(skillList, 2, 145, 55, firstDraw);
        this.drawProfession(skillList, 3, 145, 73, firstDraw);
    }

    private void drawProfession(List<AbstractMap.SimpleEntry<ProfessionType, Integer>> skillList, int index, int x, int y, boolean firstDraw) {
        if (index < skillList.size()) {
            ProfessionType profType = skillList.get(index).getKey();
            int level = skillList.get(index).getValue();
            ItemStack itemStack = new ItemStack((Item)ModItems.getProfessionToken(profType), level);
            this.itemRender.renderItemAndEffectIntoGUI((EntityLivingBase)this.mc.player, itemStack, x, y);
            int color = 0xFFFFFF;
            if (this.villager.getBlessed() > 0 && profType == this.villager.getProfessionType()) {
                color = EnumDyeColor.LIME.getColorValue();
            }
            int xPosition = x + 12;
            int yPosition = y - 5;
            String s = String.valueOf(level);
            GlStateManager.disableLighting();
            GlStateManager.disableDepth();
            GlStateManager.disableBlend();
            this.fontRenderer.drawStringWithShadow(s, (float)(xPosition + 19 - 2 - this.fontRenderer.getStringWidth(s)), (float)(yPosition + 6 + 3), color);
            GlStateManager.enableLighting();
            GlStateManager.enableDepth();
            GlStateManager.enableBlend();
            if (firstDraw) {
                HoverChecker hoverChecker = new HoverChecker(this.guiTop + y, this.guiTop + y + 16, this.guiLeft + x, this.guiLeft + x + 16, 350);
                this.hoverChecks.put(hoverChecker, I18n.format((String)("item.prof_" + profType.name + ".name"), (Object[])new Object[0]));
            }
        }
    }

    private void drawStat(String name, int xTex, int yTex, int colorIndex, int y, float value, float max, boolean firstDraw) {
        GlStateManager.color((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        this.mc.getTextureManager().bindTexture(GUI_TEXTURE);
        int BAR_LEFT = 24;
        int BAR_WIDTH = 67;
        int BAR_TEX_LEFT = 182;
        int BAR_TEX_TOP = 53;
        int ICON_LEFT = 8;
        this.drawTexturedModalRect(8, y, xTex, yTex, 11, 9);
        if (firstDraw) {
            HoverChecker hoverChecker = new HoverChecker(this.guiTop + y, this.guiTop + y + 9, this.guiLeft + 8, this.guiLeft + 8 + 11, 350);
            this.hoverChecks.put(hoverChecker, I18n.format((String)name, (Object[])new Object[0]));
        }
        this.drawTexturedModalRect(24, y + 2, 182, 53 + colorIndex * 5 * 2, 67, 5);
        int i = (int)(value / max * 67.0f);
        if (i > 0) {
            this.drawTexturedModalRect(24, y + 2, 182, 53 + (colorIndex * 5 * 2 + 5), i, 5);
        }
        this.fontRenderer.drawString(String.valueOf((int)value), 93, y + 1, 0x404040);
    }
}

