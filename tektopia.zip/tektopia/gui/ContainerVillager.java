/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.inventory.Container
 *  net.minecraft.inventory.IContainerListener
 *  net.minecraft.inventory.IInventory
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 */
package net.tangotek.tektopia.gui;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IContainerListener;
import net.minecraft.inventory.IInventory;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.tangotek.tektopia.gui.ReadOnlySlot;
import net.tangotek.tektopia.storage.VillagerInventory;

public class ContainerVillager
extends Container {
    private final IInventory villagerInventory;

    public ContainerVillager(VillagerInventory villagerInventory) {
        this.villagerInventory = villagerInventory;
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 9; ++j) {
                this.addSlotToContainer(new ReadOnlySlot((IInventory)villagerInventory, i * 9 + j, 9 + j * 18, 97 + i * 18));
            }
        }
    }

    public void addListener(IContainerListener listener) {
        super.addListener(listener);
        listener.sendAllWindowProperties((Container)this, this.villagerInventory);
    }

    @SideOnly(value=Side.CLIENT)
    public void updateProgressBar(int id, int data) {
        this.villagerInventory.setField(id, data);
    }

    public boolean canInteractWith(EntityPlayer playerIn) {
        return true;
    }
}

