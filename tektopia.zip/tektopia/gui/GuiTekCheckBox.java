/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.GuiButton
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.util.ResourceLocation
 */
package net.tangotek.tektopia.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;

public class GuiTekCheckBox
extends GuiButton {
    private boolean isChecked;
    ResourceLocation resourceLocation;
    private int checkedTexX;
    private int checkedTexY;
    private int uncheckedTexX;
    private int uncheckedTexY;

    public GuiTekCheckBox(int buttonId, int x, int y, int widthIn, int heightIn, boolean isChecked, int checkedTexX, int checkedTexY, int uncheckedTexX, int uncheckedTexY, ResourceLocation resourceLocation) {
        super(buttonId, x, y, widthIn, heightIn, "");
        this.resourceLocation = resourceLocation;
        this.isChecked = isChecked;
        this.width = widthIn;
        this.height = heightIn;
        this.checkedTexX = checkedTexX;
        this.checkedTexY = checkedTexY;
        this.uncheckedTexX = uncheckedTexX;
        this.uncheckedTexY = uncheckedTexY;
    }

    public void drawButton(Minecraft mc, int mouseX, int mouseY, float partial) {
        if (this.visible) {
            this.hovered = mouseX >= this.x && mouseY >= this.y && mouseX < this.x + this.width && mouseY < this.y + this.height;
            mc.getTextureManager().bindTexture(this.resourceLocation);
            GlStateManager.disableDepth();
            if (this.isChecked) {
                this.drawTexturedModalRect(this.x, this.y, this.checkedTexX, this.checkedTexY, this.width, this.height);
            } else {
                this.drawTexturedModalRect(this.x, this.y, this.uncheckedTexX, this.uncheckedTexY, this.width, this.height);
            }
            GlStateManager.enableDepth();
        }
    }

    public boolean mousePressed(Minecraft mc, int mouseX, int mouseY) {
        if (this.enabled && this.visible && mouseX >= this.x && mouseY >= this.y && mouseX < this.x + this.width && mouseY < this.y + this.height) {
            this.isChecked = !this.isChecked;
            return true;
        }
        return false;
    }

    public boolean isChecked() {
        return this.isChecked;
    }

    public void setIsChecked(boolean isChecked) {
        this.isChecked = isChecked;
    }
}

