/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.GuiButton
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.client.gui.inventory.GuiContainer
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.inventory.Container
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.ResourceLocation
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.text.TextComponentTranslation
 *  net.minecraftforge.fml.common.network.simpleimpl.IMessage
 *  org.lwjgl.input.Mouse
 */
package net.tangotek.tektopia.gui;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.tangotek.tektopia.ModItems;
import net.tangotek.tektopia.TekVillager;
import net.tangotek.tektopia.entities.EntityVillagerTek;
import net.tangotek.tektopia.gui.GuiTekCheckBox;
import net.tangotek.tektopia.gui.GuiVillager;
import net.tangotek.tektopia.network.PacketAIFilter;
import org.lwjgl.input.Mouse;

public class GuiVillagerAI
extends GuiContainer {
    public static final ResourceLocation GUI_VILLAGER_AI_TEXTURE = new ResourceLocation("tektopia", "textures/gui/container/villager_ai.png");
    private final EntityVillagerTek villager;
    private float currentScroll = 0.0f;
    private int scrollIndex = 0;
    private List<String> aiFilters;
    private final int MAX_VISIBLE_ROWS = 10;
    private boolean isScrolling;
    private boolean wasClicking;

    public GuiVillagerAI(EntityVillagerTek villager) {
        super(new Container(){

            public boolean canInteractWith(EntityPlayer playerIn) {
                return false;
            }
        });
        this.xSize = 178;
        this.ySize = 157;
        this.villager = villager;
        this.aiFilters = villager.getAIFilters();
        Collections.sort(this.aiFilters);
    }

    public void initGui() {
        super.initGui();
        for (int buttonId = 0; buttonId < 10; ++buttonId) {
            this.addButton(new GuiTekCheckBox(buttonId, this.guiLeft + 8, this.guiTop + 11 * buttonId + 39, 10, 10, true, 190, 57, 180, 57, GUI_VILLAGER_AI_TEXTURE));
        }
    }

    protected void actionPerformed(GuiButton button) throws IOException {
        if (button.enabled && button instanceof GuiTekCheckBox) {
            GuiTekCheckBox checkBox = (GuiTekCheckBox)button;
            int index = checkBox.id + this.scrollIndex;
            String aiFilter = this.aiFilters.get(index);
            TekVillager.NETWORK.sendToServer((IMessage)new PacketAIFilter((Entity)this.villager, aiFilter, checkBox.isChecked()));
        }
    }

    private boolean needsScrollBar() {
        return this.aiFilters.size() > 10;
    }

    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        int i = Mouse.getEventDWheel();
        if (i != 0 && this.needsScrollBar()) {
            int j = this.aiFilters.size() - 10;
            if (i > 0) {
                i = 1;
            }
            if (i < 0) {
                i = -1;
            }
            this.currentScroll = (float)((double)this.currentScroll - (double)i / (double)j);
            this.currentScroll = MathHelper.clamp((float)this.currentScroll, (float)0.0f, (float)1.0f);
            this.scrollTo(this.currentScroll);
        }
    }

    private void scrollTo(float scroll) {
        this.scrollIndex = (int)((float)(this.aiFilters.size() - 10) * scroll);
        if (this.scrollIndex < 0) {
            this.scrollIndex = 0;
        }
    }

    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        if (this.isPointInRegion(14, 0, 28, 29, mouseX, mouseY)) {
            this.mc.displayGuiScreen((GuiScreen)new GuiVillager(this.villager));
        }
        super.mouseClicked(mouseX, mouseY, mouseButton);
    }

    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.drawDefaultBackground();
        boolean flag = Mouse.isButtonDown((int)0);
        int i = this.guiLeft;
        int j = this.guiTop;
        int k = i + 160;
        int l = j + 39;
        int i1 = k + 14;
        int j1 = l + 112;
        if (!this.wasClicking && flag && mouseX >= k && mouseY >= l && mouseX < i1 && mouseY < j1) {
            this.isScrolling = this.needsScrollBar();
        }
        if (!flag) {
            this.isScrolling = false;
        }
        this.wasClicking = flag;
        if (this.isScrolling) {
            this.currentScroll = ((float)(mouseY - l) - 7.5f) / ((float)(j1 - l) - 15.0f);
            this.currentScroll = MathHelper.clamp((float)this.currentScroll, (float)0.0f, (float)1.0f);
            this.scrollTo(this.currentScroll);
        }
        this.updateChecks();
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    private void updateChecks() {
        for (GuiButton button : this.buttonList) {
            if (!(button instanceof GuiTekCheckBox)) continue;
            GuiTekCheckBox checkBox = (GuiTekCheckBox)button;
            int filterIndex = checkBox.id + this.scrollIndex;
            if (filterIndex < this.aiFilters.size()) {
                checkBox.visible = true;
                checkBox.setIsChecked(this.villager.isAIFilterEnabled(this.aiFilters.get(filterIndex)));
                continue;
            }
            checkBox.visible = false;
        }
    }

    protected void drawGuiContainerForegroundLayer(int mouseX, int mouseY) {
        GlStateManager.disableLighting();
        GlStateManager.disableBlend();
        this.itemRender.renderItemAndEffectIntoGUI((EntityLivingBase)this.mc.player, new ItemStack((Item)ModItems.getProfessionToken(this.villager.getProfessionType())), 20, 10);
        int topY = 40;
        for (int i = 0; i < 10; ++i) {
            int filterIndex = this.scrollIndex + i;
            if (filterIndex >= this.aiFilters.size()) continue;
            String filterName = this.aiFilters.get(filterIndex);
            TextComponentTranslation filterText = new TextComponentTranslation("ai.filter." + filterName, new Object[0]);
            this.fontRenderer.drawString(filterText.getUnformattedText(), 20, 40 + i * 11, 0x404040);
        }
        GlStateManager.enableLighting();
    }

    protected void drawGuiContainerBackgroundLayer(float partialTicks, int mouseX, int mouseY) {
        GlStateManager.color((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        this.mc.getTextureManager().bindTexture(GUI_VILLAGER_AI_TEXTURE);
        int i = (this.width - this.xSize) / 2;
        int j = (this.height - this.ySize) / 2;
        this.drawTexturedModalRect(i, j, 0, 0, this.xSize, this.ySize);
        int scrollLeft = this.guiLeft + 160;
        int scrollTop = this.guiTop + 39;
        int scrollHeight = scrollTop + 112;
        this.drawTexturedModalRect(scrollLeft, scrollTop + (int)((float)(scrollHeight - scrollTop - 17) * this.currentScroll), 180 + (this.needsScrollBar() ? 0 : 12), 38, 12, 15);
    }
}

