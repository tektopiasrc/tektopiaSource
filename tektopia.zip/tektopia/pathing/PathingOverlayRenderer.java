/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.client.multiplayer.WorldClient
 *  net.minecraft.client.renderer.BufferBuilder
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.Tessellator
 *  net.minecraft.client.renderer.vertex.DefaultVertexFormats
 *  net.minecraft.util.math.ChunkPos
 *  net.minecraftforge.client.event.RenderWorldLastEvent
 *  net.minecraftforge.common.MinecraftForge
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package net.tangotek.tektopia.pathing;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.math.ChunkPos;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.tangotek.tektopia.pathing.PathingNodeClient;
import net.tangotek.tektopia.pathing.PathingOverlayChunk;

public class PathingOverlayRenderer {
    private Map<ChunkPos, PathingOverlayChunk> chunks = new HashMap<ChunkPos, PathingOverlayChunk>();
    private boolean enabled = false;

    public PathingOverlayRenderer() {
        MinecraftForge.EVENT_BUS.register((Object)this);
    }

    public void handleNodeUpdate(PathingNodeClient node) {
        boolean bl = this.enabled = node != null;
        if (this.enabled) {
            ChunkPos chunkPos = new ChunkPos(node.pos);
            PathingOverlayChunk overlayChunk = this.chunks.get(chunkPos);
            if (overlayChunk == null) {
                overlayChunk = new PathingOverlayChunk(chunkPos);
                this.chunks.put(chunkPos, overlayChunk);
            }
            overlayChunk.putNode(node);
        } else {
            this.chunks.clear();
        }
    }

    @SubscribeEvent
    public void renderOverlays(RenderWorldLastEvent event) {
        if (!this.enabled) {
            return;
        }
        Minecraft minecraft = Minecraft.getMinecraft();
        WorldClient world = minecraft.world;
        EntityPlayerSP player = minecraft.player;
        if (world == null || player == null) {
            return;
        }
        double partialTicks = event.getPartialTicks();
        double viewX = player.lastTickPosX + (player.posX - player.lastTickPosX) * partialTicks;
        double viewY = player.lastTickPosY + (player.posY - player.lastTickPosY) * partialTicks;
        double viewZ = player.lastTickPosZ + (player.posZ - player.lastTickPosZ) * partialTicks;
        GlStateManager.pushMatrix();
        GlStateManager.disableTexture2D();
        GlStateManager.enableAlpha();
        GlStateManager.enableBlend();
        BufferBuilder vertexBuffer = Tessellator.getInstance().getBuffer();
        vertexBuffer.begin(7, DefaultVertexFormats.POSITION_COLOR);
        vertexBuffer.setTranslation(-viewX, -viewY, -viewZ);
        this.renderOverlays(world, vertexBuffer, viewX, viewY, viewZ);
        vertexBuffer.setTranslation(0.0, 0.0, 0.0);
        Tessellator.getInstance().draw();
        GlStateManager.enableTexture2D();
        GlStateManager.popMatrix();
    }

    private void renderOverlays(WorldClient world, BufferBuilder vertexBuffer, double viewX, double viewY, double viewZ) {
        this.chunks.values().forEach(c -> c.renderOverlays(world, vertexBuffer, viewX, viewY, viewZ));
    }
}

