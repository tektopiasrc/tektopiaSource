/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityAreaEffectCloud
 *  net.minecraft.init.MobEffects
 *  net.minecraft.potion.PotionEffect
 *  net.minecraft.util.EnumParticleTypes
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.world.World
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 */
package net.tangotek.tektopia.entities;

import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityAreaEffectCloud;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.tangotek.tektopia.entities.EntityVillagerTek;

public class EntityCaptainAura
extends EntityAreaEffectCloud {
    private float radius = 3.0f;
    private final float RADIUS_PER_TICK = 0.5f;

    public EntityCaptainAura(World worldIn) {
        super(worldIn);
    }

    public EntityCaptainAura(World worldIn, double x, double y, double z) {
        super(worldIn, x, y, z);
        this.setParticle(EnumParticleTypes.FIREWORKS_SPARK);
        this.setRadius(this.radius);
        this.setRadiusPerTick(0.5f);
    }

    public void onUpdate() {
        this.radius += 0.5f;
        if (this.world.isRemote) {
            for (int i = 0; i < 10; ++i) {
                this.perimeterParticle();
            }
        } else {
            if (this.ticksExisted >= this.getDuration()) {
                this.setDead();
                return;
            }
            double radiusSq = this.radius * this.radius;
            List<EntityVillagerTek> villagerList = this.world.getEntitiesWithinAABB(EntityVillagerTek.class, this.getEntityBoundingBox());
            villagerList.stream().filter(g -> g.getDistanceSq((Entity)this) < radiusSq).forEach(g -> g.addPotionEffect(new PotionEffect(MobEffects.RESISTANCE, 100)));
        }
    }

    @SideOnly(value=Side.CLIENT)
    private void perimeterParticle() {
        double motionY = Math.random() * 0.01 + 0.01;
        float f1 = this.world.rand.nextFloat() * ((float)Math.PI * 2);
        float xOffset = MathHelper.cos((float)f1) * this.radius;
        float zOffset = MathHelper.sin((float)f1) * this.radius;
        Vec3d pos = new Vec3d(this.posX + (double)xOffset, this.posY, this.posZ + (double)zOffset);
        this.world.spawnParticle(EnumParticleTypes.FIREWORKS_SPARK, pos.x, pos.y, pos.z, 0.0, motionY, 0.0, new int[0]);
    }
}

