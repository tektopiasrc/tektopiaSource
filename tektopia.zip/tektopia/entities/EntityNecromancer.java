/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.leviathanstudio.craftstudio.common.animation.AnimationHandler
 *  com.leviathanstudio.craftstudio.common.animation.IAnimated
 *  javax.annotation.Nullable
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockBush
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.particle.Particle
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityCreature
 *  net.minecraft.entity.EntityLiving
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.SharedMonsterAttributes
 *  net.minecraft.entity.ai.EntityAIBase
 *  net.minecraft.entity.ai.EntityAIMoveTowardsRestriction
 *  net.minecraft.entity.ai.EntityAINearestAttackableTarget
 *  net.minecraft.entity.ai.EntityAISwimming
 *  net.minecraft.entity.ai.EntityAIWanderAvoidWater
 *  net.minecraft.entity.monster.AbstractSkeleton
 *  net.minecraft.entity.monster.EntityHusk
 *  net.minecraft.entity.monster.EntityIronGolem
 *  net.minecraft.entity.monster.EntityMob
 *  net.minecraft.entity.monster.EntityWitherSkeleton
 *  net.minecraft.entity.monster.EntityZombie
 *  net.minecraft.entity.monster.IMob
 *  net.minecraft.entity.passive.EntityVillager
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.Items
 *  net.minecraft.init.MobEffects
 *  net.minecraft.item.ItemStack
 *  net.minecraft.nbt.NBTTagCompound
 *  net.minecraft.network.datasync.DataParameter
 *  net.minecraft.network.datasync.DataSerializer
 *  net.minecraft.network.datasync.DataSerializers
 *  net.minecraft.network.datasync.EntityDataManager
 *  net.minecraft.potion.PotionEffect
 *  net.minecraft.util.DamageSource
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.EnumParticleTypes
 *  net.minecraft.util.SoundCategory
 *  net.minecraft.util.SoundEvent
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.util.math.Vec3i
 *  net.minecraft.world.EnumDifficulty
 *  net.minecraft.world.World
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 */
package net.tangotek.tektopia.entities;

import com.leviathanstudio.craftstudio.common.animation.AnimationHandler;
import com.leviathanstudio.craftstudio.common.animation.IAnimated;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.BlockBush;
import net.minecraft.client.Minecraft;
import net.minecraft.client.particle.Particle;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.ai.EntityAIMoveTowardsRestriction;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWanderAvoidWater;
import net.minecraft.entity.monster.AbstractSkeleton;
import net.minecraft.entity.monster.EntityHusk;
import net.minecraft.entity.monster.EntityIronGolem;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.monster.EntityWitherSkeleton;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.init.MobEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializer;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.tangotek.tektopia.ModItems;
import net.tangotek.tektopia.ModSoundEvents;
import net.tangotek.tektopia.TekDataSerializers;
import net.tangotek.tektopia.TekVillager;
import net.tangotek.tektopia.Village;
import net.tangotek.tektopia.VillagerRole;
import net.tangotek.tektopia.caps.IVillageData;
import net.tangotek.tektopia.client.ParticleDarkness;
import net.tangotek.tektopia.client.ParticleSkull;
import net.tangotek.tektopia.entities.EntitySpiritSkull;
import net.tangotek.tektopia.entities.EntityVillageNavigator;
import net.tangotek.tektopia.entities.EntityVillagerTek;
import net.tangotek.tektopia.entities.ai.EntityAIDeathCloud;
import net.tangotek.tektopia.entities.ai.EntityAIFollowLeader;
import net.tangotek.tektopia.entities.ai.EntityAINecroMove;
import net.tangotek.tektopia.entities.ai.EntityAISoulLink;
import net.tangotek.tektopia.entities.ai.EntityAISummonUndead;
import net.tangotek.tektopia.tickjob.TickJob;

public class EntityNecromancer
extends EntityVillageNavigator
implements IMob {
    protected static AnimationHandler animHandler = TekVillager.getNewAnimationHandler(EntityNecromancer.class);
    private static final DataParameter<Integer> SPELL_TARGET = EntityDataManager.createKey(EntityNecromancer.class, (DataSerializer)DataSerializers.VARINT);
    private static final DataParameter<Integer> LEVEL = EntityDataManager.createKey(EntityNecromancer.class, (DataSerializer)DataSerializers.VARINT);
    private static final DataParameter<List<Integer>> MINIONS = EntityDataManager.createKey(EntityNecromancer.class, TekDataSerializers.INT_LIST);
    private final int SKULL_COOLDOWN_NORMAL = 100;
    private final int SKULL_COOLDOWN_ATTACKED = 40;
    private List<EntitySpiritSkull> skulls = new ArrayList<EntitySpiritSkull>();
    private int lastSkullGained = 0;
    private int skullCooldown = 100;
    private final int MAX_LEVEL = 5;
    private int maxSkulls = 1;
    private boolean isAngry = false;
    private BlockPos firstCheck;
    private boolean villagerDied = false;

    public EntityNecromancer(World worldIn) {
        super(worldIn, VillagerRole.ENEMY.value | VillagerRole.VISITOR.value);
        this.setSize(0.6f, 1.95f);
        this.setRotation(0.0f, 0.0f);
        if (this.world.isRemote) {
            this.addAnimationTriggerRange("tektopia:necro_summon", 102, 108, () -> this.skullParticles((Entity)this, 4));
            this.addAnimationTrigger("tektopia:necro_summon", 1, () -> this.skullParticles((Entity)this, 1));
            this.addAnimationTrigger("tektopia:necro_summon", 20, () -> this.skullParticles((Entity)this, 1));
            this.addAnimationTrigger("tektopia:necro_summon", 40, () -> this.skullParticles((Entity)this, 1));
            this.addAnimationTrigger("tektopia:necro_summon", 60, () -> this.skullParticles((Entity)this, 1));
            this.addAnimationTrigger("tektopia:necro_summon", 80, () -> this.skullParticles((Entity)this, 1));
        }
    }

    public void setLevel(int powerLevel) {
        int level = Math.max(1, Math.min(powerLevel, 5));
        this.dataManager.set(LEVEL, level);
        this.maxSkulls = level;
    }

    public int getLevel() {
        return (Integer)this.dataManager.get(LEVEL);
    }

    protected void initEntityAI() {
        this.tasks.addTask(0, (EntityAIBase)new EntityAISwimming((EntityLiving)this));
        this.tasks.addTask(9, (EntityAIBase)new EntityAISoulLink(this));
        this.tasks.addTask(9, (EntityAIBase)new EntityAIDeathCloud(this));
        this.tasks.addTask(9, (EntityAIBase)new EntityAISummonUndead(this, 1));
        this.tasks.addTask(10, (EntityAIBase)new EntityAINecroMove(this));
        this.targetTasks.addTask(2, (EntityAIBase)new EntityAINearestAttackableTarget((EntityCreature)this, EntityPlayer.class, true).setUnseenMemoryTicks(300));
        this.targetTasks.addTask(3, (EntityAIBase)new EntityAINearestAttackableTarget((EntityCreature)this, EntityVillagerTek.class, false).setUnseenMemoryTicks(300));
        this.targetTasks.addTask(5, (EntityAIBase)new EntityAINearestAttackableTarget((EntityCreature)this, EntityVillager.class, false).setUnseenMemoryTicks(300));
        this.targetTasks.addTask(5, (EntityAIBase)new EntityAINearestAttackableTarget((EntityCreature)this, EntityIronGolem.class, false));
    }

    @Override
    protected void setupServerJobs() {
        super.setupServerJobs();
        this.addJob(new TickJob(40, 50, true, () -> this.convertNearbyZombies()));
        this.addJob(new TickJob(75, 50, true, () -> this.convertNearbySkeletons()));
        this.addJob(new TickJob(3, 3, true, () -> this.decaySurroundings()));
    }

    public boolean hasVillagerDied() {
        return this.villagerDied;
    }

    public void notifyVillagerDeath() {
        this.villagerDied = true;
    }

    private void prepStuck() {
        this.firstCheck = this.getPosition();
    }

    private void checkStuck() {
        IVillageData vd;
        if (this.hasVillage() && this.firstCheck.distanceSq((Vec3i)this.getPosition()) < 2.0 && (vd = this.village.getTownData()) != null) {
            vd.setNomadsCheckedToday(true);
            vd.setMerchantCheckedToday(true);
        }
    }

    protected boolean shouldDecayBlock(BlockPos bp) {
        Block testBlock = this.world.getBlockState(bp).getBlock();
        return testBlock instanceof BlockBush;
    }

    protected void decaySurroundings() {
        for (int i = 0; i < 20; ++i) {
            BlockPos testPos = new BlockPos(this.posX + this.getRNG().nextGaussian() * 8.0, this.posY + this.getRNG().nextGaussian() * 0.6, this.posZ + this.getRNG().nextGaussian() * 8.0);
            if (!this.shouldDecayBlock(testPos)) continue;
            this.world.setBlockToAir(testPos);
            return;
        }
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(20.0);
        this.getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(64.0);
        this.dataManager.set(MINIONS, new ArrayList());
    }

    @Override
    protected void entityInit() {
        this.dataManager.register(MINIONS, new ArrayList());
        this.dataManager.register(SPELL_TARGET, 0);
        this.dataManager.register(LEVEL, 1);
        super.entityInit();
    }

    public boolean isSpellcasting() {
        int entityId = (Integer)this.dataManager.get(SPELL_TARGET);
        return entityId > 0;
    }

    public Entity getSpellTargetEntity() {
        int entityId = (Integer)this.dataManager.get(SPELL_TARGET);
        if (entityId > 0) {
            return this.world.getEntityByID(entityId);
        }
        return null;
    }

    public void setSpellTarget(Entity entity) {
        if (entity == null) {
            this.dataManager.set(SPELL_TARGET,0);
        } else {
            this.dataManager.set(SPELL_TARGET, entity.getEntityId());
        }
    }

    @SideOnly(value=Side.CLIENT)
    public void skullParticles(Entity entity, int count) {
        for (int i = 0; i < count; ++i) {
            Random rand = entity.world.rand;
            double motionY = Math.random() * 0.03 + 0.01;
            Vec3d pos = new Vec3d(entity.posX + rand.nextGaussian() * 0.5, entity.posY + (double)rand.nextFloat(), entity.posZ + rand.nextGaussian() * 0.5);
            ParticleSkull part = new ParticleSkull(entity.world, Minecraft.getMinecraft().getTextureManager(), pos, motionY);
            part.radius = rand.nextGaussian() * 0.1;
            part.radiusGrow = 0.005;
            part.torque = Math.random() * 0.04 - 0.02;
            part.lifeTime = rand.nextInt(15) + 10;
            part.onUpdate();
            Minecraft.getMinecraft().effectRenderer.addEffect((Particle)part);
        }
    }

    private void minionsDefendMe(EntityLivingBase enemy) {
        List<EntityMob> minions = this.getMinions();
        for (EntityMob minion : minions) {
            minion.setAttackTarget(enemy);
        }
    }

    private void cleanMinions() {
        List<Integer> idList;
        if (!this.world.isRemote && (idList = this.dataManager.get(MINIONS)).removeIf(entityId -> !this.isValidMinion(this.world.getEntityByID(entityId.intValue())))) {
            this.debugOut("Minion(s) removed. Now " + idList.size());
            this.dataManager.set(MINIONS, idList);
        }
    }

    public void addMinion(EntityMob mob) {
        List idList = (List)this.dataManager.get(MINIONS);
        idList.add(mob.getEntityId());
        this.dataManager.set(MINIONS, idList);
        this.debugOut("Minion " + mob.getEntityId() + " added to list. Now " + idList.size());
    }

    private boolean isValidMinion(Entity e) {
        return e != null && e instanceof EntityMob && e.isEntityAlive();
    }

    public List<EntityMob> getMinions() {
        List<Integer> idList = this.dataManager.get(MINIONS);
        ArrayList<EntityMob> mobList = new ArrayList<EntityMob>();
        idList.forEach(id -> {
            EntityMob mob = (EntityMob)this.world.getEntityByID(id.intValue());
            if (this.isValidMinion((Entity)mob)) {
                mobList.add(mob);
            }
        });
        return mobList;
    }

    public void onUpdate() {
        super.onUpdate();
        if (!this.world.isRemote && this.world.getDifficulty() == EnumDifficulty.PEACEFUL) {
            this.setDead();
        }
    }

    @Override
    public float getAIMoveSpeed() {
        return 0.22f;
    }

    protected SoundEvent getAmbientSound() {
        return null;
    }

    @Override
    public boolean isAITick() {
        return super.isAITick() || this.hurtTime > 0;
    }

    public int getMaxSummons() {
        if (this.villagerDied) {
            return 0;
        }
        return 4 + this.getLevel();
    }

    public boolean isReadyForSkull() {
        if (this.skulls.isEmpty()) {
            return true;
        }
        return this.skulls.size() < this.maxSkulls && !this.villagerDied && this.getRNG().nextInt(2) == 0 && this.ticksExisted - this.skullCooldown > this.lastSkullGained;
    }

    private void convertNearbyZombies() {
        if (!this.villagerDied) {
            List zombies = this.world.getEntitiesWithinAABB(EntityZombie.class, this.getEntityBoundingBox().grow((double)(15 + this.getLevel() * 4)));
            zombies.forEach(z -> this.convertZombie((EntityZombie)z));
        }
    }

    private void convertNearbySkeletons() {
        if (!this.villagerDied) {
            List skels = this.world.getEntitiesWithinAABB(AbstractSkeleton.class, this.getEntityBoundingBox().grow((double)(15 + this.getLevel() * 4)));
            skels.forEach(s -> this.convertSkeleton((AbstractSkeleton)s));
        }
    }

    public static boolean isMinion(EntityLivingBase mob) {
        return mob.getEntityData().hasUniqueId("master");
    }

    public static void makeMinion(EntityLivingBase minion, EntityNecromancer necro) {
        minion.getEntityData().setUniqueId("master", necro.getUniqueID());
    }

    public void convertZombie(EntityZombie z) {
        if (!EntityNecromancer.isMinion((EntityLivingBase)z)) {
            z.tasks.taskEntries.removeIf(entry -> entry.action.getClass() == EntityAIWanderAvoidWater.class);
            z.tasks.taskEntries.removeIf(entry -> entry.action.getClass() == EntityAIMoveTowardsRestriction.class);
            z.tasks.taskEntries.removeIf(entry -> entry.action.getClass() == EntityAIFollowLeader.class);
            z.tasks.addTask(5, (EntityAIBase)new EntityAIFollowLeader((EntityCreature)z, this, 8, 1.0));
            z.getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(64.0);
            EntityNecromancer.makeMinion((EntityLivingBase)z, this);
            this.debugOut("Converted nearby zombie | " + z.toString());
        }
    }

    public void convertSkeleton(AbstractSkeleton skel) {
        if (!EntityNecromancer.isMinion((EntityLivingBase)skel)) {
            skel.tasks.taskEntries.removeIf(entry -> entry.action.getClass() == EntityAIWanderAvoidWater.class);
            skel.tasks.taskEntries.removeIf(entry -> entry.action.getClass() == EntityAIFollowLeader.class);
            skel.tasks.addTask(5, (EntityAIBase)new EntityAIFollowLeader((EntityCreature)skel, this, 8, 1.0));
            skel.getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(32.0);
            EntityNecromancer.makeMinion((EntityLivingBase)skel, this);
        }
    }

    public EntityWitherSkeleton createWitherSkeleton(BlockPos summonPos) {
        EntityWitherSkeleton skel = new EntityWitherSkeleton(this.world);
        this.convertSkeleton((AbstractSkeleton)skel);
        skel.setLocationAndAngles((double)summonPos.getX() + 0.5, (double)summonPos.getY(), (double)summonPos.getZ() + 0.5, this.rotationYaw, this.rotationPitch);
        skel.onInitialSpawn(this.world.getDifficultyForLocation(summonPos), null);
        skel.addPotionEffect(new PotionEffect(MobEffects.INVISIBILITY, 15));
        return skel;
    }

    public EntityZombie createZombie(BlockPos summonPos) {
        this.getVillage();
        EntityZombie zombie = Village.isTimeOfDay(this.world, 13000L, 17000L) ? new EntityZombie(this.world) : new EntityHusk(this.world);
        this.convertZombie((EntityZombie)zombie);
        zombie.setLocationAndAngles((double)summonPos.getX() + 0.5, (double)summonPos.getY(), (double)summonPos.getZ() + 0.5, this.rotationYaw, this.rotationPitch);
        zombie.onInitialSpawn(this.world.getDifficultyForLocation(summonPos), null);
        zombie.addPotionEffect(new PotionEffect(MobEffects.INVISIBILITY, 15));
        return zombie;
    }

    public boolean isCreatureSkulled(EntityCreature creature) {
        this.skulls.removeIf(s -> !s.isEntityAlive() || s.getDistanceSq((Entity)this) > 625.0);
        return this.skulls.stream().anyMatch(s -> {
            EntityCreature c = s.getSkullCreature();
            return c != null && c.equals((Object)creature);
        });
    }

    public void addSkull(EntitySpiritSkull skull) {
        this.skulls.add(skull);
        this.lastSkullGained = this.ticksExisted;
        this.skullCooldown = this.getLevelCooldown(100);
        skull.setNecro(this);
        this.playSound(ModSoundEvents.deathFullSkulls, 1.3f, this.getRNG().nextFloat() * 0.4f + 0.8f);
    }

    public void releaseSkull(EntitySpiritSkull skull) {
        this.skulls.remove((Object)skull);
        skull.setDead();
        skull.setNecro(null);
        this.playSound(ModSoundEvents.deathSkullLeave);
        this.isAngry = true;
    }

    public boolean isAngry() {
        return this.isAngry;
    }

    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();
        if (this.isWorldRemote()) {
            this.updateIdle(this.isWalking());
            this.spawnCloud((Entity)this, this.isWalking() ? 30 : 20);
            if (this.isSpellcasting()) {
                this.skullParticles((Entity)this, this.getLevel() * 2);
            }
        } else {
            this.cleanMinions();
        }
    }

    @SideOnly(value=Side.CLIENT)
    public void spawnSmoke(Entity entity, float spread, int count) {
        for (int i = 0; i < count; ++i) {
            double xOffset = entity.world.rand.nextGaussian() * (double)spread;
            double zOffset = entity.world.rand.nextGaussian() * (double)spread;
            Vec3d pos = new Vec3d(entity.posX + xOffset, entity.posY + (double)Math.min(entity.world.rand.nextFloat(), entity.world.rand.nextFloat()) * 0.5 * (double)entity.height, entity.posZ + zOffset);
            entity.world.spawnParticle(EnumParticleTypes.SMOKE_LARGE, pos.x, pos.y, pos.z, 0.0, 0.08, 0.0, new int[0]);
        }
    }

    @SideOnly(value=Side.CLIENT)
    public void spawnCloud(Vec3d pos, int count) {
        for (int i = 0; i < count; ++i) {
            double motionY = Math.random() * 0.03 + 0.01;
            Vec3d newPos = new Vec3d(pos.x + this.world.rand.nextGaussian() * 0.5, pos.y, pos.z + this.world.rand.nextGaussian() * 0.5);
            ParticleDarkness part = new ParticleDarkness(this.world, Minecraft.getMinecraft().getTextureManager(), newPos, motionY);
            part.radius = this.world.rand.nextGaussian() * 0.3;
            part.radiusGrow = 0.015;
            part.torque = Math.random() * 0.04 - 0.02;
            part.lifeTime = this.world.rand.nextInt(15) + 10;
            part.onUpdate();
            Minecraft.getMinecraft().effectRenderer.addEffect((Particle)part);
        }
    }

    @SideOnly(value=Side.CLIENT)
    public void spawnCloud(Entity entity, int count) {
        for (int i = 0; i < count; ++i) {
            double motionY = Math.random() * 0.03 + 0.01;
            Vec3d pos = new Vec3d(entity.posX, entity.posY + (double)Math.min(this.world.rand.nextFloat(), this.world.rand.nextFloat()) * 0.5 * (double)entity.height, entity.posZ);
            ParticleDarkness part = new ParticleDarkness(this.world, Minecraft.getMinecraft().getTextureManager(), pos, motionY);
            part.radius = this.world.rand.nextGaussian() * 0.3;
            part.radiusGrow = 0.015;
            part.torque = Math.random() * 0.04 - 0.02;
            part.lifeTime = this.world.rand.nextInt(15) + 15;
            part.onUpdate();
            Minecraft.getMinecraft().effectRenderer.addEffect((Particle)part);
        }
    }

    @Override
    @SideOnly(value=Side.CLIENT)
    protected void startWalking() {
        this.playClientAnimation("necro_walk");
    }

    @Override
    @SideOnly(value=Side.CLIENT)
    protected void stopWalking() {
        this.stopClientAnimation("necro_walk");
    }

    @SideOnly(value=Side.CLIENT)
    protected void updateIdle(boolean isWalking) {
        if (!this.isCasting() && !isWalking) {
            if (!this.getAnimationHandler().isAnimationActive("tektopia", "necro_idle", (IAnimated)this)) {
                this.getAnimationHandler().startAnimation("tektopia", "necro_idle", (IAnimated)this);
            }
        } else if (this.getAnimationHandler().isAnimationActive("tektopia", "necro_idle", (IAnimated)this)) {
            this.getAnimationHandler().stopAnimation("tektopia", "necro_idle", (IAnimated)this);
        }
    }

    public boolean isCasting() {
        return false;
    }

    protected boolean canDespawn() {
        return false;
    }

    public boolean attackEntityFrom(DamageSource source, float amount) {
        List nearbySkullls;
        boolean livingAttack = source.getTrueSource() instanceof EntityLivingBase;
        if (livingAttack) {
            this.minionsDefendMe((EntityLivingBase)source.getTrueSource());
        }
        if ((nearbySkullls = this.world.getEntitiesWithinAABB(EntitySpiritSkull.class, this.getEntityBoundingBox().grow(5.0))).isEmpty() || source == DamageSource.OUT_OF_WORLD) {
            this.skullCooldown -= 20;
            return super.attackEntityFrom(source, amount);
        }
        this.playSound(ModSoundEvents.deathShield, 1.2f + this.getRNG().nextFloat() * 0.4f, this.getRNG().nextFloat() * 0.2f + 0.9f);
        this.addPotionEffect(new PotionEffect(MobEffects.GLOWING, 20));
        return false;
    }

    public int getLevelCooldown(int baseValue) {
        return baseValue - (int)((double)baseValue * MathHelper.clampedLerp((double)0.0, (double)0.6, (double)((double)this.getLevel() / 5.0)));
    }

    public void onDeath(DamageSource cause) {
        this.getMinions().stream().forEach(m -> m.setHealth(0.0f));
        this.playSound(ModSoundEvents.necroDead);
        super.onDeath(cause);
    }

    protected void dropFewItems(boolean wasRecentlyHit, int lootingModifier) {
        this.dropItem(Items.EMERALD, this.getLevel() * 4);
    }

    @SideOnly(value=Side.CLIENT)
    public void handleStatusUpdate(byte id) {
        super.handleStatusUpdate(id);
    }

    public void setRevengeTarget(@Nullable EntityLivingBase target) {
        super.setRevengeTarget(target);
    }

    public boolean processInteract(EntityPlayer player, EnumHand hand) {
        ItemStack itemStack = player.getHeldItem(hand);
        if (itemStack.getItem() == ModItems.beer && this.getLevel() < 5) {
            this.setLevel(this.getLevel() + 1);
            return true;
        }
        return super.processInteract(player, hand);
    }

    @Override
    public SoundCategory getSoundCategory() {
        return SoundCategory.HOSTILE;
    }

    public void writeEntityToNBT(NBTTagCompound compound) {
        super.writeEntityToNBT(compound);
        compound.setInteger("level", this.getLevel());
    }

    public void readEntityFromNBT(NBTTagCompound compound) {
        super.readEntityFromNBT(compound);
        this.setLevel(compound.getInteger("level"));
    }

    @Override
    public AnimationHandler getAnimationHandler() {
        return animHandler;
    }

    static {
        animHandler.addAnim("tektopia", "necro_walk", "necromancer", true);
        animHandler.addAnim("tektopia", "necro_idle", "necromancer", true);
        animHandler.addAnim("tektopia", "necro_summon", "necromancer", false);
        animHandler.addAnim("tektopia", "necro_siphon", "necromancer", false);
        animHandler.addAnim("tektopia", "necro_cast_forward", "necromancer", false);
    }
}

