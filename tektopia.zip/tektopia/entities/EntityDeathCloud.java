/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.particle.Particle
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityAreaEffectCloud
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.MobEffects
 *  net.minecraft.potion.PotionEffect
 *  net.minecraft.util.EnumParticleTypes
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.world.World
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 */
package net.tangotek.tektopia.entities;

import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.particle.Particle;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityAreaEffectCloud;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.tangotek.tektopia.client.ParticleSkull;

public class EntityDeathCloud
extends EntityAreaEffectCloud {
    private float angleRadians;

    public EntityDeathCloud(World worldIn) {
        super(worldIn);
    }

    public EntityDeathCloud(World worldIn, double x, double y, double z) {
        super(worldIn, x, y, z);
        this.setParticle(EnumParticleTypes.TOWN_AURA);
    }

    public void onUpdate() {
        super.onUpdate();
        if (this.world.isRemote) {
            for (int i = 0; i < 4; ++i) {
                this.angleRadians = (float)((double)this.angleRadians + 0.0035);
                if (this.angleRadians > 1.0f) {
                    this.angleRadians = 1.0f - this.angleRadians;
                }
                this.perimeterParticle(this.angleRadians, 0.0f);
                this.perimeterParticle(-this.angleRadians, -0.3f);
                this.interiorParticle();
            }
        } else {
            double radiusSq = this.getRadius() * this.getRadius();
            List<EntityPlayer> entList = this.world.getEntitiesWithinAABB(EntityPlayer.class, this.getEntityBoundingBox());
            for (EntityPlayer insideEnt : entList) {
                if (!(insideEnt.getDistanceSq((Entity)this) < radiusSq)) continue;
                int duration = insideEnt instanceof EntityPlayer ? 160 : 80;
                insideEnt.addPotionEffect(new PotionEffect(MobEffects.WITHER, duration));
            }
        }
    }

    @SideOnly(value=Side.CLIENT)
    private void perimeterParticle(float angleRadians, float radiusMod) {
        double motionY = Math.random() * 0.01 + 0.01;
        float f1 = angleRadians * ((float)Math.PI * 2);
        float xOffset = MathHelper.cos((float)f1) * (this.getRadius() + radiusMod);
        float zOffset = MathHelper.sin((float)f1) * (this.getRadius() + radiusMod);
        Vec3d pos = new Vec3d(this.posX + (double)xOffset, this.posY, this.posZ + (double)zOffset);
        this.world.spawnParticle(EnumParticleTypes.DRAGON_BREATH, pos.x, pos.y, pos.z, 0.0, motionY, 0.0, new int[0]);
    }

    @SideOnly(value=Side.CLIENT)
    private void interiorParticle() {
        double motionY = Math.random() * 0.01 + 0.01;
        float f1 = this.world.rand.nextFloat() * ((float)Math.PI * 2);
        float xOffset = MathHelper.cos((float)f1) * this.getRadius() * this.world.rand.nextFloat();
        float zOffset = MathHelper.sin((float)f1) * this.getRadius() * this.world.rand.nextFloat();
        Vec3d pos = new Vec3d(this.posX + (double)xOffset, this.posY, this.posZ + (double)zOffset);
        ParticleSkull part = new ParticleSkull(this.world, Minecraft.getMinecraft().getTextureManager(), pos, motionY);
        part.radius = this.rand.nextGaussian() * 0.05;
        part.radiusGrow = 0.002;
        part.torque = Math.random() * 0.04 - 0.02;
        part.lifeTime = this.rand.nextInt(20) + 10;
        part.onUpdate();
        Minecraft.getMinecraft().effectRenderer.addEffect((Particle)part);
    }
}

