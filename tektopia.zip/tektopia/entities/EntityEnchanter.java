/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Optional
 *  com.leviathanstudio.craftstudio.common.animation.AnimationHandler
 *  net.minecraft.entity.ai.EntityAIBase
 *  net.minecraft.init.Blocks
 *  net.minecraft.init.Enchantments
 *  net.minecraft.init.Items
 *  net.minecraft.item.EnumDyeColor
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.network.datasync.DataParameter
 *  net.minecraft.network.datasync.DataSerializer
 *  net.minecraft.network.datasync.DataSerializers
 *  net.minecraft.network.datasync.EntityDataManager
 *  net.minecraft.util.EnumParticleTypes
 *  net.minecraft.util.SoundCategory
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.world.World
 */
package net.tangotek.tektopia.entities;

import com.google.common.base.Optional;
import com.leviathanstudio.craftstudio.common.animation.AnimationHandler;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.init.Blocks;
import net.minecraft.init.Enchantments;
import net.minecraft.init.Items;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializer;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import net.tangotek.tektopia.ModSoundEvents;
import net.tangotek.tektopia.ProfessionType;
import net.tangotek.tektopia.TekVillager;
import net.tangotek.tektopia.VillagerRole;
import net.tangotek.tektopia.entities.EntityVillagerTek;
import net.tangotek.tektopia.entities.ai.EntityAICraftItems;
import net.tangotek.tektopia.entities.ai.EntityAIEnchant;
import net.tangotek.tektopia.entities.crafting.Recipe;
import net.tangotek.tektopia.storage.ItemDesire;
import net.tangotek.tektopia.structures.VillageStructureType;

public class EntityEnchanter
extends EntityVillagerTek {
    protected static AnimationHandler animHandler = TekVillager.getNewAnimationHandler(EntityEnchanter.class);
    protected static final DataParameter<Optional<BlockPos>> SPELL_BLOCK = EntityDataManager.createKey(EntityEnchanter.class, (DataSerializer)DataSerializers.OPTIONAL_BLOCK_POS);
    private static List<Recipe> enchantSet = EntityEnchanter.buildEnchantSet();
    private static List<Recipe> craftSet = EntityEnchanter.buildCraftSet();
    private static final Map<String, DataParameter<Boolean>> RECIPE_PARAMS = new HashMap<String, DataParameter<Boolean>>();
    private int blockParticleTick = 0;
    private int handParticleTick = 0;
    private BlockPos clientSpellBlock;

    public EntityEnchanter(World worldIn) {
        super(worldIn, ProfessionType.ENCHANTER, VillagerRole.VILLAGER.value);
        Runnable enchantSound = () -> this.world.playSound(this.posX, this.posY, this.posZ, ModSoundEvents.villagerEnchant, SoundCategory.NEUTRAL, 1.5f, this.rand.nextFloat() * 0.2f + 0.9f, false);
        Runnable enchantApplySound = () -> this.world.playSound(this.posX, this.posY, this.posZ, ModSoundEvents.villagerEnchantApply, SoundCategory.NEUTRAL, 1.5f, this.rand.nextFloat() * 0.2f + 0.9f, false);
        if (this.world.isRemote) {
            this.addAnimationTrigger("tektopia:villager_summon", 12, enchantSound);
            this.addAnimationTrigger("tektopia:villager_summon", 20, () -> {
                this.handParticleTick = 25;
            });
            this.addAnimationTrigger("tektopia:villager_summon", 90, enchantSound);
            this.addAnimationTrigger("tektopia:villager_summon", 130, enchantApplySound);
        }
    }

    @Override
    public AnimationHandler getAnimationHandler() {
        return animHandler;
    }

    @Override
    protected void initEntityAI() {
        super.initEntityAI();
        Predicate<ItemStack> isLapis = p -> p.getItem() == Items.DYE && p.getMetadata() == EnumDyeColor.BLUE.getDyeDamage();
        this.getDesireSet().addItemDesire(new ItemDesire("Lapis", isLapis, 1, 10, 20, null));
        craftSet.forEach(r -> this.getDesireSet().addRecipeDesire((Recipe)r));
        enchantSet.forEach(r -> this.getDesireSet().addRecipeDesire((Recipe)r));
        this.tasks.addTask(50, (EntityAIBase)new EntityAICraftItems(this, craftSet, "villager_craft", null, 80, VillageStructureType.LIBRARY, Blocks.CRAFTING_TABLE, p -> p.isWorkTime()));
        this.tasks.addTask(50, (EntityAIBase)new EntityAIEnchant(this, enchantSet, "villager_summon", new ItemStack(Items.AIR), 80, VillageStructureType.LIBRARY, Blocks.ENCHANTING_TABLE, p -> p.isWorkTime(), 1));
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        this.dataManager.register(SPELL_BLOCK, Optional.absent());
        craftSet.forEach(r -> this.registerAIFilter(r.getAiFilter(), RECIPE_PARAMS.get(r.getAiFilter())));
        enchantSet.forEach(r -> this.registerAIFilter(r.getAiFilter(), RECIPE_PARAMS.get(r.getAiFilter())));
    }

    private static List<Recipe> buildEnchantSet() {
        ArrayList<Recipe> recipes = new ArrayList<Recipe>();
        ArrayList<ItemStack> ingredients = new ArrayList<ItemStack>();
        ingredients.add(new ItemStack(Items.IRON_SWORD, 1));
        ingredients.add(new ItemStack(Items.DYE, 1, EnumDyeColor.BLUE.getDyeDamage()));
        ItemStack enchanted = new ItemStack(Items.IRON_SWORD, 1);
        enchanted.addEnchantment(Enchantments.SHARPNESS, 1);
        Recipe recipe = new Recipe(ProfessionType.ENCHANTER, "enchant_iron_sword", 1, enchanted, ingredients, 1, 1, v -> v.getSkillLerp(ProfessionType.ENCHANTER, 4, 12), 3);
        recipes.add(recipe);
        ingredients = new ArrayList();
        ingredients.add(new ItemStack(Items.IRON_AXE, 1));
        ingredients.add(new ItemStack(Items.DYE, 1, EnumDyeColor.BLUE.getDyeDamage()));
        enchanted = new ItemStack(Items.IRON_AXE, 1);
        enchanted.addEnchantment(Enchantments.EFFICIENCY, 1);
        recipe = new Recipe(ProfessionType.ENCHANTER, "enchant_iron_axe", 1, enchanted, ingredients, 1, 1, v -> v.getSkillLerp(ProfessionType.ENCHANTER, 4, 15), 3);
        recipes.add(recipe);
        ingredients = new ArrayList();
        ingredients.add(new ItemStack(Items.IRON_PICKAXE, 1));
        ingredients.add(new ItemStack(Items.DYE, 1, EnumDyeColor.BLUE.getDyeDamage()));
        enchanted = new ItemStack(Items.IRON_PICKAXE, 1);
        enchanted.addEnchantment(Enchantments.EFFICIENCY, 1);
        recipe = new Recipe(ProfessionType.ENCHANTER, "enchant_iron_pickaxe", 1, enchanted, ingredients, 1, 1, v -> v.getSkillLerp(ProfessionType.ENCHANTER, 4, 15), 3);
        recipes.add(recipe);
        ingredients = new ArrayList();
        ingredients.add(new ItemStack((Item)Items.IRON_CHESTPLATE, 1));
        ingredients.add(new ItemStack(Items.DYE, 1, EnumDyeColor.BLUE.getDyeDamage()));
        enchanted = new ItemStack((Item)Items.IRON_CHESTPLATE, 1);
        enchanted.addEnchantment(Enchantments.PROTECTION, 1);
        recipe = new Recipe(ProfessionType.ENCHANTER, "enchant_iron_chestplate", 1, enchanted, ingredients, 1, 1, v -> v.getSkillLerp(ProfessionType.ENCHANTER, 4, 15), 3);
        recipes.add(recipe);
        ingredients = new ArrayList();
        ingredients.add(new ItemStack((Item)Items.IRON_HELMET, 1));
        ingredients.add(new ItemStack(Items.DYE, 1, EnumDyeColor.BLUE.getDyeDamage()));
        enchanted = new ItemStack((Item)Items.IRON_HELMET, 1);
        enchanted.addEnchantment(Enchantments.PROTECTION, 1);
        recipe = new Recipe(ProfessionType.ENCHANTER, "enchant_iron_helmet", 1, enchanted, ingredients, 1, 1, v -> v.getSkillLerp(ProfessionType.ENCHANTER, 4, 15), 3);
        recipes.add(recipe);
        ingredients = new ArrayList();
        ingredients.add(new ItemStack((Item)Items.IRON_BOOTS, 1));
        ingredients.add(new ItemStack(Items.DYE, 1, EnumDyeColor.BLUE.getDyeDamage()));
        enchanted = new ItemStack((Item)Items.IRON_BOOTS, 1);
        enchanted.addEnchantment(Enchantments.PROTECTION, 1);
        recipe = new Recipe(ProfessionType.ENCHANTER, "enchant_iron_boots", 1, enchanted, ingredients, 1, 1, v -> v.getSkillLerp(ProfessionType.ENCHANTER, 4, 15), 3);
        recipes.add(recipe);
        ingredients = new ArrayList();
        ingredients.add(new ItemStack((Item)Items.IRON_LEGGINGS, 1));
        ingredients.add(new ItemStack(Items.DYE, 1, EnumDyeColor.BLUE.getDyeDamage()));
        enchanted = new ItemStack((Item)Items.IRON_LEGGINGS, 1);
        enchanted.addEnchantment(Enchantments.PROTECTION, 1);
        recipe = new Recipe(ProfessionType.ENCHANTER, "enchant_iron_leggings", 1, enchanted, ingredients, 1, 1, v -> v.getSkillLerp(ProfessionType.ENCHANTER, 4, 15), 3);
        recipes.add(recipe);
        ingredients = new ArrayList();
        ingredients.add(new ItemStack((Item)Items.LEATHER_CHESTPLATE, 1));
        ingredients.add(new ItemStack(Items.DYE, 1, EnumDyeColor.BLUE.getDyeDamage()));
        enchanted = new ItemStack((Item)Items.LEATHER_CHESTPLATE, 1);
        enchanted.addEnchantment(Enchantments.PROTECTION, 1);
        recipe = new Recipe(ProfessionType.ENCHANTER, "enchant_leather_chestplate", 1, enchanted, ingredients, 1, 1, v -> v.getSkillLerp(ProfessionType.ENCHANTER, 4, 15), 3);
        recipes.add(recipe);
        ingredients = new ArrayList();
        ingredients.add(new ItemStack((Item)Items.LEATHER_HELMET, 1));
        ingredients.add(new ItemStack(Items.DYE, 1, EnumDyeColor.BLUE.getDyeDamage()));
        enchanted = new ItemStack((Item)Items.LEATHER_HELMET, 1);
        enchanted.addEnchantment(Enchantments.PROTECTION, 1);
        recipe = new Recipe(ProfessionType.ENCHANTER, "enchant_leather_helmet", 1, enchanted, ingredients, 1, 1, v -> v.getSkillLerp(ProfessionType.ENCHANTER, 4, 15), 3);
        recipes.add(recipe);
        ingredients = new ArrayList();
        ingredients.add(new ItemStack((Item)Items.LEATHER_BOOTS, 1));
        ingredients.add(new ItemStack(Items.DYE, 1, EnumDyeColor.BLUE.getDyeDamage()));
        enchanted = new ItemStack((Item)Items.LEATHER_BOOTS, 1);
        enchanted.addEnchantment(Enchantments.PROTECTION, 1);
        recipe = new Recipe(ProfessionType.ENCHANTER, "enchant_leather_boots", 1, enchanted, ingredients, 1, 1, v -> v.getSkillLerp(ProfessionType.ENCHANTER, 4, 15), 3);
        recipes.add(recipe);
        ingredients = new ArrayList();
        ingredients.add(new ItemStack((Item)Items.LEATHER_LEGGINGS, 1));
        ingredients.add(new ItemStack(Items.DYE, 1, EnumDyeColor.BLUE.getDyeDamage()));
        enchanted = new ItemStack((Item)Items.LEATHER_LEGGINGS, 1);
        enchanted.addEnchantment(Enchantments.PROTECTION, 1);
        recipe = new Recipe(ProfessionType.ENCHANTER, "enchant_leather_leggings", 1, enchanted, ingredients, 1, 1, v -> v.getSkillLerp(ProfessionType.ENCHANTER, 4, 15), 3);
        recipes.add(recipe);
        ingredients = new ArrayList();
        ingredients.add(new ItemStack(Items.DIAMOND_SWORD, 1));
        ingredients.add(new ItemStack(Items.DYE, 1, EnumDyeColor.BLUE.getDyeDamage()));
        enchanted = new ItemStack(Items.DIAMOND_SWORD, 1);
        enchanted.addEnchantment(Enchantments.SHARPNESS, 1);
        recipe = new Recipe(ProfessionType.ENCHANTER, "enchant_diamond_sword", 1, enchanted, ingredients, 1, 1, v -> v.getSkillLerp(ProfessionType.ENCHANTER, 4, 15), 3);
        recipes.add(recipe);
        ingredients = new ArrayList();
        ingredients.add(new ItemStack(Items.DIAMOND_AXE, 1));
        ingredients.add(new ItemStack(Items.DYE, 1, EnumDyeColor.BLUE.getDyeDamage()));
        enchanted = new ItemStack(Items.DIAMOND_AXE, 1);
        enchanted.addEnchantment(Enchantments.EFFICIENCY, 1);
        recipe = new Recipe(ProfessionType.ENCHANTER, "enchant_diamond_axe", 1, enchanted, ingredients, 1, 1, v -> v.getSkillLerp(ProfessionType.ENCHANTER, 4, 15), 3);
        recipes.add(recipe);
        ingredients = new ArrayList();
        ingredients.add(new ItemStack(Items.DIAMOND_PICKAXE, 1));
        ingredients.add(new ItemStack(Items.DYE, 1, EnumDyeColor.BLUE.getDyeDamage()));
        enchanted = new ItemStack(Items.DIAMOND_PICKAXE, 1);
        enchanted.addEnchantment(Enchantments.EFFICIENCY, 1);
        recipe = new Recipe(ProfessionType.ENCHANTER, "enchant_diamond_pickaxe", 1, enchanted, ingredients, 1, 1, v -> v.getSkillLerp(ProfessionType.ENCHANTER, 4, 15), 3);
        recipes.add(recipe);
        ingredients = new ArrayList();
        ingredients.add(new ItemStack((Item)Items.DIAMOND_CHESTPLATE, 1));
        ingredients.add(new ItemStack(Items.DYE, 1, EnumDyeColor.BLUE.getDyeDamage()));
        enchanted = new ItemStack((Item)Items.DIAMOND_CHESTPLATE, 1);
        enchanted.addEnchantment(Enchantments.PROTECTION, 1);
        recipe = new Recipe(ProfessionType.ENCHANTER, "enchant_diamond_chestplate", 1, enchanted, ingredients, 1, 1, v -> v.getSkillLerp(ProfessionType.ENCHANTER, 4, 15), 3);
        recipes.add(recipe);
        ingredients = new ArrayList();
        ingredients.add(new ItemStack((Item)Items.DIAMOND_HELMET, 1));
        ingredients.add(new ItemStack(Items.DYE, 1, EnumDyeColor.BLUE.getDyeDamage()));
        enchanted = new ItemStack((Item)Items.DIAMOND_HELMET, 1);
        enchanted.addEnchantment(Enchantments.PROTECTION, 1);
        recipe = new Recipe(ProfessionType.ENCHANTER, "enchant_diamond_helmet", 1, enchanted, ingredients, 1, 1, v -> v.getSkillLerp(ProfessionType.ENCHANTER, 4, 15), 3);
        recipes.add(recipe);
        ingredients = new ArrayList();
        ingredients.add(new ItemStack((Item)Items.DIAMOND_BOOTS, 1));
        ingredients.add(new ItemStack(Items.DYE, 1, EnumDyeColor.BLUE.getDyeDamage()));
        enchanted = new ItemStack((Item)Items.DIAMOND_BOOTS, 1);
        enchanted.addEnchantment(Enchantments.PROTECTION, 1);
        recipe = new Recipe(ProfessionType.ENCHANTER, "enchant_diamond_boots", 1, enchanted, ingredients, 1, 1, v -> v.getSkillLerp(ProfessionType.ENCHANTER, 4, 15), 3);
        recipes.add(recipe);
        ingredients = new ArrayList();
        ingredients.add(new ItemStack((Item)Items.DIAMOND_LEGGINGS, 1));
        ingredients.add(new ItemStack(Items.DYE, 1, EnumDyeColor.BLUE.getDyeDamage()));
        enchanted = new ItemStack((Item)Items.DIAMOND_LEGGINGS, 1);
        enchanted.addEnchantment(Enchantments.PROTECTION, 1);
        recipe = new Recipe(ProfessionType.ENCHANTER, "enchant_diamond_leggings", 1, enchanted, ingredients, 1, 1, v -> v.getSkillLerp(ProfessionType.ENCHANTER, 4, 15), 3);
        recipes.add(recipe);
        ingredients = new ArrayList();
        ingredients.add(new ItemStack(Items.BOOK, 1));
        ingredients.add(new ItemStack(Items.DYE, 1, EnumDyeColor.BLUE.getDyeDamage()));
        enchanted = new ItemStack(Items.ENCHANTED_BOOK, 1);
        enchanted.addEnchantment(Enchantments.MENDING, 1);
        recipe = new Recipe(ProfessionType.ENCHANTER, "enchant_book", 1, enchanted, ingredients, 2, 3, v -> v.getSkillLerp(ProfessionType.ENCHANTER, 4, 15), 10);
        recipes.add(recipe);
        return recipes;
    }

    private static List<Recipe> buildCraftSet() {
        ArrayList<Recipe> recipes = new ArrayList<Recipe>();
        ArrayList<ItemStack> ingredients = new ArrayList<ItemStack>();
        ingredients.add(new ItemStack(Items.REEDS, 3));
        Recipe recipe = new Recipe(ProfessionType.ENCHANTER, "craft_paper", 8, new ItemStack(Items.PAPER, 3), ingredients, 2, 6, v -> 2, 128);
        recipes.add(recipe);
        ingredients = new ArrayList();
        ingredients.add(new ItemStack(Items.PAPER, 3));
        ingredients.add(new ItemStack(Items.LEATHER, 1));
        recipe = new Recipe(ProfessionType.ENCHANTER, "craft_book", 3, new ItemStack(Items.BOOK, 1), ingredients, 3, 5, v -> 2, 32);
        recipes.add(recipe);
        return recipes;
    }

    public boolean isSpellcasting() {
        BlockPos blockPos = this.getSpellBlock();
        return blockPos != null;
    }

    public BlockPos getSpellBlock() {
        return (BlockPos)((Optional)this.dataManager.get(SPELL_BLOCK)).orNull();
    }

    public void setCasting(BlockPos castingPos) {
        if (castingPos == null) {
            this.dataManager.set(SPELL_BLOCK, Optional.absent());
        } else {
            this.dataManager.set(SPELL_BLOCK, Optional.of(castingPos));
        }
    }

    public void onUpdate() {
        super.onUpdate();
        if (this.world.isRemote) {
            int skill = this.getSkill(ProfessionType.ENCHANTER);
            if (this.isSpellcasting()) {
                this.clientSpellBlock = this.getSpellBlock();
                this.blockParticleTick = 10;
                if (this.handParticleTick > 0) {
                    double particles;
                    double d0 = 0.7;
                    double d1 = 0.7;
                    double d2 = 0.7;
                    float f = this.renderYawOffset * ((float)Math.PI / 180) + MathHelper.cos((float)((float)this.ticksExisted * 0.6662f)) * 0.25f;
                    float f1 = MathHelper.cos((float)f);
                    float f2 = MathHelper.sin((float)f);
                    for (particles = 1.0; particles > 1.0; particles -= 1.0) {
                        this.world.spawnParticle(EnumParticleTypes.SPELL_MOB, this.posX + (double)f1 * 0.6, this.posY + 2.0, this.posZ + (double)f2 * 0.6, d0, d1, d2, new int[]{0, 1, 1});
                        this.world.spawnParticle(EnumParticleTypes.SPELL_MOB, this.posX - (double)f1 * 0.6, this.posY + 2.0, this.posZ - (double)f2 * 0.6, d0, d1, d2, new int[]{0, 1, 1});
                    }
                    if (this.getRNG().nextDouble() < particles) {
                        this.world.spawnParticle(EnumParticleTypes.SPELL_MOB, this.posX + (double)f1 * 0.6, this.posY + 2.0, this.posZ + (double)f2 * 0.6, d0, d1, d2, new int[]{0, 1, 1});
                        this.world.spawnParticle(EnumParticleTypes.SPELL_MOB, this.posX - (double)f1 * 0.6, this.posY + 2.0, this.posZ - (double)f2 * 0.6, d0, d1, d2, new int[]{0, 1, 1});
                    }
                    --this.handParticleTick;
                }
            }
            --this.blockParticleTick;
            if (this.blockParticleTick > 0) {
                this.world.spawnParticle(EnumParticleTypes.ENCHANTMENT_TABLE, (double)this.clientSpellBlock.getX() + 0.5, (double)this.clientSpellBlock.getY() + 3.1, (double)this.clientSpellBlock.getZ() + 0.5, -1.2 + (double)this.world.rand.nextFloat() * 2.4, (double)(this.rand.nextFloat() - 1.0f), -1.2 + (double)this.world.rand.nextFloat() * 2.4, new int[0]);
            }
        }
    }

    static {
        enchantSet.forEach(r -> RECIPE_PARAMS.put(r.getAiFilter(), (DataParameter<Boolean>)EntityDataManager.createKey(EntityEnchanter.class, (DataSerializer)DataSerializers.BOOLEAN)));
        craftSet.forEach(r -> RECIPE_PARAMS.put(r.getAiFilter(), (DataParameter<Boolean>)EntityDataManager.createKey(EntityEnchanter.class, (DataSerializer)DataSerializers.BOOLEAN)));
        animHandler.addAnim("tektopia", "villager_summon", "enchanter_m", true);
        animHandler.addAnim("tektopia", "villager_craft", "enchanter_m", true);
        EntityVillagerTek.setupAnimations(animHandler, "enchanter_m");
    }
}

