/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Predicate
 *  com.leviathanstudio.craftstudio.common.animation.AnimationHandler
 *  javax.annotation.Nullable
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.IEntityLivingData
 *  net.minecraft.entity.IMerchant
 *  net.minecraft.entity.ai.EntityAIBase
 *  net.minecraft.entity.item.EntityXPOrb
 *  net.minecraft.entity.passive.EntityAnimal
 *  net.minecraft.entity.passive.EntityChicken
 *  net.minecraft.entity.passive.EntityCow
 *  net.minecraft.entity.passive.EntityPig
 *  net.minecraft.entity.passive.EntitySheep
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.SoundEvents
 *  net.minecraft.item.ItemStack
 *  net.minecraft.nbt.NBTBase
 *  net.minecraft.nbt.NBTTagCompound
 *  net.minecraft.nbt.NBTTagList
 *  net.minecraft.nbt.NBTTagString
 *  net.minecraft.pathfinding.PathNavigate
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Vec3i
 *  net.minecraft.util.text.ITextComponent
 *  net.minecraft.util.text.TextComponentTranslation
 *  net.minecraft.village.MerchantRecipe
 *  net.minecraft.village.MerchantRecipeList
 *  net.minecraft.world.World
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 */
package net.tangotek.tektopia.entities;

import com.google.common.base.Predicate;
import com.leviathanstudio.craftstudio.common.animation.AnimationHandler;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.IMerchant;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityChicken;
import net.minecraft.entity.passive.EntityCow;
import net.minecraft.entity.passive.EntityPig;
import net.minecraft.entity.passive.EntitySheep;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.nbt.NBTTagString;
import net.minecraft.pathfinding.PathNavigate;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.village.MerchantRecipe;
import net.minecraft.village.MerchantRecipeList;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.tangotek.tektopia.EntityTagType;
import net.tangotek.tektopia.ModEntities;
import net.tangotek.tektopia.TekVillager;
import net.tangotek.tektopia.Village;
import net.tangotek.tektopia.VillagerRole;
import net.tangotek.tektopia.caps.IVillageData;
import net.tangotek.tektopia.entities.EntityVillagerTek;
import net.tangotek.tektopia.entities.ai.EntityAIGenericMove;
import net.tangotek.tektopia.entities.ai.EntityAIReadBook;
import net.tangotek.tektopia.entities.ai.EntityAIReturnLostAnimal;
import net.tangotek.tektopia.entities.ai.EntityAIVisitMerchantStall;
import net.tangotek.tektopia.entities.ai.EntityAIWanderStructure;
import net.tangotek.tektopia.structures.VillageStructure;
import net.tangotek.tektopia.tickjob.TickJob;

public class EntityMerchant
extends EntityVillagerTek
implements IMerchant {
    protected static AnimationHandler animHandler = TekVillager.getNewAnimationHandler(EntityMerchant.class);
    private BlockPos firstCheck;
    private int stallLevel = 0;
    @Nullable
    private EntityPlayer buyingPlayer;
    @Nullable
    private MerchantRecipeList merchantList;
    private List<EntityAnimal> animalDeliveries = new ArrayList<EntityAnimal>();

    public EntityMerchant(World worldIn) {
        super(worldIn, null, VillagerRole.VENDOR.value | VillagerRole.VISITOR.value);
        this.sleepOffset = 0;
    }

    @Override
    protected void setupServerJobs() {
        super.setupServerJobs();
        this.addJob(new TickJob(50, 50, true, () -> this.releashAnimals()));
        this.addJob(new TickJob(100, 0, false, () -> this.prepStuck()));
        this.addJob(new TickJob(400, 0, false, () -> this.checkStuck()));
        this.addJob(new TickJob(50, 0, true, () -> {
            if (this.isSleepingTime()) {
                this.setDead();
            }
        }));
        this.addJob(new TickJob(300, 100, true, () -> {
            if (!this.hasVillage() || !this.getVillage().isValid()) {
                this.debugOut("Killing Self.  No village");
                this.setDead();
            }
        }));
    }

    private void prepStuck() {
        this.firstCheck = this.getPos();
    }

    private void checkStuck() {
        if (this.firstCheck.distanceSq((Vec3i)this.getPos()) < 20.0) {
            this.debugOut("Merchant failed to find a way to the village.");
            this.setDead();
        }
    }

    @Override
    public AnimationHandler getAnimationHandler() {
        return animHandler;
    }

    @Override
    protected void initEntityAI() {
        super.initEntityAI();
        this.addTask(50, new EntityAIGenericMove(this, p -> p.hasVillage() && Village.isNightTime(this.world), v -> this.village.getEdgeNode(), EntityVillagerTek.MovementMode.WALK, null, () -> {
            this.debugOut("Killing Self.  Left the village");
            this.setDead();
        }));
        this.addTask(50, new EntityAIVisitMerchantStall(this, p -> this.hasVillage(), 3, 60));
        this.addTask(50, new EntityAIGenericMove(this, p -> !Village.isNightTime(this.world) && p.hasVillage() && !this.isTrading(), v -> this.animalDeliveries.isEmpty() ? this.village.getLastVillagerPos() : this.getDeliveryPos(), EntityVillagerTek.MovementMode.WALK, null, () -> this.animalDeliveries.clear()));
    }

    @Override
    protected void initEntityAIBase() {
    }

    @Override
    public boolean canNavigate() {
        if (this.isTrading()) {
            return false;
        }
        return super.canNavigate();
    }

    @Override
    protected PathNavigate createNavigator(World worldIn) {
        PathNavigate nav = super.createNavigator(worldIn);
        return nav;
    }

    @Override
    public float getAIMoveSpeed() {
        return super.getAIMoveSpeed() * 0.9f;
    }

    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();
        if (!this.world.isRemote) {
            ListIterator<EntityAnimal> itr = this.animalDeliveries.listIterator();
            while (itr.hasNext()) {
                EntityAnimal animal = itr.next();
                if (!animal.isEntityAlive()) {
                    itr.remove();
                    if ((animal = animal instanceof EntityCow ? new EntityCow(this.world) : (animal instanceof EntityChicken ? new EntityChicken(this.world) : (animal instanceof EntitySheep ? new EntitySheep(this.world) : (animal instanceof EntityPig ? new EntityPig(this.world) : null)))) == null) continue;
                    itr.add((EntityAnimal)animal);
                    this.spawnAnimal((EntityAnimal)animal);
                    continue;
                }
                if (animal.getLeashHolder() == null) {
                    this.teleportAnimal((EntityAnimal)animal);
                    animal.setLeashHolder((Entity)this, true);
                    continue;
                }
                if (animal.getLeashHolder() != this) {
                    itr.remove();
                    continue;
                }
                if (!(animal.getDistanceSq((Entity)this) > 40.0)) continue;
                this.teleportAnimal((EntityAnimal)animal);
            }
        }
    }

    @Override
    protected void addTask(int priority, EntityAIBase task) {
        if (task instanceof EntityAIWanderStructure && priority <= 100) {
            return;
        }
        if (task instanceof EntityAIReadBook) {
            return;
        }
        super.addTask(priority, task);
    }

    private void releashAnimals() {
        for (EntityAnimal animal : this.animalDeliveries) {
            if (!animal.isEntityAlive()) continue;
            animal.setLeashHolder(null, true);
            animal.setLeashHolder((Entity)this, true);
        }
    }

    @Override
    public boolean isMale() {
        return true;
    }

    private void teleportAnimal(EntityAnimal animal) {
        animal.setPositionAndUpdate(this.getX(), this.getY(), this.getZ());
    }

    public void addAnimalDelivery(EntityAnimal animal) {
        this.animalDeliveries.add(animal);
        this.spawnAnimal(animal);
    }

    private BlockPos getDeliveryPos() {
        VillageStructure struct;
        if (this.animalDeliveries.size() > 0 && (struct = EntityAIReturnLostAnimal.getDestinationStructure(this.getVillage(), this.animalDeliveries.get(0), this.getPosition())) != null) {
            return struct.getDoorOutside();
        }
        return this.getVillage().getOrigin();
    }

    private void spawnAnimal(EntityAnimal animal) {
        animal.setLocationAndAngles(this.getX() + 0.5, this.getY(), this.getZ() + 0.5, 0.0f, 0.0f);
        animal.onInitialSpawn(this.world.getDifficultyForLocation(this.getPos()), (IEntityLivingData)null);
        this.world.spawnEntity((Entity)animal);
        ModEntities.makeTaggedEntity((Entity)animal, EntityTagType.VILLAGER);
    }

    @Override
    public void addVillagerPosition() {
    }

    public void setStall(int level) {
        this.stallLevel = level;
    }

    public void setCustomer(@Nullable EntityPlayer player) {
        this.buyingPlayer = player;
        this.getNavigator().clearPath();
    }

    @Nullable
    public EntityPlayer getCustomer() {
        return this.buyingPlayer;
    }

    public boolean isTrading() {
        return this.buyingPlayer != null;
    }

    @Override
    protected void bedCheck() {
    }

    @Nullable
    public MerchantRecipeList getRecipes(EntityPlayer player) {
        if (this.merchantList == null) {
            this.populateBuyingList(this.stallLevel);
        }
        return this.merchantList;
    }

    @Override
    protected boolean getCanUseDoors() {
        return true;
    }

    @Override
    public boolean processInteract(EntityPlayer player, EnumHand hand) {
        if (!(!this.isEntityAlive() || this.isTrading() || this.isChild() || player.isSneaking() || this.world.isRemote)) {
            if (this.merchantList == null) {
                this.populateBuyingList(this.stallLevel);
            }
            if (this.merchantList != null && !this.merchantList.isEmpty()) {
                this.setCustomer(player);
                player.displayVillagerTradeGui((IMerchant)this);
                this.getNavigator().clearPath();
            }
        }
        return true;
    }

    private void populateBuyingList(int stallLevel) {
        IVillageData vd;
        if (this.merchantList == null && this.hasVillage() && (vd = this.getVillage().getTownData()) != null) {
            vd.initEconomy();
            this.merchantList = vd.getEconomy().getMerchantList(this.getVillage(), stallLevel);
        }
    }

    @SideOnly(value=Side.CLIENT)
    public void setRecipes(@Nullable MerchantRecipeList recipeList) {
    }

    public World getWorld() {
        return this.world;
    }

    public void useRecipe(MerchantRecipe recipe) {
        recipe.incrementToolUses();
        this.livingSoundTime = -this.getTalkInterval();
        this.playSound(SoundEvents.ENTITY_VILLAGER_YES, this.getSoundVolume(), this.getSoundPitch());
        int i = 3 + this.rand.nextInt(4);
        if (recipe.getToolUses() == 1 || this.rand.nextInt(5) == 0) {
            i += 5;
        }
        if (recipe.getRewardsExp()) {
            this.world.spawnEntity((Entity)new EntityXPOrb(this.world, this.posX, this.posY + 0.5, this.posZ, i));
        }
        if (this.hasVillage()) {
            this.getVillage().purchaseFromMerchant(recipe, this, this.getCustomer());
        }
    }

    public void verifySellingItem(ItemStack stack) {
        if (!this.world.isRemote && this.livingSoundTime > -this.getTalkInterval() + 20) {
            this.livingSoundTime = -this.getTalkInterval();
            this.playSound(stack.isEmpty() ? SoundEvents.ENTITY_VILLAGER_NO : SoundEvents.ENTITY_VILLAGER_YES, this.getSoundVolume(), this.getSoundPitch());
        }
    }

    public ITextComponent getDisplayName() {
        TextComponentTranslation itextcomponent = new TextComponentTranslation("entity.villager.merchant", new Object[0]);
        itextcomponent.getStyle().setHoverEvent(this.getHoverEvent());
        itextcomponent.getStyle().setInsertion(this.getCachedUniqueIdString());
        return itextcomponent;
    }

    @Override
    public Predicate<Entity> isHostile() {
        return e -> false;
    }

    @Override
    public boolean isFleeFrom(Entity e) {
        return false;
    }

    public BlockPos getPos() {
        return new BlockPos((Entity)this);
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound compound) {
        super.writeEntityToNBT(compound);
        NBTTagList nbttaglist = new NBTTagList();
        for (EntityAnimal animal : this.animalDeliveries) {
            nbttaglist.appendTag((NBTBase)new NBTTagString(animal.getUniqueID().toString()));
        }
        compound.setTag("animals", (NBTBase)nbttaglist);
        if (this.merchantList != null) {
            compound.setTag("Offers", (NBTBase)this.merchantList.getRecipiesAsTags());
        }
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound compound) {
        super.readEntityFromNBT(compound);
        NBTTagList nbttaglist = compound.getTagList("animals", 10);
        block0: for (int i = 0; i < nbttaglist.tagCount(); ++i) {
            UUID uuid = UUID.fromString(nbttaglist.getStringTagAt(i));
            for (EntityAnimal animal : this.world.getEntitiesWithinAABB(EntityAnimal.class, this.getEntityBoundingBox().grow(12.0))) {
                if (!animal.getUniqueID().equals(uuid)) continue;
                this.animalDeliveries.add(animal);
                continue block0;
            }
        }
        if (compound.hasKey("Offers", 10)) {
            NBTTagCompound nbttagcompound = compound.getCompoundTag("Offers");
            this.merchantList = new MerchantRecipeList(nbttagcompound);
        }
    }

    static {
        EntityVillagerTek.setupAnimations(animHandler, "merchant_m");
    }
}

