/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.particle.Particle
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityCreature
 *  net.minecraft.entity.projectile.ProjectileHelper
 *  net.minecraft.nbt.NBTTagCompound
 *  net.minecraft.network.datasync.DataParameter
 *  net.minecraft.network.datasync.DataSerializer
 *  net.minecraft.network.datasync.DataSerializers
 *  net.minecraft.network.datasync.EntityDataManager
 *  net.minecraft.util.DamageSource
 *  net.minecraft.util.EnumParticleTypes
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.world.World
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 */
package net.tangotek.tektopia.entities;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.particle.Particle;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.projectile.ProjectileHelper;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializer;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.tangotek.tektopia.ModSoundEvents;
import net.tangotek.tektopia.client.ParticleDarkness;
import net.tangotek.tektopia.client.ParticleSkull;
import net.tangotek.tektopia.entities.EntityNecromancer;

public class EntitySpiritSkull
extends Entity {
    private double acceleration = 0.0;
    private int glowTimer = 0;
    private boolean initialSpawn = false;
    private static final DataParameter<Byte> SKULL_MODE = EntityDataManager.createKey(EntitySpiritSkull.class, (DataSerializer)DataSerializers.BYTE);
    private static final DataParameter<Integer> NECRO = EntityDataManager.createKey(EntitySpiritSkull.class, (DataSerializer)DataSerializers.VARINT);
    private static final DataParameter<Integer> SKULL_CREATURE = EntityDataManager.createKey(EntitySpiritSkull.class, (DataSerializer)DataSerializers.VARINT);

    public EntitySpiritSkull(World worldIn, boolean init) {
        this(worldIn);
        this.initialSpawn = init;
    }

    public EntitySpiritSkull(World worldIn) {
        super(worldIn);
        this.setSize(0.3125f, 0.3125f);
        this.setInvisible(true);
    }

    @SideOnly(value=Side.CLIENT)
    public EntitySpiritSkull(World worldIn, double x, double y, double z) {
        super(worldIn);
        this.setLocationAndAngles(x, y, z, this.rotationYaw, this.rotationPitch);
        this.setPosition(x, y, z);
        this.setSize(0.3125f, 0.3125f);
        this.setInvisible(true);
    }

    protected void entityInit() {
        this.dataManager.register(SKULL_MODE, ((byte)SkullMode.RETURNING.ordinal()));
        this.dataManager.register(NECRO, 0);
        this.dataManager.register(SKULL_CREATURE, 0);
    }

    public void onUpdate() {
        super.onUpdate();
        boolean valid = true;
        if (!this.world.isBlockLoaded(new BlockPos((Entity)this))) {
            this.setDead();
            valid = false;
        }
        SkullMode skullMode = this.getSkullMode();
        EntityNecromancer necro = this.getNecro();
        EntityCreature skullCreature = this.getSkullCreature();
        if (necro == null || !necro.isEntityAlive()) {
            if (!this.world.isRemote) {
                this.setDead();
            }
            valid = false;
        } else if (skullCreature == null || !skullCreature.isEntityAlive()) {
            if (!this.world.isRemote) {
                necro.releaseSkull(this);
            }
            valid = false;
        } else if (this.ticksExisted > 800) {
            necro.releaseSkull(this);
        }
        if (valid) {
            if (skullMode == SkullMode.RETURNING) {
                if (this.ticksExisted > 23) {
                    Vec3d dest = necro.getPositionVector().addVector(0.0, (double)necro.getEyeHeight(), 0.0);
                    if (!this.world.isRemote) {
                        if (this.isInvisible()) {
                            this.setInvisible(false);
                            this.setLocationAndAngles(skullCreature.posX, skullCreature.posY + (double)skullCreature.getEyeHeight(), skullCreature.posZ, 0.0f, 0.0f);
                            this.playSound(ModSoundEvents.deathSkullRebound, this.world.rand.nextFloat() * 0.4f + 1.2f, this.world.rand.nextFloat() * 0.4f + 0.8f);
                        } else if (this.getDistanceSq(dest.x, dest.y, dest.z) < 1.0) {
                            this.setSkullMode(SkullMode.PROTECTING);
                            this.playSound(ModSoundEvents.deathSkullArrive, this.world.rand.nextFloat() * 0.4f + 1.2f, this.world.rand.nextFloat() * 0.4f + 0.8f);
                        }
                    }
                    Vec3d dir = dest.subtract(this.getPositionVector()).normalize().scale(0.3);
                    this.motionX = dir.x;
                    this.motionY = dir.y;
                    this.motionZ = dir.z;
                    this.posX += this.motionX;
                    this.posY += this.motionY;
                    this.posZ += this.motionZ;
                    ProjectileHelper.rotateTowardsMovement((Entity)this, (float)0.2f);
                    this.setPosition(this.posX, this.posY, this.posZ);
                }
            } else if (skullMode == SkullMode.PROTECTING) {
                Vec3d origin = necro.getPositionVector().addVector(0.0, (double)necro.getEyeHeight(), 0.0);
                this.setPosition(origin.x, origin.y, origin.z);
            } else if (skullMode == SkullMode.ATTACKING) {
                this.posX += this.motionX;
                this.posY += this.motionY;
                this.posZ += this.motionZ;
                ProjectileHelper.rotateTowardsMovement((Entity)this, (float)0.2f);
                this.motionX *= this.acceleration;
                this.motionY *= this.acceleration;
                this.motionZ *= this.acceleration;
                this.setPosition(this.posX, this.posY, this.posZ);
            }
            if (this.world.isRemote) {
                if (skullMode != SkullMode.PROTECTING) {
                    this.createDarknessParticles(5, 0.1f);
                } else {
                    this.createDarknessParticles(2, 0.07f);
                }
                if (skullMode == SkullMode.PROTECTING || skullMode == SkullMode.RETURNING) {
                    necro.spawnCloud((Entity)skullCreature, 3);
                    if (necro.getRNG().nextInt(4) == 0) {
                        necro.skullParticles((Entity)skullCreature, 1);
                    }
                }
                if (this.ticksExisted >= 1 && this.ticksExisted <= 20 && necro != null && skullCreature != null) {
                    float percentFrom = (float)(this.ticksExisted - 1) / 20.0f;
                    float percentTo = (float)this.ticksExisted / 20.0f;
                    this.particleLine((Entity)necro, (Entity)skullCreature, percentFrom, percentTo, 25);
                }
                if (this.isGlowing()) {
                    this.world.spawnParticle(EnumParticleTypes.SMOKE_LARGE, this.posX, this.posY, this.posZ, this.world.rand.nextGaussian() * 0.1, 0.08, this.world.rand.nextGaussian() * 0.1, new int[0]);
                }
                if (this.ticksExisted > 23 && this.ticksExisted < 27) {
                    this.createSkullParticles(4);
                }
            } else if (this.glowTimer > 0) {
                --this.glowTimer;
                if (this.glowTimer == 0) {
                    this.setGlowing(false);
                }
            }
        }
    }

    @SideOnly(value=Side.CLIENT)
    private void particleLine(Entity source, Entity target, float from, float to, int count) {
        Vec3d start = source.getPositionVector().addVector(0.0, (double)source.getEyeHeight(), 0.0);
        Vec3d end = target.getPositionVector().addVector(0.0, (double)target.getEyeHeight(), 0.0);
        Vec3d line = end.subtract(start);
        for (int i = 0; i < count; ++i) {
            Vec3d delta = line.scale((double)MathHelper.nextFloat((Random)this.world.rand, (float)from, (float)to));
            Vec3d pos = start.add(delta);
            ParticleDarkness part = new ParticleDarkness(this.world, Minecraft.getMinecraft().getTextureManager(), pos, this.motionY);
            part.lifeTime = this.world.rand.nextInt(10) + 10;
            part.setRBGColorF(0.953f, 0.173f, 0.077f);
            part.onUpdate();
            Minecraft.getMinecraft().effectRenderer.addEffect((Particle)part);
        }
    }

    @SideOnly(value=Side.CLIENT)
    private void createDarknessParticles(int count, float radius) {
        for (int i = 0; i < count; ++i) {
            double motionY = Math.random() * 0.03 + 0.01;
            Vec3d pos = new Vec3d(this.posX + this.rand.nextGaussian() * 0.1, this.posY, this.posZ + this.rand.nextGaussian() * 0.1);
            ParticleDarkness part = new ParticleDarkness(this.world, Minecraft.getMinecraft().getTextureManager(), pos, motionY);
            part.radius = this.world.rand.nextGaussian() * (double)radius;
            part.radiusGrow = 0.005;
            part.torque = Math.random() * 0.04 - 0.02;
            part.lifeTime = this.world.rand.nextInt(15) + 20;
            part.onUpdate();
            Minecraft.getMinecraft().effectRenderer.addEffect((Particle)part);
        }
    }

    @SideOnly(value=Side.CLIENT)
    private void createSkullParticles(int count) {
        for (int i = 0; i < count; ++i) {
            double motionY = Math.random() * 0.03 + 0.01;
            Vec3d pos = new Vec3d(this.posX + this.rand.nextGaussian() * 0.5, this.posY + this.rand.nextGaussian(), this.posZ + this.rand.nextGaussian() * 0.5);
            ParticleSkull part = new ParticleSkull(this.world, Minecraft.getMinecraft().getTextureManager(), pos, motionY);
            part.radius = this.world.rand.nextGaussian() * 0.1;
            part.radiusGrow = 0.005;
            part.torque = Math.random() * 0.04 - 0.02;
            part.lifeTime = this.world.rand.nextInt(15) + 20;
            part.onUpdate();
            Minecraft.getMinecraft().effectRenderer.addEffect((Particle)part);
        }
    }

    @Nullable
    public EntityNecromancer getNecro() {
        Entity e;
        Integer entityId = (Integer)this.dataManager.get(NECRO);
        if (entityId > 0 && (e = this.world.getEntityByID(entityId.intValue())) instanceof EntityNecromancer) {
            return (EntityNecromancer)e;
        }
        return null;
    }

    public void setNecro(EntityNecromancer necro) {
        this.dataManager.set(NECRO, (necro == null ? 0 : necro.getEntityId()));
    }

    public void setSkullCreature(EntityCreature creature) {
        this.dataManager.set(SKULL_CREATURE, (creature == null ? 0 : creature.getEntityId()));
    }

    @Nullable
    public EntityCreature getSkullCreature() {
        Entity e;
        Integer entityId = (Integer)this.dataManager.get(SKULL_CREATURE);
        if (entityId > 0 && (e = this.world.getEntityByID(entityId.intValue())) instanceof EntityCreature && e.isEntityAlive()) {
            return (EntityCreature)e;
        }
        return null;
    }

    public SkullMode getSkullMode() {
        byte index = (Byte)this.dataManager.get(SKULL_MODE);
        return SkullMode.values()[index];
    }

    public void setSkullMode(SkullMode mode) {
        this.motionX = 0.0;
        this.motionY = 0.0;
        this.motionZ = 0.0;
        this.acceleration = 0.0;
        this.dataManager.set(SKULL_MODE, ((byte)mode.ordinal()));
        if (mode == SkullMode.ATTACKING) {
            this.acceleration = 1.02;
        }
    }

    public float getSpinRadius() {
        return 1.3f + (float)Math.abs(this.getUniqueID().getLeastSignificantBits() % 70L) / 100.0f;
    }

    public float getSpinSpeed() {
        float speed = 4.0f + (float)(Math.abs(this.getUniqueID().getLeastSignificantBits()) % 6L);
        if (this.getUniqueID().getLeastSignificantBits() % 2L == 0L) {
            speed = -speed;
        }
        return speed;
    }

    public float getSpinAxis() {
        return (float)Math.abs(this.getUniqueID().getLeastSignificantBits() % 6L) / 10.0f;
    }

    @SideOnly(value=Side.CLIENT)
    public boolean isInRangeToRenderDist(double distance) {
        double d0 = this.getEntityBoundingBox().getAverageEdgeLength() * 4.0;
        if (Double.isNaN(d0)) {
            d0 = 4.0;
        }
        return distance < (d0 *= 64.0) * d0;
    }

    protected void readEntityFromNBT(NBTTagCompound compound) {
    }

    protected void writeEntityToNBT(NBTTagCompound compound) {
    }

    public boolean canBeCollidedWith() {
        return false;
    }

    public boolean attackEntityFrom(DamageSource source, float amount) {
        return false;
    }

    public static enum SkullMode {
        RETURNING,
        PROTECTING,
        ATTACKING;

    }
}

