/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.leviathanstudio.craftstudio.common.animation.AnimationHandler
 *  net.minecraft.entity.ai.EntityAIBase
 *  net.minecraft.network.datasync.DataParameter
 *  net.minecraft.network.datasync.DataSerializer
 *  net.minecraft.network.datasync.DataSerializers
 *  net.minecraft.network.datasync.EntityDataManager
 *  net.minecraft.world.World
 */
package net.tangotek.tektopia.entities;

import com.leviathanstudio.craftstudio.common.animation.AnimationHandler;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializer;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.world.World;
import net.tangotek.tektopia.ModSoundEvents;
import net.tangotek.tektopia.ProfessionType;
import net.tangotek.tektopia.TekVillager;
import net.tangotek.tektopia.VillagerRole;
import net.tangotek.tektopia.entities.EntityVillagerTek;
import net.tangotek.tektopia.entities.ai.EntityAIPerformTavern;
import net.tangotek.tektopia.entities.ai.EntityAIPerformWander;
import net.tangotek.tektopia.entities.ai.EntityAIWanderStructure;

public class EntityBard
extends EntityVillagerTek {
    protected static AnimationHandler animHandler = TekVillager.getNewAnimationHandler(EntityBard.class);
    private static final DataParameter<Byte> PERFORMANCE = EntityDataManager.createKey(EntityBard.class, (DataSerializer)DataSerializers.BYTE);
    private static final DataParameter<Boolean> PERFORM_WANDER = EntityDataManager.createKey(EntityBard.class, (DataSerializer)DataSerializers.BOOLEAN);
    private static final DataParameter<Boolean> PERFORM_TAVERN = EntityDataManager.createKey(EntityBard.class, (DataSerializer)DataSerializers.BOOLEAN);
    private int lastPerformanceTick = 0;

    public EntityBard(World worldIn) {
        super(worldIn, ProfessionType.BARD, VillagerRole.VILLAGER.value);
    }

    @Override
    public AnimationHandler getAnimationHandler() {
        return animHandler;
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        this.registerAIFilter("perform_wander", PERFORM_WANDER);
        this.registerAIFilter("perform_tavern", PERFORM_TAVERN);
        this.dataManager.register(PERFORMANCE, (byte)0);
    }

    @Override
    protected void initEntityAI() {
        super.initEntityAI();
        this.tasks.addTask(50, (EntityAIBase)new EntityAIPerformTavern(this));
        this.tasks.addTask(50, (EntityAIBase)new EntityAIPerformWander(this));
    }

    @Override
    protected void addTask(int priority, EntityAIBase task) {
        if (task instanceof EntityAIWanderStructure) {
            return;
        }
        super.addTask(priority, task);
    }

    public boolean isPerforming() {
        return (Byte)this.dataManager.get(PERFORMANCE) != 0;
    }

    public ModSoundEvents.Performance getPerformance() {
        Byte perf = (Byte)this.dataManager.get(PERFORMANCE);
        return ModSoundEvents.Performance.valueOf(perf);
    }

    public void setPerformance(ModSoundEvents.Performance perf) {
        if (perf == null) {
            this.dataManager.set(PERFORMANCE, (byte)0);
            this.lastPerformanceTick = this.ticksExisted;
        } else {
            this.dataManager.set(PERFORMANCE, perf.id);
        }
    }

    @Override
    protected boolean wantsTavern() {
        return this.hasTavern();
    }

    public int timeSincePerformance() {
        return this.ticksExisted - this.lastPerformanceTick;
    }

    public void onUpdate() {
        super.onUpdate();
    }

    static {
        animHandler.addAnim("tektopia", "villager_flute_1", "bard_m", true);
        EntityVillagerTek.setupAnimations(animHandler, "bard_m");
    }
}

