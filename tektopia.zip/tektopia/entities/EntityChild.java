/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.leviathanstudio.craftstudio.common.animation.AnimationHandler
 *  javax.annotation.Nullable
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.IEntityLivingData
 *  net.minecraft.entity.ai.EntityAIBase
 *  net.minecraft.item.ItemStack
 *  net.minecraft.nbt.NBTTagCompound
 *  net.minecraft.network.datasync.DataParameter
 *  net.minecraft.network.datasync.DataSerializer
 *  net.minecraft.network.datasync.DataSerializers
 *  net.minecraft.network.datasync.EntityDataManager
 *  net.minecraft.util.SoundEvent
 *  net.minecraft.world.DifficultyInstance
 *  net.minecraft.world.World
 */
package net.tangotek.tektopia.entities;

import com.leviathanstudio.craftstudio.common.animation.AnimationHandler;
import javax.annotation.Nullable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializer;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.SoundEvent;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.World;
import net.tangotek.tektopia.ProfessionType;
import net.tangotek.tektopia.TekVillager;
import net.tangotek.tektopia.Village;
import net.tangotek.tektopia.VillagerRole;
import net.tangotek.tektopia.entities.EntityNitwit;
import net.tangotek.tektopia.entities.EntityVillagerTek;
import net.tangotek.tektopia.entities.ai.EntityAIGenericMove;
import net.tangotek.tektopia.entities.ai.EntityAIPlayTag;
import net.tangotek.tektopia.entities.ai.EntityAIReadBook;
import net.tangotek.tektopia.entities.ai.EntityAISchoolAttend;
import net.tangotek.tektopia.structures.VillageStructure;
import net.tangotek.tektopia.structures.VillageStructureType;

public class EntityChild
extends EntityVillagerTek {
    protected static AnimationHandler animHandler = TekVillager.getNewAnimationHandler(EntityChild.class);
    private static final DataParameter<Byte> VARIATION = EntityDataManager.createKey(EntityChild.class, (DataSerializer)DataSerializers.BYTE);
    private static final DataParameter<Boolean> PLAY_TAG = EntityDataManager.createKey(EntityChild.class, (DataSerializer)DataSerializers.BOOLEAN);
    private static final DataParameter<Boolean> ATTEND_SCHOOL = EntityDataManager.createKey(EntityChild.class, (DataSerializer)DataSerializers.BOOLEAN);
    protected EntityChild chasedBy = null;
    protected boolean attendedSchoolToday = false;
    private int daysForAdult;

    public EntityChild(World worldIn) {
        super(worldIn, ProfessionType.CHILD, VillagerRole.VILLAGER.value);
        this.setSize(this.width * 0.5f, this.height * 0.5f);
    }

    @Override
    public AnimationHandler getAnimationHandler() {
        return animHandler;
    }

    @Override
    @Nullable
    public IEntityLivingData onInitialSpawn(DifficultyInstance difficulty, @Nullable IEntityLivingData livingdata) {
        this.setVariation((byte)this.rand.nextInt(2));
        return super.onInitialSpawn(difficulty, livingdata);
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        this.dataManager.register(VARIATION, ((byte)this.rand.nextInt(2)));
        this.registerAIFilter("play_tag", PLAY_TAG);
        this.registerAIFilter("attend_school", ATTEND_SCHOOL);
        this.removeAIFilter("visit_tavern");
    }

    @Override
    protected void initEntityAI() {
        super.initEntityAI();
        this.daysForAdult = 4 + this.getRNG().nextInt(2);
        this.addTask(50, new EntityAISchoolAttend(this, p -> p.isWorkTime() && this.needsSchoolToday()));
        this.addTask(50, new EntityAIPlayTag(this));
        this.addTask(50, new EntityAIGenericMove(this, p -> p.isWorkTime() && p.hasVillage() && p.getRNG().nextInt(2) == 0, v -> this.village.getLastVillagerPos(), EntityVillagerTek.MovementMode.SKIP, null, null));
        this.addTask(50, new EntityAIGenericMove(this, p -> p.isWorkTime() && p.hasVillage(), v -> this.village.getLastVillagerPos(), EntityVillagerTek.MovementMode.WALK, null, null));
    }

    @Override
    protected void onNewDay() {
        super.onNewDay();
        this.checkGrowAdult();
    }

    @Override
    public void attachToVillage(Village v) {
        super.attachToVillage(v);
        this.sleepOffset = this.genOffset(400) - 1200;
    }

    @Override
    protected void setupServerJobs() {
        super.setupServerJobs();
    }

    @Override
    protected void addTask(int priority, EntityAIBase task) {
        if (task instanceof EntityAIReadBook) {
            return;
        }
        super.addTask(priority, task);
    }

    protected void setVariation(Byte v) {
        this.dataManager.set(VARIATION, v);
    }

    public Byte getVariation() {
        return (byte)((Byte)this.dataManager.get(VARIATION));
    }

    @Override
    public void onStartSleep(int sleepAxis) {
        super.onStartSleep(sleepAxis);
        this.attendedSchoolToday = false;
    }

    @Override
    public void onStartSit(int sitAxis) {
        VillageStructure curStruct = this.getCurrentStructure();
        if (curStruct != null && curStruct.type == VillageStructureType.SCHOOL) {
            this.attendedSchoolToday = true;
        }
        super.onStartSit(sitAxis);
    }

    @Override
    public double getSitOffset() {
        return 0.24;
    }

    public boolean needsSchoolToday() {
        return !this.attendedSchoolToday;
    }

    public boolean isChild() {
        return true;
    }

    @Override
    public boolean canConvertProfession(ProfessionType pt) {
        return false;
    }

    public float getEyeHeight() {
        return 0.87f;
    }

    @Override
    protected boolean wantsTavern() {
        return false;
    }

    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();
    }

    @Override
    protected boolean canVillagerPickupItem(ItemStack itemIn) {
        return super.canVillagerPickupItem(itemIn);
    }

    @Override
    protected void cleanUpInventory() {
        super.cleanUpInventory();
    }

    protected void checkGrowAdult() {
        if (this.daysAlive >= this.daysForAdult) {
            EntityNitwit villager = new EntityNitwit(this.world);
            villager.setLocationAndAngles(this.posX, this.posY, this.posZ, 0.0f, 0.0f);
            villager.onInitialSpawn(this.world.getDifficultyForLocation(this.getPosition()), null);
            villager.cloneFrom(this);
            this.world.spawnEntity((Entity)villager);
        }
    }

    @Override
    public float getAIMoveSpeed() {
        return super.getAIMoveSpeed() * 0.75f;
    }

    public void setChasedBy(EntityChild child) {
        this.chasedBy = child;
    }

    public EntityChild getChasedBy() {
        return this.chasedBy;
    }

    @Override
    public boolean isFleeFrom(Entity e) {
        return e == this.chasedBy || super.isFleeFrom(e);
    }

    @Override
    public void playSound(SoundEvent soundEvent) {
        this.playSound(soundEvent, this.getRNG().nextFloat() * 0.4f + 0.8f, this.getRNG().nextFloat() * 0.4f + 1.1f);
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound compound) {
        super.writeEntityToNBT(compound);
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound compound) {
        super.readEntityFromNBT(compound);
    }

    static {
        animHandler.addAnim("tektopia", "villager_skip", "child_m", true);
        animHandler.addAnim("tektopia", "villager_sit_raise", "child_m", false);
        EntityVillagerTek.setupAnimations(animHandler, "child_m");
    }
}

