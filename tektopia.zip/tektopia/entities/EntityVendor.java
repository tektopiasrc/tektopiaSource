/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.block.Block
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.IMerchant
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.Blocks
 *  net.minecraft.init.Items
 *  net.minecraft.init.SoundEvents
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.text.ITextComponent
 *  net.minecraft.util.text.TextComponentTranslation
 *  net.minecraft.village.MerchantRecipe
 *  net.minecraft.village.MerchantRecipeList
 *  net.minecraft.world.World
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 */
package net.tangotek.tektopia.entities;

import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IMerchant;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.village.MerchantRecipe;
import net.minecraft.village.MerchantRecipeList;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.tangotek.tektopia.ProfessionType;
import net.tangotek.tektopia.VillagerRole;
import net.tangotek.tektopia.entities.EntityVillagerTek;
import net.tangotek.tektopia.entities.ai.EntityAIWanderStructure;
import net.tangotek.tektopia.tickjob.TickJob;

public abstract class EntityVendor
extends EntityVillagerTek
implements IMerchant {
    @Nullable
    protected EntityPlayer buyingPlayer;
    @Nullable
    protected MerchantRecipeList buyingList;

    public EntityVendor(World worldIn, int roleMask) {
        super(worldIn, null, roleMask | VillagerRole.VENDOR.value);
    }

    @Override
    protected void setupServerJobs() {
        super.setupServerJobs();
        this.addJob(new TickJob(200, 200, true, () -> {
            if (this.getCurrentStructure() == null) {
                this.setDead();
            }
        }));
    }

    @Override
    public boolean isMale() {
        return true;
    }

    @Override
    protected void initEntityAIBase() {
    }

    @Override
    protected void initEntityAI() {
        super.initEntityAI();
        this.addTask(50, new EntityAIWanderStructure(this, p -> p.getCurrentStructure(), p -> p.getRNG().nextInt(5) == 0, 0));
    }

    protected ItemStack createEmerald(int qty) {
        return new ItemStack(Items.EMERALD, qty);
    }

    protected MerchantRecipe createMerchantRecipe(ItemStack item, int emeraldCost) {
        if (emeraldCost <= 64) {
            return new MerchantRecipe(this.createEmerald(emeraldCost), ItemStack.EMPTY, item, 0, 99999);
        }
        if (emeraldCost % 9 == 0) {
            return new MerchantRecipe(new ItemStack(Item.getItemFromBlock((Block)Blocks.EMERALD_BLOCK), emeraldCost / 9), ItemStack.EMPTY, item, 0, 99999);
        }
        return new MerchantRecipe(new ItemStack(Item.getItemFromBlock((Block)Blocks.EMERALD_BLOCK), emeraldCost / 9), this.createEmerald(emeraldCost % 9), item, 0, 99999);
    }

    @Override
    public boolean canConvertProfession(ProfessionType pt) {
        return false;
    }

    @Override
    public void addVillagerPosition() {
    }

    public void setCustomer(@Nullable EntityPlayer player) {
        this.buyingPlayer = player;
        this.buyingList = null;
    }

    @Nullable
    public EntityPlayer getCustomer() {
        return this.buyingPlayer;
    }

    public boolean isTrading() {
        return this.buyingPlayer != null;
    }

    @Override
    public boolean isSleepingTime() {
        return false;
    }

    @Override
    protected void bedCheck() {
    }

    @Override
    public int getHunger() {
        return this.getMaxHunger();
    }

    @Nullable
    public MerchantRecipeList getRecipes(EntityPlayer player) {
        if (this.buyingList == null) {
            this.populateBuyingList();
        }
        return this.buyingList;
    }

    @Override
    public boolean processInteract(EntityPlayer player, EnumHand hand) {
        boolean flag;
        ItemStack itemstack = player.getHeldItem(hand);
        boolean bl = flag = itemstack.getItem() == Items.NAME_TAG;
        if (flag) {
            itemstack.interactWithEntity(player, (EntityLivingBase)this, hand);
        } else if (this.isEntityAlive() && !this.isTrading() && !this.isChild() && !player.isSneaking()) {
            if (this.buyingList == null) {
                this.populateBuyingList();
            }
            if (this.buyingList != null) {
                if (!this.world.isRemote && !this.buyingList.isEmpty()) {
                    this.setCustomer(player);
                    this.getNavigator().clearPath();
                    player.displayVillagerTradeGui((IMerchant)this);
                } else if (this.buyingList.isEmpty()) {
                    return super.processInteract(player, hand);
                }
            }
        }
        return true;
    }

    protected abstract void populateBuyingList();

    @SideOnly(value=Side.CLIENT)
    public void setRecipes(@Nullable MerchantRecipeList recipeList) {
    }

    public World getWorld() {
        return this.world;
    }

    public void useRecipe(MerchantRecipe recipe) {
        recipe.incrementToolUses();
        this.livingSoundTime = -this.getTalkInterval();
        this.playSound(SoundEvents.ENTITY_VILLAGER_YES, this.getSoundVolume(), this.getSoundPitch());
        this.setHappy(this.getMaxHappy());
    }

    public void verifySellingItem(ItemStack stack) {
        if (!this.world.isRemote && this.livingSoundTime > -this.getTalkInterval() + 20) {
            this.livingSoundTime = -this.getTalkInterval();
            this.playSound(stack.isEmpty() ? SoundEvents.ENTITY_VILLAGER_NO : SoundEvents.ENTITY_VILLAGER_YES, this.getSoundVolume(), this.getSoundPitch());
        }
    }

    protected abstract String getTranslationKey();

    public ITextComponent getDisplayName() {
        TextComponentTranslation itextcomponent = new TextComponentTranslation(this.getTranslationKey(), new Object[0]);
        itextcomponent.getStyle().setHoverEvent(this.getHoverEvent());
        itextcomponent.getStyle().setInsertion(this.getCachedUniqueIdString());
        return itextcomponent;
    }

    public BlockPos getPos() {
        return new BlockPos((Entity)this);
    }
}

