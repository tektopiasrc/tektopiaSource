/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.leviathanstudio.craftstudio.common.animation.AnimationHandler
 *  net.minecraft.block.Block
 *  net.minecraft.init.Blocks
 *  net.minecraft.init.Items
 *  net.minecraft.item.EnumDyeColor
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.network.datasync.DataParameter
 *  net.minecraft.network.datasync.DataSerializer
 *  net.minecraft.network.datasync.DataSerializers
 *  net.minecraft.network.datasync.EntityDataManager
 *  net.minecraft.world.World
 */
package net.tangotek.tektopia.entities;

import com.leviathanstudio.craftstudio.common.animation.AnimationHandler;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.function.Predicate;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializer;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.world.World;
import net.tangotek.tektopia.ItemTagType;
import net.tangotek.tektopia.ModItems;
import net.tangotek.tektopia.ProfessionType;
import net.tangotek.tektopia.TekVillager;
import net.tangotek.tektopia.VillagerRole;
import net.tangotek.tektopia.entities.EntityVillagerTek;
import net.tangotek.tektopia.entities.ai.EntityAICraftItems;
import net.tangotek.tektopia.entities.ai.EntityAIEmptyFurnace;
import net.tangotek.tektopia.entities.ai.EntityAISmelting;
import net.tangotek.tektopia.entities.crafting.Recipe;
import net.tangotek.tektopia.storage.ItemDesire;
import net.tangotek.tektopia.structures.VillageStructureType;

public class EntityChef
extends EntityVillagerTek {
    protected static AnimationHandler animHandler = TekVillager.getNewAnimationHandler(EntityChef.class);
    private static final DataParameter<Boolean> COOK_BEEF = EntityDataManager.createKey(EntityChef.class, (DataSerializer)DataSerializers.BOOLEAN);
    private static final DataParameter<Boolean> COOK_MUTTON = EntityDataManager.createKey(EntityChef.class, (DataSerializer)DataSerializers.BOOLEAN);
    private static final DataParameter<Boolean> COOK_CHICKEN = EntityDataManager.createKey(EntityChef.class, (DataSerializer)DataSerializers.BOOLEAN);
    private static final DataParameter<Boolean> COOK_PORK = EntityDataManager.createKey(EntityChef.class, (DataSerializer)DataSerializers.BOOLEAN);
    private static final DataParameter<Boolean> COOK_POTATO = EntityDataManager.createKey(EntityChef.class, (DataSerializer)DataSerializers.BOOLEAN);
    private static final DataParameter<Boolean> SMELT_CHARCOAL = EntityDataManager.createKey(EntityChef.class, (DataSerializer)DataSerializers.BOOLEAN);
    private static List<Recipe> craftSet = EntityChef.buildCraftSet();
    private static final Map<String, DataParameter<Boolean>> RECIPE_PARAMS = new HashMap<String, DataParameter<Boolean>>();

    public EntityChef(World worldIn) {
        super(worldIn, ProfessionType.CHEF, VillagerRole.VILLAGER.value);
    }

    @Override
    public AnimationHandler getAnimationHandler() {
        return animHandler;
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        this.registerAIFilter("cook_beef", COOK_BEEF);
        this.registerAIFilter("cook_pork", COOK_PORK);
        this.registerAIFilter("cook_mutton", COOK_MUTTON);
        this.registerAIFilter("cook_chicken", COOK_CHICKEN);
        this.registerAIFilter("cook_potato", COOK_POTATO);
        this.registerAIFilter("smelt_charcoal", SMELT_CHARCOAL);
        craftSet.forEach(r -> this.registerAIFilter(r.getAiFilter(), RECIPE_PARAMS.get(r.getAiFilter())));
    }

    @Override
    protected void initEntityAI() {
        super.initEntityAI();
        this.getDesireSet().addItemDesire(new ItemDesire("Fuel", EntityAISmelting.getBestFuel(), 1, 6, 10, null));
        this.getDesireSet().addItemDesire(new ItemDesire(Blocks.LOG, 0, 4, 8, p -> p.isAIFilterEnabled("smelt_charcoal")));
        this.getDesireSet().addItemDesire(new ItemDesire("Cookable", EntityChef.bestCookable(this), 0, this.getSkillLerp(ProfessionType.CHEF, 1, 3) * 8, 0, null));
        craftSet.forEach(r -> this.getDesireSet().addRecipeDesire((Recipe)r));
        this.addTask(50, new EntityAIEmptyFurnace(this, VillageStructureType.KITCHEN, EntityChef.takeFromFurnace()));
        this.addTask(50, new EntityAISmelting((EntityVillagerTek)this, VillageStructureType.KITCHEN, p -> !EntityChef.hasCoal(p, 1) && p.isAIFilterEnabled("smelt_charcoal"), p -> p.getItem() == Item.getItemFromBlock((Block)Blocks.LOG) ? 1 : 0, () -> this.tryAddSkill(ProfessionType.CHEF, 10)));
        this.addTask(50, new EntityAISmelting((EntityVillagerTek)this, VillageStructureType.KITCHEN, p -> true, EntityChef.bestCookable(this), () -> this.tryAddSkill(ProfessionType.CHEF, 3)));
        this.addTask(50, new EntityAICraftItems(this, craftSet, "villager_cook", null, 80, VillageStructureType.KITCHEN, Blocks.CRAFTING_TABLE, p -> p.isWorkTime()));
    }

    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();
    }

    private static List<Recipe> buildCraftSet() {
        ArrayList<Recipe> recipes = new ArrayList<Recipe>();
        ArrayList<ItemStack> ingredients = new ArrayList<ItemStack>();
        ingredients.add(new ItemStack(Items.GOLD_INGOT, 8));
        ingredients.add(new ItemStack(Items.APPLE, 1));
        Recipe recipe = new Recipe(ProfessionType.CHEF, "craft_golden_apple", 2, new ItemStack(Items.GOLDEN_APPLE, 1), ingredients, 1, 1, v -> v.getSkillLerp(ProfessionType.CHEF, 7, 2), 16);
        recipes.add(recipe);
        ingredients = new ArrayList();
        ingredients.add(new ItemStack(Items.GOLD_INGOT, 1));
        ingredients.add(new ItemStack(Items.CARROT, 1));
        recipe = new Recipe(ProfessionType.CHEF, "craft_golden_carrot", 2, new ItemStack(Items.GOLDEN_CARROT, 1), ingredients, 3, 3, v -> v.getSkillLerp(ProfessionType.CHEF, 7, 2), 16);
        recipes.add(recipe);
        ingredients = new ArrayList();
        ingredients.add(new ItemStack(Items.BEETROOT, 6));
        ingredients.add(new ItemStack(Items.BOWL, 1));
        recipe = new Recipe(ProfessionType.CHEF, "craft_beetroot_soup", 2, new ItemStack(Items.BEETROOT_SOUP, 1), ingredients, 2, 3, v -> v.getSkillLerp(ProfessionType.CHEF, 7, 2), 15);
        recipes.add(recipe);
        ingredients = new ArrayList();
        ingredients.add(new ItemStack(Items.MILK_BUCKET, 3));
        ingredients.add(new ItemStack(Items.SUGAR, 2));
        ingredients.add(new ItemStack(Items.EGG, 1));
        ingredients.add(new ItemStack(Items.WHEAT, 3));
        recipe = new Recipe(ProfessionType.CHEF, "craft_cake", 1, new ItemStack(Items.CAKE, 1), ingredients, 1, 1, v -> v.getSkillLerp(ProfessionType.CHEF, 10, 5), 1){

            @Override
            public ItemStack craft(EntityVillagerTek villager) {
                List<ItemStack> items = villager.getInventory().getItems((Predicate<ItemStack>) p -> p.getItem() == Items.MILK_BUCKET, 3);
                int villagerMilks = (int)items.stream().filter(itemStack -> ModItems.isTaggedItem(itemStack, ItemTagType.VILLAGER)).count();
                ItemStack result = super.craft(villager);
                if (result != null) {
                    int nonVillagerMilks = 3 - villagerMilks;
                    if (villagerMilks > 0) {
                        villager.getInventory().addItem(ModItems.makeTaggedItem(new ItemStack(Items.BUCKET, villagerMilks), ItemTagType.VILLAGER));
                    }
                    if (nonVillagerMilks > 0) {
                        villager.getInventory().addItem(new ItemStack(Items.BUCKET, nonVillagerMilks));
                    }
                }
                return result;
            }
        };
        recipes.add(recipe);
        ingredients = new ArrayList();
        ingredients.add(new ItemStack(Items.WHEAT, 3));
        recipe = new Recipe(ProfessionType.CHEF, "craft_bread", 6, new ItemStack(Items.BREAD, 1), ingredients, 3, 5, v -> v.getSkillLerp(ProfessionType.CHEF, 5, 2), 32);
        recipes.add(recipe);
        ingredients = new ArrayList();
        ingredients.add(new ItemStack(Item.getItemFromBlock((Block)Blocks.LOG), 1, 99));
        Predicate<EntityVillagerTek> pred = v -> !Recipe.hasPersonalGoal(v, new ItemStack(Items.BOWL, 3));
        Recipe recipe2 = new Recipe(ProfessionType.CHEF, "craft_wooden_bowl", 10, new ItemStack(Items.BOWL, 1), ingredients, 3, 3, v -> v.getSkillLerp(ProfessionType.CHEF, 5, 1), 3, pred);
        recipes.add(recipe2);
        ingredients = new ArrayList();
        ingredients.add(new ItemStack(Items.REEDS, 1));
        pred = v -> !Recipe.hasPersonalGoal(v, new ItemStack(Items.SUGAR, 6));
        recipe2 = new Recipe(ProfessionType.CHEF, "craft_sugar", 15, new ItemStack(Items.SUGAR, 1), ingredients, 3, 4, v -> v.getSkillLerp(ProfessionType.CHEF, 3, 1), 32, pred);
        recipes.add(recipe2);
        ingredients = new ArrayList();
        ingredients.add(new ItemStack(Item.getItemFromBlock((Block)Blocks.PUMPKIN), 1));
        ingredients.add(new ItemStack(Items.SUGAR, 1));
        ingredients.add(new ItemStack(Items.EGG, 1));
        recipe = new Recipe(ProfessionType.CHEF, "craft_pumpkin_pie", 2, new ItemStack(Items.PUMPKIN_PIE, 1), ingredients, 3, 4, v -> v.getSkillLerp(ProfessionType.CHEF, 9, 4), 1);
        recipes.add(recipe);
        ingredients = new ArrayList();
        ingredients.add(new ItemStack(Items.WHEAT, 2));
        ingredients.add(new ItemStack(Items.DYE, 1, EnumDyeColor.BROWN.getDyeDamage()));
        recipe = new Recipe(ProfessionType.CHEF, "craft_cookie", 4, new ItemStack(Items.COOKIE, 1), ingredients, 3, 3, v -> v.getSkillLerp(ProfessionType.CHEF, 6, 2), 3);
        recipes.add(recipe);
        return recipes;
    }

    private static Predicate<ItemStack> takeFromFurnace() {
        return p -> EntityChef.isCooked().test((ItemStack)p) || p.getItem() == Items.COAL;
    }

    private static Predicate<ItemStack> isCooked() {
        return p -> p.getItem() == Items.COOKED_CHICKEN || p.getItem() == Items.COOKED_BEEF || p.getItem() == Items.COOKED_MUTTON || p.getItem() == Items.COOKED_PORKCHOP || p.getItem() == Items.BAKED_POTATO;
    }

    protected static boolean hasCoal(EntityVillagerTek villager, int req) {
        int count = villager.getInventory().getItemCount(EntityChef.isCoal());
        return count >= req;
    }

    public static Predicate<ItemStack> isCoal() {
        return p -> p.getItem() == Items.COAL;
    }

    private static Function<ItemStack, Integer> bestCookable(EntityVillagerTek villager) {
        return p -> {
            if (p.getItem() == Items.BEEF && villager.isAIFilterEnabled("cook_beef")) {
                return EntityVillagerTek.foodItemValue(null).apply(Items.COOKED_BEEF);
            }
            if (p.getItem() == Items.PORKCHOP && villager.isAIFilterEnabled("cook_pork")) {
                return EntityVillagerTek.foodItemValue(null).apply(Items.COOKED_PORKCHOP);
            }
            if (p.getItem() == Items.CHICKEN && villager.isAIFilterEnabled("cook_chicken")) {
                return EntityVillagerTek.foodItemValue(null).apply(Items.COOKED_CHICKEN);
            }
            if (p.getItem() == Items.MUTTON && villager.isAIFilterEnabled("cook_mutton")) {
                return EntityVillagerTek.foodItemValue(null).apply(Items.COOKED_MUTTON);
            }
            if (p.getItem() == Items.POTATO && villager.isAIFilterEnabled("cook_potato")) {
                return EntityVillagerTek.foodItemValue(null).apply(Items.BAKED_POTATO);
            }
            return -1;
        };
    }

    static {
        craftSet.forEach(r -> RECIPE_PARAMS.put(r.getAiFilter(), (DataParameter<Boolean>)EntityDataManager.createKey(EntityChef.class, (DataSerializer)DataSerializers.BOOLEAN)));
        animHandler.addAnim("tektopia", "villager_take", "chef_m", false);
        animHandler.addAnim("tektopia", "villager_cook", "chef_m", false);
        EntityVillagerTek.setupAnimations(animHandler, "chef_m");
    }
}

