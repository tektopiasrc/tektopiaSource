/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.ai.EntityAIBase
 *  net.minecraft.init.Items
 *  net.minecraft.init.MobEffects
 *  net.minecraft.item.ItemStack
 *  net.minecraft.potion.PotionEffect
 */
package net.tangotek.tektopia.entities.ai;

import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.init.Items;
import net.minecraft.init.MobEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.tangotek.tektopia.ItemTagType;
import net.tangotek.tektopia.ModItems;
import net.tangotek.tektopia.entities.EntityVillagerTek;

import java.util.function.Predicate;

public class EntityAIEatGoldenApple
extends EntityAIBase {
    private EntityVillagerTek villager;
    private ItemStack foodItem;
    private int eatTime = 0;

    public EntityAIEatGoldenApple(EntityVillagerTek v) {
        this.villager = v;
        this.setMutexBits(1);
    }

    public boolean isInterruptible() {
        return false;
    }

    public boolean shouldExecute() {
        if (this.villager.isAITick() && this.villager.getHealth() < this.villager.getMaxHealth() / 2.0f && this.villager.isAIFilterEnabled("eat_golden_apple")) {
            this.foodItem = this.villager.getInventory().getItem(p -> p.getItem() == Items.GOLDEN_APPLE && ModItems.isTaggedItem(p, ItemTagType.VILLAGER) ? 1 : 0);
            if (!this.foodItem.isEmpty()) {
                return true;
            }
        }
        return false;
    }

    public void startExecuting() {
        this.startEat();
        super.startExecuting();
    }

    public boolean shouldContinueExecuting() {
        return this.eatTime >= 0;
    }

    public void updateTask() {
        --this.eatTime;
        if (this.eatTime == 0 && !this.villager.getInventory().removeItems((Predicate<ItemStack>) p -> ItemStack.areItemStacksEqual((ItemStack)p, (ItemStack)this.foodItem), 1).isEmpty()) {
            this.foodItem.shrink(1);
            this.villager.addPotionEffect(new PotionEffect(MobEffects.REGENERATION, 200, 1));
            this.villager.addPotionEffect(new PotionEffect(MobEffects.ABSORPTION, 2400, 0));
        }
        super.updateTask();
    }

    private void startEat() {
        this.eatTime = 80;
        this.villager.getNavigator().clearPath();
        this.villager.equipActionItem(this.foodItem);
        this.villager.playServerAnimation("villager_eat");
    }

    private void stopEat() {
        this.villager.unequipActionItem(this.foodItem);
        this.villager.stopServerAnimation("villager_eat");
    }

    public void resetTask() {
        super.resetTask();
        this.stopEat();
        this.foodItem = null;
        this.eatTime = 0;
    }
}

