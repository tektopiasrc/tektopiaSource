/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.BlockHorizontal
 *  net.minecraft.block.properties.IProperty
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.world.IBlockAccess
 */
package net.tangotek.tektopia.entities.ai;

import net.minecraft.block.BlockHorizontal;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.IBlockAccess;
import net.tangotek.tektopia.entities.EntityVillagerTek;
import net.tangotek.tektopia.entities.ai.EntityAIMoveToBlock;

public class EntityAISleep
extends EntityAIMoveToBlock {
    private int bedAxis = -1;
    protected final EntityVillagerTek villager;
    private boolean hasSleptToday = false;

    public EntityAISleep(EntityVillagerTek v) {
        super(v);
        this.villager = v;
    }

    @Override
    protected BlockPos getDestinationBlock() {
        if (this.villager.getBedPos() != null) {
            if (this.isWalkable(this.villager.getBedPos().up(), this.navigator)) {
                return this.villager.getBedPos().up();
            }
            return this.villager.getBedPos();
        }
        return null;
    }

    @Override
    public boolean shouldExecute() {
        if (this.villager.isAITick()) {
            if (!this.villager.isSleepingTime()) {
                this.hasSleptToday = false;
            }
            if (this.villager.hasVillage() && this.villager.getVillage().enemySeenRecently()) {
                return false;
            }
            if (this.villager.shouldSleep()) {
                this.bedAxis = this.getBedAxis();
                if (this.bedAxis >= 0) {
                    if (!this.hasSleptToday) {
                        return super.shouldExecute();
                    }
                    this.villager.setThought(EntityVillagerTek.VillagerThought.INSOMNIA);
                } else {
                    this.villager.setThought(EntityVillagerTek.VillagerThought.BED);
                }
            }
        }
        return false;
    }

    @Override
    public void startExecuting() {
        super.startExecuting();
    }

    @Override
    public boolean shouldContinueExecuting() {
        if (!this.villager.shouldSleep()) {
            return false;
        }
        if (this.villager.isSleeping() && this.bedAxis < 0) {
            return false;
        }
        if (this.hasArrived()) {
            return this.villager.isSleeping();
        }
        return super.shouldContinueExecuting();
    }

    @Override
    void updateMovementMode() {
        this.villager.setMovementMode(this.villager.getDefaultMovement());
    }

    @Override
    public void updateTask() {
        if (this.villager.isSleeping()) {
            this.hasSleptToday = true;
            if (this.villager.getRNG().nextInt(1200) == 0) {
                this.villager.heal(1.0f);
            }
            if (this.villager.getRNG().nextInt(30) == 0) {
                this.startSleep();
            }
        }
        super.updateTask();
    }

    @Override
    protected BlockPos findWalkPos() {
        return this.destinationPos;
    }

    private int getBedAxis() {
        if (this.villager.getBedPos() != null) {
            EnumFacing enumfacing;
            IBlockState state = this.villager.world.isBlockLoaded(this.villager.getBedPos()) ? this.villager.world.getBlockState(this.villager.getBedPos()) : null;
            boolean isBed = state != null && state.getBlock().isBed(state, (IBlockAccess)this.villager.world, this.villager.getBedPos(), null);
            EnumFacing enumFacing = enumfacing = isBed && state.getBlock() instanceof BlockHorizontal ? (EnumFacing)state.getValue((IProperty)BlockHorizontal.FACING) : null;
            if (enumfacing != null) {
                return enumfacing.getHorizontalIndex();
            }
        }
        return -1;
    }

    private Vec3d getSleepPos() {
        BlockPos bp = this.villager.getBedPos().up();
        return new Vec3d((double)bp.getX() + 0.5, (double)bp.getY() - 0.3, (double)bp.getZ() + 0.5);
    }

    private void moveToSleepPos() {
        Vec3d sleepPos = this.getSleepPos();
        if (this.villager.getPositionVector().squareDistanceTo(sleepPos.x, sleepPos.y, sleepPos.z) > 0.05) {
            this.villager.setLocationAndAngles(sleepPos.x, sleepPos.y, sleepPos.z, this.villager.rotationYaw, this.villager.rotationPitch);
            this.villager.motionX = 0.0;
            this.villager.motionY = 0.0;
            this.villager.motionZ = 0.0;
        }
    }

    @Override
    protected void onArrival() {
        this.startSleep();
        super.onArrival();
    }

    private void startSleep() {
        this.bedAxis = this.getBedAxis();
        if (this.bedAxis >= 0) {
            this.moveToSleepPos();
            this.villager.onStartSleep(this.bedAxis);
        }
    }

    @Override
    public void resetTask() {
        this.villager.onStopSleep();
        this.bedAxis = -1;
        super.resetTask();
    }
}

