/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.ai.EntityAIBase
 *  net.minecraft.pathfinding.Path
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.util.math.Vec3i
 */
package net.tangotek.tektopia.entities.ai;

import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.pathfinding.Path;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;
import net.tangotek.tektopia.VillageManager;
import net.tangotek.tektopia.entities.EntityVillageNavigator;
import net.tangotek.tektopia.pathing.BasePathingNode;
import net.tangotek.tektopia.pathing.PathNavigateVillager2;
import net.tangotek.tektopia.structures.VillageStructure;

public abstract class EntityAIMoveToBlock
extends EntityAIBase {
    private static int STUCK_TIME = 40;
    protected EntityVillageNavigator navigator;
    private BlockPos walkPos;
    protected BlockPos destinationPos;
    private int pathUpdateTick = 20;
    private boolean arrived = false;
    private int stuckCheck = STUCK_TIME;
    private Vec3d stuckPos = Vec3d.ZERO;
    private boolean stuck = false;
    private int lastPathIndex = -1;
    private Vec3d lastNodePos;

    public EntityAIMoveToBlock(EntityVillageNavigator v) {
        this.navigator = v;
        this.setMutexBits(1);
    }

    protected abstract BlockPos getDestinationBlock();

    protected void onArrival() {
    }

    public boolean shouldExecute() {
        if (this.navigator.hasVillage() && this.navigator.getNavigator() instanceof PathNavigateVillager2 && this.canNavigate()) {
            this.destinationPos = this.getDestinationBlock();
            if (this.destinationPos != null) {
                this.stuck = false;
                this.stuckPos = new Vec3d(0.0, -400.0, 0.0);
                this.arrived = false;
                this.pathUpdateTick = 40;
                this.doMove();
                return !this.stuck;
            }
        }
        return false;
    }

    protected boolean isNearWalkPos() {
        return this.walkPos != null && this.walkPos.distanceSq((Vec3i)this.navigator.getPosition()) <= 1.0;
    }

    protected boolean isNearDestination(double range) {
        return this.destinationPos.distanceSq((Vec3i)this.navigator.getPosition()) < range * range;
    }

    protected boolean canNavigate() {
        return this.navigator.onGround;
    }

    public void startExecuting() {
        this.updateMovementMode();
    }

    public boolean shouldContinueExecuting() {
        return !this.arrived && !this.stuck && this.navigator.canNavigate();
    }

    protected void updateFacing() {
        if (!this.arrived) {
            if (!this.navigator.getNavigator().noPath()) {
                Vec3d lookPos = this.navigator.getNavigator().getPath().getCurrentPos();
                this.navigator.faceLocation(lookPos.x, lookPos.z, 4.0f);
            }
        } else if (this.destinationPos != null) {
            // empty if block
        }
    }

    abstract void updateMovementMode();

    public void updateTask() {
        --this.pathUpdateTick;
        if (this.pathUpdateTick <= 0 && !this.arrived) {
            this.pathUpdateTick = 40;
            this.navigator.updateMovement(this.arrived);
        }
        if (!this.arrived && this.isNearWalkPos()) {
            this.arrived = true;
            this.navigator.getNavigator().clearPath();
            this.onArrival();
        }
        this.updateFacing();
        if (!this.arrived) {
            if (this.navigator.getNavigator().noPath()) {
                this.doMove();
            } else {
                int pathIndex = this.navigator.getNavigator().getPath().getCurrentPathIndex();
                if (this.lastPathIndex != pathIndex) {
                    this.lastNodePos = this.navigator.getNavigator().getPath().getCurrentPos();
                    this.lastPathIndex = pathIndex;
                }
            }
            --this.stuckCheck;
            if (this.stuckCheck < 0) {
                this.stuckCheck = STUCK_TIME;
                if (!this.navigator.getNavigator().noPath()) {
                    this.stuck = this.navigator.getPositionVector().squareDistanceTo(this.stuckPos) < 1.0;
                    this.stuckPos = this.navigator.getPositionVector();
                } else {
                    this.navigator.debugOut("has no path?");
                }
            }
            if (this.stuck) {
                if (this.attemptStuckFix() && this.lastPathIndex >= 0) {
                    this.navigator.getNavigator().clearPath();
                    this.doMove();
                } else {
                    this.onStuck();
                }
            }
        }
    }

    protected boolean attemptStuckFix() {
        return false;
    }

    protected void onStuck() {
        VillageManager.get(this.navigator.world).submitStuck(this.navigator.getPosition());
        Path path = this.navigator.getNavigator().getPath();
        if (path != null && this.navigator.hasVillage() && this.navigator.getNavigator() instanceof PathNavigateVillager2) {
            PathNavigateVillager2 pathNavigateVillager2 = (PathNavigateVillager2)this.navigator.getNavigator();
        }
        this.navigator.getNavigator().clearPath();
    }

    protected void onPathFailed(BlockPos pos) {
        VillageManager.get(this.navigator.world).submitStuck(this.navigator.getPosition());
        this.stuck = true;
    }

    public BlockPos getWalkPos() {
        return this.walkPos;
    }

    protected BlockPos findWalkPos() {
        BlockPos pos = this.destinationPos;
        BlockPos diff = this.navigator.getPosition().subtract((Vec3i)pos);
        EnumFacing facing = EnumFacing.getFacingFromVector((float)diff.getX(), (float)0.0f, (float)diff.getZ());
        BlockPos testPos = pos.offset(facing);
        if (this.isWalkable(testPos, this.navigator)) {
            return testPos;
        }
        testPos = pos.offset(facing).offset(facing.rotateY());
        if (this.isWalkable(testPos, this.navigator)) {
            return testPos;
        }
        testPos = pos.offset(facing).offset(facing.rotateYCCW());
        if (this.isWalkable(testPos, this.navigator)) {
            return testPos;
        }
        testPos = pos.offset(facing.rotateY());
        if (this.isWalkable(testPos, this.navigator)) {
            return testPos;
        }
        testPos = pos.offset(facing.rotateYCCW());
        if (this.isWalkable(testPos, this.navigator)) {
            return testPos;
        }
        testPos = pos.offset(facing.getOpposite());
        if (this.isWalkable(testPos, this.navigator)) {
            return testPos;
        }
        testPos = pos.offset(facing.getOpposite()).offset(facing.rotateY());
        if (this.isWalkable(testPos, this.navigator)) {
            return testPos;
        }
        testPos = pos.offset(facing.getOpposite()).offset(facing.rotateYCCW());
        if (this.isWalkable(testPos, this.navigator)) {
            return testPos;
        }
        if (this.isWalkable(pos, this.navigator)) {
            return pos;
        }
        return null;
    }

    protected boolean isWalkable(BlockPos pos, EntityVillageNavigator nav) {
        BasePathingNode baseNode;
        if (nav.getVillage() != null && (baseNode = nav.getVillage().getPathingGraph().getBaseNode(pos.getX(), pos.getY(), pos.getZ())) != null) {
            return !VillageStructure.isWoodDoor(nav.world, pos) && !VillageStructure.isGate(nav.world, pos);
        }
        return false;
    }

    protected void doMove() {
        this.arrived = false;
        this.stuckCheck = STUCK_TIME;
        this.walkPos = this.findWalkPos();
        if (this.walkPos == null) {
            this.stuck = true;
        } else if (!this.isNearWalkPos() && this.canNavigate()) {
            boolean pathFound = this.navigator.getNavigator().tryMoveToXYZ((double)this.walkPos.getX(), (double)this.walkPos.getY(), (double)this.walkPos.getZ(), (double)this.navigator.getAIMoveSpeed());
            if (pathFound) {
                this.navigator.getLookHelper().setLookPosition((double)this.walkPos.getX(), (double)this.walkPos.getY(), (double)this.walkPos.getZ(), 50.0f, (float)this.navigator.getVerticalFaceSpeed());
            } else {
                this.onPathFailed(this.walkPos);
            }
        }
    }

    protected boolean hasArrived() {
        return this.arrived;
    }

    protected void setArrived() {
        this.arrived = true;
    }

    public void resetTask() {
        super.resetTask();
        this.arrived = false;
        this.stuckCheck = STUCK_TIME;
        this.navigator.resetMovement();
    }
}

