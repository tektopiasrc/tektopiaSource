/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.init.Blocks
 *  net.minecraft.init.Items
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.math.BlockPos
 */
package net.tangotek.tektopia.entities.ai;

import java.util.List;
import java.util.function.Predicate;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.tangotek.tektopia.ProfessionType;
import net.tangotek.tektopia.entities.EntityFarmer;
import net.tangotek.tektopia.entities.EntityVillagerTek;
import net.tangotek.tektopia.entities.ai.EntityAIMoveToBlock;

public class EntityAITillDirt
extends EntityAIMoveToBlock {
    private boolean active = false;
    private int hoeTime = 0;
    private ItemStack bestTool;
    protected final EntityVillagerTek villager;

    public EntityAITillDirt(EntityVillagerTek entityIn, Predicate<EntityVillagerTek> shouldPred) {
        super(entityIn);
        this.villager = entityIn;
    }

    @Override
    protected BlockPos getDestinationBlock() {
        BlockPos cropPos;
        if (this.villager.getVillage() != null && (cropPos = this.villager.getVillage().requestFarmland(block -> this.canTill((BlockPos)block))) != null) {
            return cropPos.up();
        }
        return null;
    }

    @Override
    public boolean shouldExecute() {
        if (this.villager.isAITick() && this.villager.hasVillage() && this.villager.isWorkTime() && this.villager.isAIFilterEnabled("till_dirt")) {
            List<ItemStack> toolList = this.villager.getInventory().getItems(EntityFarmer.getBestHoe(), 1);
            if (!toolList.isEmpty()) {
                this.bestTool = toolList.get(0);
                return super.shouldExecute();
            }
            this.villager.setThought(EntityVillagerTek.VillagerThought.HOE);
            this.bestTool = null;
        }
        return false;
    }

    @Override
    public void startExecuting() {
        this.active = true;
        super.startExecuting();
    }

    @Override
    public boolean shouldContinueExecuting() {
        return this.active;
    }

    @Override
    void updateMovementMode() {
        this.villager.setMovementMode(this.villager.getDefaultMovement());
    }

    @Override
    public void updateTask() {
        super.updateTask();
        if (this.hoeTime > 0) {
            --this.hoeTime;
            if (this.hoeTime == 10) {
                this.stopHoeing();
                if (this.canTill(this.destinationPos.down())) {
                    this.villager.world.setBlockState(this.destinationPos.down(), Blocks.FARMLAND.getDefaultState(), 3);
                    this.villager.world.setBlockToAir(this.destinationPos);
                }
                this.villager.tryAddSkill(ProfessionType.FARMER, 14);
                this.villager.damageItem(this.bestTool, 3);
                this.villager.modifyHunger(-2);
            } else if (this.hoeTime <= 0) {
                this.active = false;
                this.villager.throttledSadness(-3);
            }
        }
    }

    @Override
    protected BlockPos findWalkPos() {
        return this.destinationPos;
    }

    @Override
    protected void onStuck() {
        this.active = false;
        super.onStuck();
    }

    @Override
    protected void onArrival() {
        this.startHoeing();
        super.onArrival();
    }

    private boolean canTill(BlockPos bp) {
        Block block = this.villager.world.getBlockState(bp).getBlock();
        if (block == Blocks.DIRT || block == Blocks.GRASS) {
            return this.villager.world.isAirBlock(bp.up());
        }
        return false;
    }

    private void startHoeing() {
        if (this.canTill(this.destinationPos.down())) {
            int reductionTime = 38 * this.villager.getSkillLerp(ProfessionType.FARMER, 0, 3);
            this.hoeTime = 250 - reductionTime;
            if (this.bestTool.getItem() == Items.WOODEN_HOE) {
                this.hoeTime += 40;
            }
            this.villager.getNavigator().clearPath();
            this.villager.playServerAnimation("villager_hoe");
            this.villager.equipActionItem(this.bestTool);
        } else {
            this.active = false;
        }
    }

    private void stopHoeing() {
        this.villager.stopServerAnimation("villager_hoe");
        this.villager.unequipActionItem();
    }

    @Override
    public void resetTask() {
        super.resetTask();
        this.active = false;
        this.hoeTime = 0;
        this.stopHoeing();
    }
}

