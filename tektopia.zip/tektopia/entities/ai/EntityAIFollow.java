/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.util.math.Vec3i
 */
package net.tangotek.tektopia.entities.ai;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;
import net.tangotek.tektopia.entities.EntityVillageNavigator;
import net.tangotek.tektopia.entities.ai.EntityAIMoveToBlock;

public abstract class EntityAIFollow
extends EntityAIMoveToBlock {
    protected EntityLivingBase followTarget;
    protected BlockPos lastTargetPos;
    protected int followUpdateTick = 40;
    protected final EntityVillageNavigator navigator;

    public EntityAIFollow(EntityVillageNavigator entityIn) {
        super(entityIn);
        this.navigator = entityIn;
    }

    @Override
    protected BlockPos getDestinationBlock() {
        BlockPos pos = this.followTarget.getPosition();
        if (this.isWalkable(pos, this.navigator)) {
            return pos;
        }
        Vec3d diff = this.followTarget.getPositionVector().subtract(new Vec3d((double)pos.getX() + 0.5, (double)pos.getY(), (double)pos.getZ() + 0.5));
        BlockPos xOffset = pos.add(Math.signum(diff.x), 0.0, 0.0);
        if (this.isWalkable(xOffset, this.navigator)) {
            return xOffset;
        }
        BlockPos zOffset = pos.add(0.0, 0.0, Math.signum(diff.z));
        if (this.isWalkable(zOffset, this.navigator)) {
            return zOffset;
        }
        BlockPos bothOffset = pos.add(Math.signum(diff.x), 0.0, Math.signum(diff.z));
        if (this.isWalkable(bothOffset, this.navigator)) {
            return bothOffset;
        }
        return pos;
    }

    @Override
    public boolean shouldExecute() {
        if (this.navigator.hasVillage()) {
            this.followTarget = this.getFollowTarget();
            if (this.followTarget == null) {
                return false;
            }
            if (!this.shouldFollow()) {
                return false;
            }
            return super.shouldExecute();
        }
        return false;
    }

    @Override
    public void startExecuting() {
        this.updateFollowTick();
        super.startExecuting();
    }

    @Override
    protected boolean isNearWalkPos() {
        return this.getWalkPos() != null && this.getWalkPos().distanceSq((Vec3i)this.navigator.getPosition()) < 2.5;
    }

    @Override
    public boolean shouldContinueExecuting() {
        if (!this.shouldFollow()) {
            return false;
        }
        return super.shouldContinueExecuting();
    }

    @Override
    public void updateTask() {
        --this.followUpdateTick;
        if (this.shouldFollow()) {
            if (this.followUpdateTick <= 0) {
                this.updateFollowTick();
                this.doMove();
            } else if (this.followTarget.getDistanceSq(this.lastTargetPos) > 25.0) {
                this.doMove();
            }
        }
        this.navigator.faceEntity((Entity)this.followTarget, 60.0f, 40.0f);
        super.updateTask();
    }

    protected abstract EntityLivingBase getFollowTarget();

    @Override
    protected void doMove() {
        this.destinationPos = this.getDestinationBlock();
        super.doMove();
        this.lastTargetPos = this.followTarget.getPosition();
    }

    @Override
    public void resetTask() {
        this.followTarget = null;
        super.resetTask();
    }

    protected boolean shouldFollow() {
        return this.followTarget.isEntityAlive();
    }

    private void updateFollowTick() {
        double distSq = this.followTarget.getDistanceSq((Entity)this.navigator);
        this.followUpdateTick = distSq < 100.0 ? 10 : (distSq < 400.0 ? 40 : 60);
    }
}

