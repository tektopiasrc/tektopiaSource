/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.BlockHorizontal
 *  net.minecraft.block.properties.IProperty
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.util.math.Vec3i
 */
package net.tangotek.tektopia.entities.ai;

import java.util.function.Function;
import java.util.function.Predicate;
import net.minecraft.block.BlockHorizontal;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;
import net.tangotek.tektopia.entities.EntityVillagerTek;
import net.tangotek.tektopia.entities.ai.EntityAIMoveToBlock;
import net.tangotek.tektopia.structures.VillageStructure;

public class EntityAIWanderStructure
extends EntityAIMoveToBlock {
    private final int happyChance;
    private final Function<EntityVillagerTek, VillageStructure> wanderFunc;
    private BlockPos chairPos;
    private int sitTime = 0;
    private boolean forceExecute = false;
    private VillageStructure structure;
    protected final EntityVillagerTek villager;
    private final Predicate<EntityVillagerTek> shouldPred;

    public EntityAIWanderStructure(EntityVillagerTek v, Function<EntityVillagerTek, VillageStructure> whereFunc, Predicate<EntityVillagerTek> shouldPred, int happyChance) {
        super(v);
        this.villager = v;
        this.shouldPred = shouldPred;
        this.happyChance = happyChance;
        this.wanderFunc = whereFunc;
    }

    @Override
    public boolean shouldExecute() {
        if (this.villager.isAITick() && this.villager.hasVillage() && this.shouldPred.test(this.villager) && this.villager.getRNG().nextInt(2) == 0) {
            return super.shouldExecute();
        }
        return false;
    }

    @Override
    public boolean shouldContinueExecuting() {
        if (this.sitTime > 0) {
            return true;
        }
        return super.shouldContinueExecuting();
    }

    @Override
    void updateMovementMode() {
        this.villager.setMovementMode(this.villager.getDefaultMovement());
    }

    @Override
    public void startExecuting() {
        this.forceExecute = false;
        super.startExecuting();
    }

    @Override
    protected BlockPos findWalkPos() {
        return this.destinationPos;
    }

    @Override
    protected boolean isNearWalkPos() {
        if (this.chairPos != null) {
            return this.chairPos != null && this.chairPos.distanceSq((Vec3i)this.villager.getPosition()) <= 1.0;
        }
        return super.isNearWalkPos();
    }

    @Override
    protected BlockPos getDestinationBlock() {
        this.structure = this.wanderFunc.apply(this.villager);
        if (this.structure != null) {
            this.chairPos = this.structure.tryVillagerSit(this.villager);
            if (this.chairPos != null) {
                return this.chairPos;
            }
            BlockPos pos = this.structure.getRandomFloorTile();
            if (pos != null) {
                return pos;
            }
        }
        return null;
    }

    @Override
    public void updateTask() {
        if (this.sitTime > 0) {
            --this.sitTime;
            if (this.sitTime % 10 == 0) {
                this.moveToSitPos();
                if (this.villager.getRNG().nextInt(120) == 0) {
                    this.villager.modifyHappy(1);
                }
            }
        }
        super.updateTask();
    }

    @Override
    protected void onArrival() {
        if (this.chairPos != null) {
            this.sitTime = this.structure.getSitTime(this.villager);
            this.startSit();
            this.testHappy(3);
        } else {
            this.testHappy(2);
        }
        super.onArrival();
    }

    private void testHappy(int happyVal) {
        if (this.happyChance > 0 && this.villager.getRNG().nextInt(this.happyChance) == 0) {
            this.villager.modifyHappy(happyVal);
        }
    }

    private EnumFacing getChairFacing() {
        if (this.chairPos != null && this.villager.world.isBlockLoaded(this.chairPos)) {
            IBlockState state = this.villager.world.getBlockState(this.chairPos);
            EnumFacing enumfacing = state.getBlock() instanceof BlockHorizontal ? ((EnumFacing)state.getValue((IProperty)BlockHorizontal.FACING)).getOpposite() : null;
            return enumfacing;
        }
        return null;
    }

    private int getChairAxis() {
        EnumFacing facing = this.getChairFacing();
        if (facing != null) {
            return facing.getHorizontalIndex();
        }
        return -1;
    }

    private void startSit() {
        int chairAxis = this.getChairAxis();
        if (chairAxis >= 0) {
            this.moveToSitPos();
            this.villager.onStartSit(chairAxis);
        }
    }

    private Vec3d getSitPos() {
        return new Vec3d((double)this.destinationPos.getX() + 0.5, (double)this.destinationPos.getY() + this.villager.getSitOffset(), (double)this.destinationPos.getZ() + 0.5);
    }

    private void moveTo(Vec3d pos) {
        this.villager.setLocationAndAngles(pos.x, pos.y, pos.z, this.villager.rotationYaw, this.villager.rotationPitch);
        this.villager.motionX = 0.0;
        this.villager.motionY = 0.0;
        this.villager.motionZ = 0.0;
    }

    private void moveToSitPos() {
        Vec3d sitPos = this.getSitPos();
        if (this.villager.getPositionVector().squareDistanceTo(sitPos.x, sitPos.y, sitPos.z) > 0.05) {
            this.moveTo(sitPos);
        }
    }

    @Override
    public void resetTask() {
        if (this.chairPos != null && this.structure != null) {
            this.structure.vacateSpecialBlock(this.chairPos);
        }
        this.villager.onStopSit();
        this.sitTime = 0;
        super.resetTask();
    }
}

