/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.ai.EntityAIBase
 *  net.minecraft.entity.monster.EntityMob
 *  net.minecraft.entity.monster.EntityZombie
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.MathHelper
 */
package net.tangotek.tektopia.entities.ai;

import java.util.List;
import java.util.Random;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.tangotek.tektopia.ModSoundEvents;
import net.tangotek.tektopia.entities.EntityNecromancer;

public class EntityAISummonUndead
extends EntityAIBase {
    private EntityNecromancer necro;
    private int summonTime = 0;
    private int cooldownTick = 0;
    protected final int checkInterval;
    private BlockPos summonPos;
    private final int MAX_SUMMONS = 50;
    private int summonCount = 0;

    public EntityAISummonUndead(EntityNecromancer necro, int checkInterval) {
        this.checkInterval = checkInterval;
        this.necro = necro;
        this.setMutexBits(1);
    }

    public boolean shouldExecute() {
        List zombs;
        if (this.necro.isAITick() && this.isSummonReady(this.necro) && this.necro.getMinions().size() < this.necro.getMaxSummons() && (zombs = this.necro.world.getEntitiesWithinAABB(EntityZombie.class, this.necro.getEntityBoundingBox().grow(30.0, 10.0, 30.0))).size() < this.necro.getLevel() * 2) {
            this.summonPos = this.findSummonPos(this.necro.getNavigator().noPath() ? 2.0f : 10.0f);
            return this.summonPos != null;
        }
        return false;
    }

    private boolean isSummonReady(EntityNecromancer necro) {
        if (this.summonCount >= 50) {
            return false;
        }
        if (this.necro.getMinions().size() < 1) {
            return true;
        }
        return this.necro.ticksExisted > this.cooldownTick && (this.necro.getMinions().size() < 1 || this.necro.getRNG().nextInt(this.checkInterval) == 0);
    }

    public void startExecuting() {
        this.necro.getNavigator().clearPath();
        this.startSummoning();
        super.startExecuting();
    }

    public boolean shouldContinueExecuting() {
        return this.summonTime > 0;
    }

    public void updateTask() {
        if (this.summonTime > 0) {
            this.necro.faceLocation(this.summonPos.getX(), this.summonPos.getZ(), 100.0f);
            --this.summonTime;
            if (this.summonTime == 12) {
                this.spawnMinion();
            }
        }
    }

    public boolean isInterruptible() {
        return false;
    }

    private BlockPos findSummonPos(float forwardDist) {
        float distance = forwardDist;
        float f1 = MathHelper.sin((float)(this.necro.rotationYaw * ((float)Math.PI / 180)));
        float f2 = MathHelper.cos((float)(this.necro.rotationYaw * ((float)Math.PI / 180)));
        double behindX = -distance * f1;
        double behindZ = distance * f2;
        BlockPos testPos = new BlockPos(this.necro.posX + behindX, this.necro.posY, this.necro.posZ + behindZ);
        EntityZombie zombie = new EntityZombie(this.necro.world);
        int searchBoxXZ = 8;
        for (int l = 0; l < 50; ++l) {
            int k1;
            int j1;
            int i1 = testPos.getX() + MathHelper.getInt((Random)this.necro.world.rand, (int)(-searchBoxXZ), (int)searchBoxXZ);
            BlockPos bp = new BlockPos(i1, j1 = testPos.getY() + MathHelper.getInt((Random)this.necro.world.rand, (int)-5, (int)5), k1 = testPos.getZ() + MathHelper.getInt((Random)this.necro.world.rand, (int)(-searchBoxXZ), (int)searchBoxXZ));
            if (!this.necro.world.isSideSolid(bp.down(), EnumFacing.UP)) continue;
            zombie.setPosition((double)i1 + 0.5, (double)j1, (double)k1 + 0.5);
            if (!zombie.isNotColliding() || this.necro.hasVillage() && this.necro.getVillage().isInStructure(bp)) continue;
            return bp;
        }
        return null;
    }

    private void startSummoning() {
        this.necro.debugOut("Summoning undead minion [ " + this.summonPos + "] Starting");
        this.summonTime = 47;
        this.necro.playServerAnimation("necro_summon");
        this.necro.playSound(ModSoundEvents.deathSummon, this.necro.getRNG().nextFloat() * 0.2f + 1.2f, this.necro.getRNG().nextFloat() * 0.2f + 0.9f);
    }

    private void stopSummoning() {
        this.necro.debugOut("Summoning complete [ " + this.summonPos + "] Starting");
        this.necro.stopServerAnimation("necro_summon");
    }

    private void spawnMinion() {
        Entity minion = this.necro.getLevel() == 5 && this.necro.getRNG().nextBoolean() ? this.necro.createWitherSkeleton(this.summonPos) : (this.necro.getLevel() == 4 && this.necro.getRNG().nextInt(4) == 0 ? this.necro.createWitherSkeleton(this.summonPos) : this.necro.createZombie(this.summonPos));
        this.necro.world.spawnEntity((Entity)minion);
        this.necro.addMinion((EntityMob)minion);
        minion.playSound(ModSoundEvents.deathSummonTarget, this.necro.getRNG().nextFloat() * 0.4f + 0.8f, this.necro.getRNG().nextFloat() * 0.4f + 0.8f);
        ++this.summonCount;
        this.necro.playSound(ModSoundEvents.deathSummonEnd);
        this.cooldownTick = this.necro.ticksExisted + this.necro.getLevelCooldown(MathHelper.getInt((Random)this.necro.getRNG(), (int)30, (int)50) + this.necro.getMinions().size() * 20);
    }

    public void resetTask() {
        this.summonTime = 0;
        this.stopSummoning();
        super.resetTask();
    }
}

