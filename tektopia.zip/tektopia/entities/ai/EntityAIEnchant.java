/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.enchantment.EnchantmentData
 *  net.minecraft.enchantment.EnchantmentHelper
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.item.EntityItem
 *  net.minecraft.init.Items
 *  net.minecraft.item.ItemEnchantedBook
 *  net.minecraft.item.ItemStack
 */
package net.tangotek.tektopia.entities.ai;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.function.Predicate;
import net.minecraft.block.Block;
import net.minecraft.enchantment.EnchantmentData;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.init.Items;
import net.minecraft.item.ItemEnchantedBook;
import net.minecraft.item.ItemStack;
import net.tangotek.tektopia.ItemTagType;
import net.tangotek.tektopia.ModItems;
import net.tangotek.tektopia.ProfessionType;
import net.tangotek.tektopia.entities.EntityEnchanter;
import net.tangotek.tektopia.entities.EntityVillagerTek;
import net.tangotek.tektopia.entities.ai.EntityAICraftItems;
import net.tangotek.tektopia.entities.crafting.Recipe;
import net.tangotek.tektopia.structures.VillageStructureType;
import net.tangotek.tektopia.tickjob.TickJob;

public class EntityAIEnchant
extends EntityAICraftItems {
    private EntityItem floatingItem;

    public EntityAIEnchant(EntityVillagerTek v, List<Recipe> recipes, String anim, ItemStack heldItem, int craftTime, VillageStructureType structureType, Block machineBlock, Predicate<EntityVillagerTek> shouldPred, int skillChance) {
        super(v, recipes, anim, heldItem, craftTime, structureType, machineBlock, shouldPred);
    }

    @Override
    public void startExecuting() {
        super.startExecuting();
    }

    @Override
    public void updateTask() {
        super.updateTask();
        if (this.floatingItem != null) {
            this.floatingItem.rotationYaw += 1.0f;
            this.floatingItem.prevRotationYaw = this.floatingItem.rotationYaw;
            this.floatingItem.motionY = 0.0;
        }
    }

    @Override
    protected ItemStack craftItem(EntityVillagerTek villager) {
        ItemStack enchantedItem = super.craftItem(villager);
        if (enchantedItem != null && enchantedItem.isItemEnchanted()) {
            boolean wasVillagerItem = ModItems.isTaggedItem(enchantedItem, ItemTagType.VILLAGER);
            int enchantLevel = 5 + villager.getSkillLerp(ProfessionType.ENCHANTER, 1, 30);
            if (!wasVillagerItem) {
                enchantLevel = Math.max(1, enchantLevel / 5);
            }
            boolean isBook = false;
            List<EnchantmentData> list = new ArrayList();
            enchantedItem = new ItemStack(enchantedItem.getItem(), 1, enchantedItem.getMetadata());
            for (int i = 0; i < 10; ++i) {
                if (enchantedItem.getItem() == Items.ENCHANTED_BOOK) {
                    list = EnchantmentHelper.buildEnchantmentList((Random)villager.getRNG(), (ItemStack)new ItemStack(Items.BOOK, 1, enchantedItem.getMetadata()), (int)enchantLevel, (boolean)true);
                    isBook = true;
                } else {
                    list = EnchantmentHelper.buildEnchantmentList((Random)villager.getRNG(), (ItemStack)enchantedItem, (int)enchantLevel, (boolean)true);
                }
                list.removeIf(e -> e.enchantment.isCurse());
                if (!list.isEmpty()) break;
            }
            for (EnchantmentData enchantmentdata : list) {
                if (isBook) {
                    ItemEnchantedBook.addEnchantment((ItemStack)enchantedItem, (EnchantmentData)enchantmentdata);
                    continue;
                }
                enchantedItem.addEnchantment(enchantmentdata.enchantment, enchantmentdata.enchantmentLevel);
            }
            if (wasVillagerItem) {
                ModItems.makeTaggedItem(enchantedItem, ItemTagType.VILLAGER);
            }
        }
        return enchantedItem;
    }

    @Override
    public boolean shouldExecute() {
        return super.shouldExecute();
    }

    @Override
    protected void onArrival() {
        super.onArrival();
        this.clearFloater();
        this.floatingItem = new EntityItem(this.villager.world, (double)this.destinationPos.getX() + 0.5, (double)this.destinationPos.getY() + 1.6, (double)this.destinationPos.getZ() + 0.5, this.activeRecipe.getProduct().copy());
        this.floatingItem.setNoGravity(true);
        this.floatingItem.lifespan = 6000;
        this.floatingItem.setInfinitePickupDelay();
        this.floatingItem.motionX = 0.0;
        this.floatingItem.motionY = 0.0;
        this.floatingItem.motionZ = 0.0;
        this.villager.addJob(new TickJob(16, 0, false, () -> {
            if (this.floatingItem != null) {
                this.villager.world.spawnEntity((Entity)this.floatingItem);
            }
        }));
    }

    private void clearFloater() {
        if (this.floatingItem != null) {
            this.floatingItem.setDead();
            this.floatingItem = null;
        }
    }

    @Override
    protected void startCraft() {
        super.startCraft();
        if (this.villager instanceof EntityEnchanter) {
            EntityEnchanter enchanter = (EntityEnchanter)this.villager;
            enchanter.setCasting(this.destinationPos);
        }
    }

    @Override
    protected void stopCraft() {
        super.stopCraft();
        if (this.villager instanceof EntityEnchanter) {
            EntityEnchanter enchanter = (EntityEnchanter)this.villager;
            enchanter.setCasting(null);
        }
    }

    @Override
    public void resetTask() {
        this.clearFloater();
        super.resetTask();
    }
}

