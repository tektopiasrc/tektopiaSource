/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.item.ItemStack
 *  net.minecraft.tileentity.TileEntity
 *  net.minecraft.tileentity.TileEntityChest
 *  net.minecraft.util.EntitySelectors
 *  net.minecraft.util.math.BlockPos
 */
package net.tangotek.tektopia.entities.ai;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.util.EntitySelectors;
import net.minecraft.util.math.BlockPos;
import net.tangotek.tektopia.entities.EntityVillagerTek;
import net.tangotek.tektopia.entities.ai.EntityAIMoveToBlock;

public class EntityAIDeliverToStorage2
extends EntityAIMoveToBlock {
    private TileEntityChest chest;
    private int dropOffTick = -1;
    private ItemStack itemCarryingCopy;
    private EntityVillagerTek villager;
    private int deliveryId = 0;

    public EntityAIDeliverToStorage2(EntityVillagerTek v) {
        super(v);
        this.villager = v;
    }

    @Override
    protected BlockPos getDestinationBlock() {
        if (this.villager.hasVillage() && !this.itemCarryingCopy.isEmpty()) {
            this.chest = this.villager.getVillage().getAvailableStorageChest(this.itemCarryingCopy, this.villager.getPosition());
            if (this.chest != null) {
                return this.chest.getPos();
            }
        }
        return null;
    }

    @Override
    public boolean shouldExecute() {
        if ((this.villager.isAITick() || this.villager.isStoragePriority()) && this.villager.isDeliveryTime()) {
            this.deliveryId = this.villager.getDesireSet().getDeliveryId(this.villager, this.villager.isStoragePriority() ? 1 : 3);
            if (this.deliveryId > 0) {
                this.itemCarryingCopy = this.villager.getDesireSet().getDeliveryItemCopy(this.villager);
                return super.shouldExecute();
            }
        }
        return false;
    }

    @Override
    public boolean shouldContinueExecuting() {
        if (this.dropOffTick >= 0) {
            return true;
        }
        if (!this.villager.getDesireSet().isDeliveryMatch(this.deliveryId)) {
            return false;
        }
        return super.shouldContinueExecuting();
    }

    @Override
    protected BlockPos findWalkPos() {
        BlockPos result = super.findWalkPos();
        if (result == null) {
            BlockPos pos = this.destinationPos;
            BlockPos testPos = pos.west(2);
            if (this.isWalkable(testPos, this.navigator)) {
                return testPos;
            }
            testPos = pos.east(2);
            if (this.isWalkable(testPos, this.navigator)) {
                return testPos;
            }
            testPos = pos.north(2);
            if (this.isWalkable(testPos, this.navigator)) {
                return testPos;
            }
            testPos = pos.south(2);
            if (this.isWalkable(testPos, this.navigator)) {
                return testPos;
            }
        }
        return result;
    }

    @Override
    void updateMovementMode() {
        this.villager.setMovementMode(this.villager.getDefaultMovement());
    }

    @Override
    public void startExecuting() {
        super.startExecuting();
        if (this.itemCarryingCopy != null) {
            this.villager.equipActionItem(this.itemCarryingCopy);
        }
    }

    public boolean isInterruptible() {
        return this.dropOffTick <= 0;
    }

    @Override
    public void updateTask() {
        super.updateTask();
        --this.dropOffTick;
        if (this.dropOffTick == 0) {
            this.dropOffItems();
            this.villager.throttledSadness(-1);
            this.closeChest();
            this.dropOffTick = -1;
        }
    }

    @Override
    public void resetTask() {
        this.dropOffTick = -1;
        this.deliveryId = 0;
        super.resetTask();
        if (this.itemCarryingCopy != null) {
            this.villager.unequipActionItem(this.itemCarryingCopy);
            this.itemCarryingCopy = null;
            this.villager.setStoragePriority();
        }
    }

    @Override
    protected void onArrival() {
        super.onArrival();
        this.dropOffTick = 30;
        this.openChest();
    }

    protected void dropOffItems() {
        if (this.isNearDestination(5.0) && !this.chest.isInvalid()) {
            this.villager.setStoragePriority();
            if (!this.villager.getDesireSet().deliverItems(this.villager, this.chest, this.deliveryId)) {
                this.villager.getDesireSet().forceUpdate();
            }
        }
    }

    private void openChest() {
        TileEntity te = this.villager.world.getTileEntity(this.destinationPos);
        if (te instanceof TileEntityChest) {
            TileEntityChest tileEntityChest = (TileEntityChest)te;
            EntityPlayer p = this.villager.world.getClosestPlayer((double)this.destinationPos.getX(), (double)this.destinationPos.getY(), (double)this.destinationPos.getZ(), -1.0, EntitySelectors.NOT_SPECTATING);
            if (p != null) {
                tileEntityChest.openInventory(p);
            }
        }
    }

    private void closeChest() {
        TileEntity te = this.villager.world.getTileEntity(this.destinationPos);
        if (te instanceof TileEntityChest) {
            TileEntityChest tileEntityChest = (TileEntityChest)te;
            EntityPlayer p = this.villager.world.getClosestPlayer((double)this.destinationPos.getX(), (double)this.destinationPos.getY(), (double)this.destinationPos.getZ(), -1.0, EntitySelectors.NOT_SPECTATING);
            if (p != null) {
                tileEntityChest.closeInventory(p);
            }
        }
    }
}

