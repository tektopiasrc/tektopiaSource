/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Predicate
 *  com.google.common.base.Predicates
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.util.EntitySelectors
 *  net.minecraft.util.math.BlockPos
 */
package net.tangotek.tektopia.entities.ai;

import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.EntitySelectors;
import net.minecraft.util.math.BlockPos;
import net.tangotek.tektopia.entities.EntityChild;
import net.tangotek.tektopia.entities.EntityVillagerTek;
import net.tangotek.tektopia.entities.ai.EntityAIFollow;

public class EntityAIPlayTag
extends EntityAIFollow {
    protected EntityChild targetChild = null;
    protected EntityChild thisChild = null;
    protected EntityChild preferredTarget = null;
    private boolean active = false;
    protected final Predicate<Entity> canChase;
    protected final EntityVillagerTek villager;
    private int activeTick = 0;

    public EntityAIPlayTag(EntityVillagerTek v) {
        super(v);
        this.villager = v;
        Predicate<Entity> isChasable = e -> e.isEntityAlive() && e instanceof EntityChild;
        this.canChase = Predicates.and((Predicate)EntitySelectors.CAN_AI_TARGET, (Predicate)isChasable);
        if (this.villager instanceof EntityChild) {
            this.thisChild = (EntityChild)this.villager;
        }
    }

    @Override
    public boolean shouldExecute() {
        if (this.villager.isAITick("play_tag") && this.villager.hasVillage() && this.villager.isWorkTime() && this.thisChild != null) {
            if (this.thisChild.getChasedBy() != null) {
                this.preferredTarget = this.thisChild.getChasedBy();
            } else {
                this.targetChild = this.seekChaseTarget();
                if (this.targetChild != null) {
                    return super.shouldExecute();
                }
            }
        }
        return false;
    }

    @Override
    protected EntityLivingBase getFollowTarget() {
        return this.targetChild;
    }

    private EntityChild seekChaseTarget() {
        List children;
        EntityChild result = null;
        if (this.preferredTarget != null) {
            if (this.canChase.test(this.preferredTarget) && this.thisChild.getDistanceSq((Entity)this.preferredTarget) < 256.0) {
                result = this.preferredTarget;
            }
            this.preferredTarget = null;
        }
        if (result == null && !(children = this.villager.world.getEntitiesInAABBexcluding((Entity)this.villager, this.villager.getEntityBoundingBox().grow(16.0), this.canChase)).isEmpty()) {
            return (EntityChild)(children.get(this.villager.world.rand.nextInt(children.size())));
        }
        return result;
    }

    @Override
    public void startExecuting() {
        this.active = true;
        this.activeTick = this.villager.world.rand.nextInt(100) + 80;
        this.villager.setMovementMode(EntityVillagerTek.MovementMode.RUN);
        this.targetChild.setChasedBy((EntityChild)this.villager);
        if (this.villager.getRNG().nextInt(4) == 0) {
            this.villager.modifyHappy(4);
        }
        super.startExecuting();
    }

    @Override
    public boolean shouldContinueExecuting() {
        return this.targetChild != null && this.active;
    }

    @Override
    void updateMovementMode() {
        this.villager.setMovementMode(EntityVillagerTek.MovementMode.RUN);
    }

    @Override
    public void updateTask() {
        --this.activeTick;
        if (this.activeTick <= 0) {
            this.active = false;
        }
        super.updateTask();
    }

    @Override
    protected void onArrival() {
        super.onArrival();
    }

    @Override
    protected void onStuck() {
        this.active = false;
        super.onStuck();
    }

    @Override
    protected void onPathFailed(BlockPos pos) {
        this.active = false;
        super.onPathFailed(pos);
    }

    @Override
    public void resetTask() {
        this.active = false;
        this.targetChild.setChasedBy(null);
        this.preferredTarget = null;
        this.villager.setMovementMode(this.villager.getDefaultMovement());
        this.targetChild = null;
        super.resetTask();
    }
}

