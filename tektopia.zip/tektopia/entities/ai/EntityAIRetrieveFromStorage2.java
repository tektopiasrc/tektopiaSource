/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.item.ItemStack
 *  net.minecraft.tileentity.TileEntity
 *  net.minecraft.tileentity.TileEntityChest
 *  net.minecraft.util.EntitySelectors
 *  net.minecraft.util.math.BlockPos
 */
package net.tangotek.tektopia.entities.ai;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.util.EntitySelectors;
import net.minecraft.util.math.BlockPos;
import net.tangotek.tektopia.entities.EntityVillagerTek;
import net.tangotek.tektopia.entities.ai.EntityAIMoveToBlock;
import net.tangotek.tektopia.storage.ItemDesire;

public class EntityAIRetrieveFromStorage2
extends EntityAIMoveToBlock {
    private TileEntityChest chest = null;
    protected ItemDesire retrieveDesire = null;
    protected final EntityVillagerTek villager;
    private int pickUpTick = 0;
    protected boolean autoCheck = false;
    protected ItemStack itemTaken = null;

    public EntityAIRetrieveFromStorage2(EntityVillagerTek v) {
        super(v);
        this.villager = v;
    }

    @Override
    protected BlockPos getDestinationBlock() {
        if (this.chest != null) {
            return this.chest.getPos();
        }
        return null;
    }

    @Override
    protected void updateMovementMode() {
        this.villager.setMovementMode(this.villager.getDefaultMovement());
    }

    @Override
    public boolean shouldExecute() {
        if ((this.villager.isAITick() || this.villager.isStoragePriority()) && this.villager.hasVillage()) {
            this.autoCheck = false;
            this.retrieveDesire = this.villager.getDesireSet().getNeededDesire(this.villager);
            if (this.retrieveDesire != null && this.villager.getInventory().hasSlotFree()) {
                this.chest = this.retrieveDesire.getPickUpChest(this.villager);
                if (this.chest != null) {
                    return super.shouldExecute();
                }
            }
        }
        return false;
    }

    public boolean isInterruptible() {
        return this.pickUpTick <= 0;
    }

    @Override
    public void startExecuting() {
        super.startExecuting();
    }

    @Override
    public boolean shouldContinueExecuting() {
        if (this.pickUpTick > 0) {
            return true;
        }
        if (this.chest != this.retrieveDesire.getPickUpChest(this.villager)) {
            return false;
        }
        return super.shouldContinueExecuting();
    }

    @Override
    protected BlockPos findWalkPos() {
        BlockPos result = super.findWalkPos();
        if (result == null) {
            BlockPos pos = this.destinationPos;
            BlockPos testPos = pos.west(2);
            if (this.isWalkable(testPos, this.navigator)) {
                return testPos;
            }
            testPos = pos.east(2);
            if (this.isWalkable(testPos, this.navigator)) {
                return testPos;
            }
            testPos = pos.north(2);
            if (this.isWalkable(testPos, this.navigator)) {
                return testPos;
            }
            testPos = pos.south(2);
            if (this.isWalkable(testPos, this.navigator)) {
                return testPos;
            }
        }
        return result;
    }

    @Override
    public void updateTask() {
        super.updateTask();
        --this.pickUpTick;
        if (this.pickUpTick == 15) {
            this.pickUpItems();
        } else if (this.pickUpTick == 1) {
            this.closeChest();
        }
    }

    @Override
    public void resetTask() {
        this.pickUpTick = 0;
        if (this.itemTaken != null) {
            this.villager.unequipActionItem(this.itemTaken);
            this.itemTaken = null;
            this.villager.setStoragePriority();
        }
        super.resetTask();
    }

    @Override
    protected void onArrival() {
        super.onArrival();
        this.pickUpTick = 30;
        this.openChest();
    }

    protected void pickUpItems() {
        if (this.isNearDestination(5.0) && !this.chest.isInvalid()) {
            this.itemTaken = this.retrieveDesire.pickUpItems(this.villager);
            if (this.itemTaken != ItemStack.EMPTY) {
                this.itemAcquired(this.itemTaken);
            } else {
                this.villager.getDesireSet().forceUpdate();
            }
        }
    }

    protected boolean itemAcquired(ItemStack itemStack) {
        this.autoCheck = true;
        this.villager.setStoragePriority();
        boolean result = this.villager.getInventory().addItem(itemStack) == ItemStack.EMPTY;
        return result;
    }

    private void openChest() {
        TileEntity te = this.villager.world.getTileEntity(this.destinationPos);
        if (te instanceof TileEntityChest) {
            TileEntityChest tileEntityChest = (TileEntityChest)te;
            EntityPlayer p = this.villager.world.playerEntities.stream().filter(EntitySelectors.NOT_SPECTATING).findFirst().orElse(null);
            if (p != null) {
                tileEntityChest.openInventory(p);
            }
        }
    }

    private void closeChest() {
        TileEntity te = this.villager.world.getTileEntity(this.destinationPos);
        if (te instanceof TileEntityChest) {
            TileEntityChest tileEntityChest = (TileEntityChest)te;
            EntityPlayer p = this.villager.world.playerEntities.stream().filter(EntitySelectors.NOT_SPECTATING).findFirst().orElse(null);
            if (p != null) {
                tileEntityChest.closeInventory(p);
            }
        }
    }
}

