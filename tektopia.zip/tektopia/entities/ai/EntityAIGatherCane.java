/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.init.Blocks
 *  net.minecraft.init.Items
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Vec3i
 */
package net.tangotek.tektopia.entities.ai;

import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import net.tangotek.tektopia.ModBlocks;
import net.tangotek.tektopia.ProfessionType;
import net.tangotek.tektopia.blockfinder.SugarCaneScanner;
import net.tangotek.tektopia.entities.EntityVillagerTek;
import net.tangotek.tektopia.entities.ai.EntityAIMoveToBlock;

public class EntityAIGatherCane
extends EntityAIMoveToBlock {
    private final EntityVillagerTek villager;
    private BlockPos targetPos;
    private boolean active = false;
    private int gatherTime = 0;
    private final int maxStorage;

    public EntityAIGatherCane(EntityVillagerTek entityIn, int maxStorage) {
        super(entityIn);
        this.villager = entityIn;
        this.maxStorage = maxStorage;
    }

    @Override
    protected BlockPos getDestinationBlock() {
        if (this.villager.getVillage() != null) {
            this.releaseBlockClaim();
            BlockPos bp = this.villager.getVillage().requestBlock((Block)Blocks.REEDS);
            if (bp != null) {
                this.villager.debugOut("GatherCane start " + bp);
                return bp;
            }
        }
        return null;
    }

    @Override
    protected BlockPos findWalkPos() {
        BlockPos diff = this.villager.getPosition().subtract((Vec3i)this.destinationPos);
        EnumFacing facing = EnumFacing.getFacingFromVector((float)diff.getX(), (float)0.0f, (float)diff.getZ());
        BlockPos focusPos = this.destinationPos.offset(facing);
        if (this.isWalkable(focusPos, this.villager)) {
            return focusPos;
        }
        BlockPos closest = null;
        double minDist = Double.MAX_VALUE;
        for (int x = -1; x <= 1; ++x) {
            for (int z = -1; z <= 1; ++z) {
                double thisDist;
                BlockPos testPos = focusPos.add(x, 0, z);
                if (!this.isWalkable(testPos, this.villager) || !((thisDist = testPos.distanceSq((Vec3i)focusPos)) < minDist)) continue;
                minDist = thisDist;
                closest = testPos;
            }
        }
        return closest;
    }

    @Override
    public boolean shouldExecute() {
        if (this.villager.isAITick() && this.villager.getVillage() != null && this.villager.isWorkTime() && this.villager.getRNG().nextInt(15) == 0 && this.villager.isAIFilterEnabled("gather_cane")) {
            int storageCount = this.villager.getVillage().getStorageCount(p -> p.getItem() == Items.REEDS);
            if (this.maxStorage > 0 && storageCount >= this.maxStorage) {
                return false;
            }
            return super.shouldExecute();
        }
        return false;
    }

    @Override
    public void startExecuting() {
        this.targetPos = this.destinationPos;
        this.active = true;
        super.startExecuting();
    }

    @Override
    public boolean shouldContinueExecuting() {
        return this.active;
    }

    @Override
    void updateMovementMode() {
        this.villager.setMovementMode(this.villager.getDefaultMovement());
    }

    @Override
    public void updateTask() {
        if (this.gatherTime > 0) {
            this.villager.getLookHelper().setLookPosition((double)this.destinationPos.getX(), (double)this.destinationPos.getY(), (double)this.destinationPos.getZ(), 30.0f, 30.0f);
            --this.gatherTime;
            if (this.gatherTime == 10) {
                this.gatherBlock();
            } else if (this.gatherTime == 0) {
                this.villager.pickupItems(4);
                this.active = false;
            }
        } else {
            super.updateTask();
        }
    }

    public boolean isInterruptible() {
        return this.gatherTime <= 0;
    }

    @Override
    protected void onStuck() {
        this.active = false;
        super.onStuck();
    }

    @Override
    protected void onArrival() {
        if (this.isNearDestination(2.5)) {
            this.villager.debugOut("GatherCane [ " + this.targetPos.getX() + ", " + this.targetPos.getZ() + "] Arrived at Destination: " + this.getWalkPos());
            if (SugarCaneScanner.getCaneStalk(this.villager.world, this.targetPos) != null) {
                this.startGathering();
                super.onArrival();
            } else {
                this.villager.debugOut("GatherCane [ " + this.targetPos.getX() + ", " + this.targetPos.getZ() + "] Uhhh.  No cane here?");
                this.active = false;
            }
        }
    }

    @Override
    protected void onPathFailed(BlockPos pos) {
        this.active = false;
        super.onPathFailed(pos);
    }

    private void startGathering() {
        this.villager.debugOut("GatherCane [ " + this.targetPos.getX() + ", " + this.targetPos.getZ() + "] Starting");
        this.gatherTime = 36;
        this.villager.getNavigator().clearPath();
        this.villager.playServerAnimation("villager_take");
    }

    private void stopChopping() {
        this.villager.stopServerAnimation("villager_take");
    }

    private void gatherBlock() {
        int count = 0;
        if (this.isNearDestination(3.0)) {
            BlockPos reedPos = this.targetPos;
            while (SugarCaneScanner.isCane(this.villager.world.getBlockState(reedPos.up()))) {
                reedPos = reedPos.up();
            }
            while (SugarCaneScanner.isCane(this.villager.world.getBlockState(reedPos.down()))) {
                ModBlocks.villagerDestroyBlock(reedPos, this.villager, true, true);
                reedPos = reedPos.down();
                ++count;
            }
            this.villager.tryAddSkill(ProfessionType.FARMER, 9);
            this.villager.throttledSadness(-2);
            this.villager.modifyHunger(-2);
        }
        this.villager.debugOut("GatherCane [ " + this.targetPos.getX() + ", " + this.targetPos.getZ() + "] Chopped: " + count);
    }

    private void releaseBlockClaim() {
        if (this.targetPos != null && this.villager.getVillage() != null) {
            this.villager.getVillage().releaseBlockClaim((Block)Blocks.REEDS, this.targetPos);
            this.targetPos = null;
        }
    }

    @Override
    public void resetTask() {
        this.stopChopping();
        this.releaseBlockClaim();
        super.resetTask();
    }
}

