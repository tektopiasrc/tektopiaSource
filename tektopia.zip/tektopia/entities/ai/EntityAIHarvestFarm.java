/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.init.Blocks
 *  net.minecraft.util.math.BlockPos
 */
package net.tangotek.tektopia.entities.ai;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.tangotek.tektopia.ModBlocks;
import net.tangotek.tektopia.ProfessionType;
import net.tangotek.tektopia.VillageFarm;
import net.tangotek.tektopia.entities.EntityVillagerTek;
import net.tangotek.tektopia.entities.ai.EntityAIMoveToBlock;

public class EntityAIHarvestFarm
extends EntityAIMoveToBlock {
    private final boolean replant;
    private boolean active = false;
    private int harvestTime = 0;
    private IBlockState replantState = null;
    protected final EntityVillagerTek villager;

    public EntityAIHarvestFarm(EntityVillagerTek entityIn, boolean replant) {
        super(entityIn);
        this.replant = replant;
        this.villager = entityIn;
    }

    @Override
    protected BlockPos getDestinationBlock() {
        BlockPos cropPos;
        if (this.villager.getVillage() != null && (cropPos = this.villager.getVillage().requestMaxAgeCrop()) != null && this.villager.isAIFilterEnabled("harvest_" + this.villager.world.getBlockState(cropPos).getBlock().getUnlocalizedName())) {
            return cropPos;
        }
        return null;
    }

    @Override
    public boolean shouldExecute() {
        if (this.villager.isAITick() && this.villager.hasVillage() && this.villager.isWorkTime()) {
            return super.shouldExecute();
        }
        return false;
    }

    @Override
    protected BlockPos findWalkPos() {
        return this.destinationPos;
    }

    @Override
    public void startExecuting() {
        this.active = true;
        super.startExecuting();
    }

    @Override
    public boolean shouldContinueExecuting() {
        return this.active;
    }

    @Override
    void updateMovementMode() {
        this.villager.setMovementMode(this.villager.getDefaultMovement());
    }

    @Override
    public void updateTask() {
        super.updateTask();
        if (this.harvestTime > 0) {
            --this.harvestTime;
            if (this.harvestTime == 30) {
                this.stopHarvesting();
                this.gatherResources();
            } else if (this.harvestTime == 0) {
                this.villager.pickupItems(4);
                this.active = false;
                if (this.replant && this.replantState != null) {
                    this.villager.world.setBlockState(this.destinationPos, this.replantState, 2);
                }
            }
        }
    }

    public boolean isInterruptible() {
        return this.harvestTime > 30 || this.harvestTime <= 0;
    }

    @Override
    protected void onStuck() {
        this.active = false;
        super.onStuck();
    }

    @Override
    protected void onArrival() {
        this.startHarvesting();
        super.onArrival();
    }

    private void startHarvesting() {
        float ANIMATION_TIME = 60.0f;
        if (VillageFarm.isMaxAgeCrop(this.villager.world, this.destinationPos)) {
            int animationCycles = this.villager.getSkillLerp(ProfessionType.FARMER, 7, 2);
            this.harvestTime = (int)(60.0f * (float)animationCycles / 30.0f * 20.0f) + 30;
            this.villager.getNavigator().clearPath();
            this.villager.playServerAnimation("villager_pickup");
        } else {
            this.active = false;
        }
    }

    private void stopHarvesting() {
        this.villager.stopServerAnimation("villager_pickup");
    }

    private void gatherResources() {
        if (this.isNearDestination(4.0)) {
            Block block = this.villager.world.getBlockState(this.destinationPos).getBlock();
            this.replantState = this.getReplantFromBlock(block);
            ModBlocks.villagerDestroyBlock(this.destinationPos, this.villager, true, true);

            this.villager.tryAddSkill(ProfessionType.FARMER, 12);
            this.villager.throttledSadness(-2);
            this.villager.modifyHunger(-1);
        }
    }

    protected IBlockState getReplantFromBlock(Block block) {
        if (block == Blocks.WHEAT) {
            return Blocks.WHEAT.getDefaultState();
        }
        if (block == Blocks.POTATOES) {
            return Blocks.POTATOES.getDefaultState();
        }
        if (block == Blocks.CARROTS) {
            return Blocks.CARROTS.getDefaultState();
        }
        if (block == Blocks.BEETROOTS) {
            return Blocks.BEETROOTS.getDefaultState();
        }
        return null;
    }

    @Override
    public void resetTask() {
        this.stopHarvesting();
        super.resetTask();
    }
}

