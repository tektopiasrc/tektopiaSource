/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Predicate
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.item.EntityItem
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.math.BlockPos
 */
package net.tangotek.tektopia.entities.ai;

import com.google.common.base.Predicate;
import java.util.Comparator;
import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.tangotek.tektopia.entities.EntityVillagerTek;
import net.tangotek.tektopia.entities.ai.EntityAIMoveToBlock;

public class EntityAIPickUpItem
extends EntityAIMoveToBlock {
    protected final EntityVillagerTek villager;
    private List<PickUpData> pickUps;
    protected EntityItem pickUpItem;
    private final int chance;

    public EntityAIPickUpItem(EntityVillagerTek v, List<PickUpData> pickUpCounts, int chance) {
        super(v);
        this.villager = v;
        this.pickUps = pickUpCounts;
        this.chance = chance;
    }

    @Override
    public boolean shouldExecute() {
        if (this.villager.isAITick() && this.navigator.hasVillage() && this.villager.isWorkTime() && this.villager.getRNG().nextInt(this.chance) == 0) {
            return super.shouldExecute();
        }
        return false;
    }

    @Override
    protected BlockPos getDestinationBlock() {
        List<EntityItem> entityItems = this.villager.world.getEntitiesWithinAABB(EntityItem.class, this.villager.getEntityBoundingBox().grow(20.0, 10.0, 20.0), this.shouldPickUp(this.villager));
        this.pickUpItem = entityItems.stream().min(Comparator.comparing(e -> e.getDistanceSq((Entity)this.villager))).orElse(null);
        if (this.pickUpItem != null) {
            return this.pickUpItem.getPosition();
        }
        return null;
    }

    private Predicate<EntityItem> shouldPickUp(EntityVillagerTek villager) {
        return e -> {
            if (this.villager.getVillage().getPathingGraph().isInGraph(e.getPosition())) {
                for (PickUpData pickUp : this.pickUps) {
                    int itemCount;
                    if (!villager.isAIFilterEnabled(pickUp.aiFilter) || !e.getItem().isItemEqual(pickUp.itemStack) || (itemCount = villager.getInventory().getItemCount((java.util.function.Predicate<ItemStack>) i -> e.getItem().isItemEqual(i))) >= pickUp.quantity) continue;
                    return true;
                }
            }
            return false;
        };
    }

    @Override
    protected BlockPos findWalkPos() {
        return this.destinationPos;
    }

    @Override
    public void startExecuting() {
        super.startExecuting();
    }

    @Override
    public boolean shouldContinueExecuting() {
        if (this.pickUpItem.isEntityAlive()) {
            return super.shouldContinueExecuting();
        }
        return false;
    }

    @Override
    void updateMovementMode() {
        this.villager.setMovementMode(this.villager.getDefaultMovement());
    }

    @Override
    protected void onArrival() {
        this.villager.pickupItems(4);
        super.onArrival();
    }

    @Override
    public void resetTask() {
        this.pickUpItem = null;
        super.resetTask();
    }

    public static class PickUpData {
        public final int quantity;
        public final ItemStack itemStack;
        public final String aiFilter;

        public PickUpData(ItemStack itemStack, int quantity, String aiFilter) {
            this.itemStack = itemStack;
            this.quantity = quantity;
            this.aiFilter = aiFilter;
        }
    }
}

