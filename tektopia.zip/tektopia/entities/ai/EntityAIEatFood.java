/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.ai.EntityAIBase
 *  net.minecraft.init.Items
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 */
package net.tangotek.tektopia.entities.ai;

import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Predicate;

import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.tangotek.tektopia.ItemTagType;
import net.tangotek.tektopia.ModItems;
import net.tangotek.tektopia.entities.EntityVillagerTek;

public class EntityAIEatFood
extends EntityAIBase {
    private EntityVillagerTek villager;
    private ItemStack foodItem;
    private int eatTime = 0;
    public static final Map<Item, VillagerFood> villagerFood = new HashMap<Item, VillagerFood>();

    private static void registerFood(Item item, int hunger, int happy) {
        EntityAIEatFood.registerFood(item, hunger, happy, null);
    }

    private static void registerFood(Item item, int hunger, int happy, BiConsumer<EntityVillagerTek, ItemStack> postEat) {
        VillagerFood food = new VillagerFood(item, hunger, happy, postEat);
        villagerFood.put(food.item, food);
    }

    public EntityAIEatFood(EntityVillagerTek v) {
        this.villager = v;
        this.setMutexBits(1);
    }

    public boolean isInterruptible() {
        return false;
    }

    public boolean shouldExecute() {
        if (this.villager.isAITick() && this.villager.isHungry() && !this.villager.isSleeping()) {
            this.foodItem = this.villager.getInventory().getItem(p -> EntityAIEatFood.getFoodScore(p.getItem(), this.villager));
            if (!this.foodItem.isEmpty()) {
                return true;
            }
            this.villager.setThought(EntityVillagerTek.VillagerThought.HUNGRY);
        }
        return false;
    }

    public static int getFoodScore(Item item, EntityVillagerTek v) {
        VillagerFood food = villagerFood.get(item);
        if (food != null) {
            return EntityAIEatFood.getFoodScore(food, v);
        }
        return -1;
    }

    public static int getFoodScore(VillagerFood food, EntityVillagerTek v) {
        if (v != null) {
            int happy = food.getHappy(v);
            int hunger = food.getHunger(v);
            if (v.getHunger() + hunger > v.getMaxHunger()) {
                hunger = 1;
            }
            if (v.getHappy() + happy > v.getMaxHappy()) {
                happy = 0;
            }
            int score = hunger;
            int happyPotential = happy * 5;
            float happyFactor = 1.0f;
            if (happyPotential > 0) {
                happyFactor = (float)(v.getMaxHappy() - v.getHappy()) / (float)v.getMaxHappy();
            }
            return Math.max(score += (int)((float)happyPotential * happyFactor), 1);
        }
        return food.happy + food.hunger;
    }

    public void startExecuting() {
        this.startEat();
        super.startExecuting();
    }

    public boolean shouldContinueExecuting() {
        return this.eatTime >= 0;
    }

    public void updateTask() {
        VillagerFood food;
        --this.eatTime;
        if (this.eatTime == 0 && !this.villager.getInventory().removeItems((Predicate<ItemStack>) p -> ItemStack.areItemStacksEqual((ItemStack)p, (ItemStack)this.foodItem), 1).isEmpty() && (food = villagerFood.get(this.foodItem.getItem())) != null) {
            food.eat(this.villager, this.foodItem);
        }
        super.updateTask();
    }

    private void startEat() {
        this.eatTime = 80;
        this.villager.getNavigator().clearPath();
        this.villager.equipActionItem(this.foodItem);
        this.villager.playServerAnimation("villager_eat");
    }

    private void stopEat() {
        this.villager.unequipActionItem(this.foodItem);
        this.villager.stopServerAnimation("villager_eat");
    }

    public void resetTask() {
        super.resetTask();
        this.stopEat();
        this.foodItem = null;
        this.eatTime = 0;
    }

    static {
        BiConsumer<EntityVillagerTek, ItemStack> returnBowl = (v, i) -> {
            ItemStack bowl = new ItemStack(Items.BOWL);
            if (ModItems.isTaggedItem(i, ItemTagType.VILLAGER)) {
                ModItems.makeTaggedItem(bowl, ItemTagType.VILLAGER);
            }
            v.getInventory().addItem(bowl);
        };
        EntityAIEatFood.registerFood(Items.APPLE, 12, -1);
        EntityAIEatFood.registerFood(Items.BAKED_POTATO, 35, 1);
        EntityAIEatFood.registerFood(Items.BEETROOT, 7, -1);
        EntityAIEatFood.registerFood(Items.BEETROOT_SOUP, 50, 6, returnBowl);
        EntityAIEatFood.registerFood(Items.BREAD, 55, 4);
        EntityAIEatFood.registerFood(Items.CAKE, 7, 25);
        EntityAIEatFood.registerFood(Items.CARROT, 12, -1);
        EntityAIEatFood.registerFood(Items.COOKED_BEEF, 70, 14);
        EntityAIEatFood.registerFood(Items.COOKED_CHICKEN, 60, 6);
        EntityAIEatFood.registerFood(Items.COOKED_MUTTON, 66, 4);
        EntityAIEatFood.registerFood(Items.COOKED_PORKCHOP, 70, 14);
        EntityAIEatFood.registerFood(Items.COOKIE, 5, 16);
        EntityAIEatFood.registerFood(Items.GOLDEN_CARROT, 70, 20);
        EntityAIEatFood.registerFood(Items.MELON, 6, 3);
        EntityAIEatFood.registerFood(Items.MUSHROOM_STEW, 50, 4, returnBowl);
        EntityAIEatFood.registerFood(Items.POTATO, 7, -1);
        EntityAIEatFood.registerFood(Items.PUMPKIN_PIE, 35, 18);
    }

    public static class VillagerFood {
        private final int happy;
        private final int hunger;
        private final Item item;
        private final BiConsumer<EntityVillagerTek, ItemStack> postEat;

        public VillagerFood(Item item, int hunger, int happy) {
            this(item, hunger, happy, null);
        }

        public VillagerFood(Item item, int hunger, int happy, BiConsumer<EntityVillagerTek, ItemStack> post) {
            this.item = item;
            this.hunger = hunger;
            this.happy = happy;
            this.postEat = post;
        }

        public void eat(EntityVillagerTek v, ItemStack foodItem) {
            boolean isVFood = ModItems.isTaggedItem(foodItem, ItemTagType.VILLAGER);
            int hunger = this.getHunger(v);
            if (!isVFood) {
                hunger /= 2;
            }
            v.modifyHunger(hunger);
            if (isVFood) {
                int happy = this.getHappy(v);
                v.modifyHappy(happy);
            }
            if (this.postEat != null) {
                this.postEat.accept(v, foodItem);
            }
            v.debugOut("Eating Food " + foodItem.getItem().getUnlocalizedName());
            v.addRecentEat(this.item);
        }

        public int getHappy(EntityVillagerTek villager) {
            int recentEatModifier = villager.getRecentEatModifier(this.item);
            return Math.max(this.happy + recentEatModifier, -3);
        }

        public int getHunger(EntityVillagerTek villager) {
            return this.hunger;
        }

        public Item getItem() {
            return this.item;
        }
    }
}

