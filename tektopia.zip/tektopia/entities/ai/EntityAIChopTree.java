/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockLeaves
 *  net.minecraft.block.BlockOldLog
 *  net.minecraft.block.BlockPlanks$EnumType
 *  net.minecraft.block.BlockSapling
 *  net.minecraft.block.properties.IProperty
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.enchantment.Enchantment
 *  net.minecraft.enchantment.EnchantmentHelper
 *  net.minecraft.entity.item.EntityItem
 *  net.minecraft.init.Blocks
 *  net.minecraft.init.Enchantments
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.ItemTool
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Vec3i
 */
package net.tangotek.tektopia.entities.ai;

import java.util.List;
import java.util.function.Predicate;

import net.minecraft.block.Block;
import net.minecraft.block.BlockLeaves;
import net.minecraft.block.BlockOldLog;
import net.minecraft.block.BlockPlanks;
import net.minecraft.block.BlockSapling;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.IBlockState;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.init.Blocks;
import net.minecraft.init.Enchantments;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemTool;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import net.tangotek.tektopia.ModBlocks;
import net.tangotek.tektopia.ProfessionType;
import net.tangotek.tektopia.blockfinder.TreeScanner;
import net.tangotek.tektopia.entities.EntityLumberjack;
import net.tangotek.tektopia.entities.EntityVillagerTek;
import net.tangotek.tektopia.entities.ai.EntityAIMoveToBlock;

public class EntityAIChopTree
extends EntityAIMoveToBlock {
    private final boolean replant;
    private final EntityVillagerTek villager;
    private BlockPlanks.EnumType treeType;
    private BlockPos treePos;
    private ItemStack bestAxe;
    private boolean active = false;
    private int chopTime = 0;

    public EntityAIChopTree(EntityVillagerTek entityIn, boolean replant) {
        super(entityIn);
        this.replant = replant;
        this.villager = entityIn;
    }

    @Override
    protected BlockPos getDestinationBlock() {
        if (this.villager.getVillage() != null) {
            this.releaseTreeClaim();
            BlockPos treePos = this.villager.getVillage().requestBlock(Blocks.LOG);
            if (treePos != null) {
                BlockPlanks.EnumType treeType = (BlockPlanks.EnumType)this.villager.world.getBlockState(treePos).getValue((IProperty)BlockOldLog.VARIANT);
                if (this.villager.isAIFilterEnabled("chop_tree_" + treeType.getName())) {
                    return treePos;
                }
            }
        }
        return null;
    }

    @Override
    protected BlockPos findWalkPos() {
        BlockPos diff = this.villager.getPosition().subtract((Vec3i)this.destinationPos);
        EnumFacing facing = EnumFacing.getFacingFromVector((float)diff.getX(), (float)0.0f, (float)diff.getZ());
        BlockPos focusPos = this.destinationPos.offset(facing);
        if (this.isWalkable(focusPos, this.villager)) {
            return focusPos;
        }
        BlockPos closest = null;
        double minDist = Double.MAX_VALUE;
        for (int x = -3; x <= 3; ++x) {
            for (int z = -3; z <= 3; ++z) {
                double thisDist;
                BlockPos testPos = focusPos.add(x, 0, z);
                if (!this.isWalkable(testPos, this.villager) || !((thisDist = testPos.distanceSq((Vec3i)focusPos)) < minDist)) continue;
                minDist = thisDist;
                closest = testPos;
            }
        }
        return closest;
    }

    @Override
    public boolean shouldExecute() {
        if (this.villager.isAITick() && this.villager.hasVillage() && this.villager.isWorkTime() && this.villager.getVillage().hasBlock(Blocks.LOG)) {
            List<ItemStack> axeList = this.villager.getInventory().getItems(EntityLumberjack.getBestAxe(this.villager), 1);
            if (!axeList.isEmpty()) {
                this.bestAxe = axeList.get(0);
                return super.shouldExecute();
            }
            this.villager.setThought(EntityVillagerTek.VillagerThought.AXE);
            this.bestAxe = null;
        }
        return false;
    }

    @Override
    public void startExecuting() {
        this.treePos = this.destinationPos;
        this.active = true;
        this.chopTime = 0;
        super.startExecuting();
    }

    @Override
    public boolean shouldContinueExecuting() {
        return this.active && !this.bestAxe.isEmpty();
    }

    @Override
    void updateMovementMode() {
        this.villager.setMovementMode(this.villager.getDefaultMovement());
    }

    @Override
    public void updateTask() {
        super.updateTask();
        if (this.chopTime > 0) {
            --this.chopTime;
            if (this.chopTime == 30) {
                this.stopChopping();
                this.chopTree();
            } else if (this.chopTime == 0) {
                this.pickUpItems();
                this.active = false;
                if (this.replant && this.treeType != null && this.consumeSaplingItem(this.treeType)) {
                    this.villager.world.setBlockState(this.treePos, Blocks.SAPLING.getDefaultState().withProperty((IProperty)BlockSapling.TYPE, (Comparable)this.treeType), 2);
                }
            }
            if (this.chopTime >= 30 && (this.chopTime - 30) % 20 == 0 && this.villager.getRNG().nextInt(this.villager.getSkillLerp(ProfessionType.LUMBERJACK, 2, 6)) == 0) {
                this.villager.damageItem(this.bestAxe, 1);
            }
            this.villager.faceLocation(this.treePos.getX(), this.treePos.getZ(), 30.0f);
        }
    }

    public boolean isInterruptible() {
        return this.chopTime > 30 || this.chopTime <= 0;
    }

    @Override
    protected void onStuck() {
        this.active = false;
        super.onStuck();
    }

    @Override
    protected boolean attemptStuckFix() {
        int trimmed = this.trimLeaves();
        return trimmed > 0;
    }

    @Override
    protected void onArrival() {
        if (this.isNearDestination(2.5)) {
            if (TreeScanner.treeTest(this.villager.world, this.treePos) != null) {
                this.startChopping();
                super.onArrival();
            } else {
                this.active = false;
            }
        } else if (this.isNearWalkPos()) {
            int trimmed = this.trimLeaves();
            if (trimmed > 0) {
                this.doMove();
            } else {
                this.active = false;
            }
        }
    }

    @Override
    protected void onPathFailed(BlockPos pos) {
        this.active = false;
        super.onPathFailed(pos);
    }

    private static int getToolMaterialValue(ItemTool tool) {
        if (tool.getToolMaterialName().equals("STONE")) {
            return 25;
        }
        if (tool.getToolMaterialName().equals("IRON")) {
            return 35;
        }
        if (tool.getToolMaterialName().equals("DIAMOND")) {
            return 45;
        }
        return 15;
    }

    public static int getChopCount(EntityVillagerTek villager, ItemStack bestAxe) {
        int skill = villager.getSkill(ProfessionType.LUMBERJACK);
        int enchantLevel = EnchantmentHelper.getEnchantmentLevel((Enchantment)Enchantments.EFFICIENCY, (ItemStack)bestAxe);
        int materialValue = EntityAIChopTree.getToolMaterialValue((ItemTool)bestAxe.getItem());
        float damagePerChop = (float)skill + 70.0f + (float)materialValue + (float)(enchantLevel * 8);
        return Math.max(Math.round(1500.0f / damagePerChop), 1);
    }

    private void startChopping() {
        int chopCount = EntityAIChopTree.getChopCount(this.villager, this.bestAxe);
        this.chopTime = chopCount * 20 + 30;
        this.villager.getNavigator().clearPath();
        this.villager.equipActionItem(this.bestAxe);
        this.villager.playServerAnimation("villager_chop");
    }

    private void stopChopping() {
        this.villager.unequipActionItem();
        this.villager.stopServerAnimation("villager_chop");
    }

    private void chopTree() {
        int logsChopped = 0;
        IBlockState blockState = this.villager.world.getBlockState(this.treePos);
        if (TreeScanner.isLog(blockState)) {
            this.treeType = (BlockPlanks.EnumType)blockState.getValue((IProperty)BlockOldLog.VARIANT);
            switch (this.treeType) {
                case OAK: {
                    logsChopped = this.chopTreeOak(this.treePos);
                    break;
                }
                case BIRCH: 
                case JUNGLE: 
                case SPRUCE: {
                    logsChopped = this.chopTreeStraight(this.treePos);
                }
            }
            if (logsChopped > 0) {
                this.villager.throttledSadness(-2);
                this.villager.tryAddSkill(ProfessionType.LUMBERJACK, 7);
                this.villager.modifyHunger(-logsChopped / 2);
                this.villager.debugOut("ChopTree [ " + this.treePos.getX() + ", " + this.treePos.getZ() + "] Chopped: " + logsChopped);
            }
        }
    }

    private int chopTreeOak(BlockPos treePos) {
        int count = 0;
        BlockPos trunkPos = treePos;
        int skill = this.villager.getSkill(ProfessionType.LUMBERJACK);
        while (this.chopLog(trunkPos, count == 0 ? true : this.logDropCheck(skill), false)) {
            trunkPos = trunkPos.up();
            ++count;
        }
        if (count >= 6) {
            trunkPos = treePos.up(3);
            for (BlockPos branchPos : BlockPos.getAllInBox((BlockPos)trunkPos.add(-5, 0, -5), (BlockPos)trunkPos.add(5, 9, 5))) {
                if (!this.chopLog(branchPos, this.logDropCheck(skill), true)) continue;
                ++count;
            }
        }
        return count;
    }

    private int chopTreeStraight(BlockPos treePos) {
        int count = 0;
        int skill = this.villager.getSkill(ProfessionType.LUMBERJACK);
        while (this.chopLog(treePos, count == 0 ? true : this.logDropCheck(skill), false)) {
            treePos = treePos.up();
            ++count;
        }
        return count;
    }

    private boolean logDropCheck(int skill) {
        return this.villager.getRNG().nextInt(5) == 0;
    }

    private boolean hasAdjacentLeaf(BlockPos pos) {
        return TreeScanner.isLeaf(this.villager.world.getBlockState(pos.west())) || TreeScanner.isLeaf(this.villager.world.getBlockState(pos.east())) || TreeScanner.isLeaf(this.villager.world.getBlockState(pos.north())) || TreeScanner.isLeaf(this.villager.world.getBlockState(pos.south())) || TreeScanner.isLeaf(this.villager.world.getBlockState(pos.up()));
    }

    private boolean chopLog(BlockPos pos, boolean dropBlock, boolean adjacentLeafCheck) {
        if (TreeScanner.isLog(this.villager.world.getBlockState(pos)) && (!adjacentLeafCheck || this.hasAdjacentLeaf(pos))) {
            ModBlocks.villagerDestroyBlock(pos, this.villager, dropBlock, true);
            if (this.treeType == BlockPlanks.EnumType.JUNGLE && this.villager.getRNG().nextInt(8) == 0) {
                this.villager.entityDropItem(new ItemStack(Item.getItemFromBlock((Block)Blocks.SAPLING), 1, 3), 0.0f);
            }
            return true;
        }
        return false;
    }

    private boolean consumeSaplingItem(BlockPlanks.EnumType blockType) {
        List<ItemStack> removedSaplings = this.villager.getInventory().removeItems((Predicate<ItemStack>) is -> EntityLumberjack.isSapling().test((ItemStack)is) && is.getMetadata() == blockType.getMetadata(), 1);
        return !removedSaplings.isEmpty();
    }

    private int trimLeaves() {
        BlockPos pos = this.villager.getPosition();
        int trimmed = 0;
        for (BlockPos bp : BlockPos.getAllInBox((int)(pos.getX() - 2), (int)pos.getY(), (int)(pos.getZ() - 2), (int)(pos.getX() + 2), (int)(pos.getY() + 2), (int)(pos.getZ() + 2))) {
            IBlockState blockState = this.villager.world.getBlockState(bp);
            if (!TreeScanner.isLeaf(blockState) || !((Boolean)blockState.getValue((IProperty)BlockLeaves.DECAYABLE)).booleanValue()) continue;
            blockState.getBlock().dropBlockAsItem(this.villager.world, bp, blockState, 0);
            this.villager.world.setBlockToAir(bp);
            ++trimmed;
        }
        return trimmed;
    }

    private void pickUpItems() {
        if (!this.villager.isDead) {
            for (EntityItem entityitem : this.villager.world.getEntitiesWithinAABB(EntityItem.class, this.villager.getEntityBoundingBox().grow(8.0, 12.0, 8.0))) {
                if (entityitem.isDead || entityitem.getItem().isEmpty() || entityitem.cannotPickup()) continue;
                this.villager.updateEquipmentIfNeeded(entityitem);
            }
        }
    }

    private void releaseTreeClaim() {
        if (this.treePos != null && this.villager.getVillage() != null) {
            this.villager.getVillage().releaseBlockClaim(Blocks.LOG, this.treePos);
            this.treePos = null;
        }
    }

    @Override
    public void resetTask() {
        this.stopChopping();
        this.active = false;
        this.releaseTreeClaim();
        super.resetTask();
    }
}

