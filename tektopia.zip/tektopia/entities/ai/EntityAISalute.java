/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.ai.EntityAIBase
 */
package net.tangotek.tektopia.entities.ai;

import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.ai.EntityAIBase;
import net.tangotek.tektopia.ModItems;
import net.tangotek.tektopia.entities.EntityGuard;

public class EntityAISalute
extends EntityAIBase {
    private EntityGuard guard;
    private EntityLivingBase saluteTarget;
    private long lastSalute = 0L;
    private int saluteTime = 0;

    public EntityAISalute(EntityGuard v) {
        this.guard = v;
        this.setMutexBits(1);
    }

    public boolean shouldExecute() {
        if (this.guard.isAITick("salute") && this.guard.world.getTotalWorldTime() - this.lastSalute > 2400L && !this.guard.isSleeping() && this.guard.getAttackTarget() == null && this.guard.hasVillage() && !this.guard.getVillage().enemySeenRecently()) {
            List captains;
            this.saluteTarget = this.guard.world.getClosestPlayerToEntity((Entity)this.guard, 12.0);
            if (this.saluteTarget != null) {
                return true;
            }
            if (!this.guard.isCaptain() && !(captains = this.guard.world.getEntitiesWithinAABB(EntityGuard.class, this.guard.getEntityBoundingBox().grow(12.0), g -> g.isCaptain())).isEmpty()) {
                this.saluteTarget = (EntityLivingBase)captains.get(0);
                return true;
            }
        }
        return false;
    }

    public void startExecuting() {
        this.startSalute();
        super.startExecuting();
    }

    public boolean shouldContinueExecuting() {
        return this.saluteTime > 0;
    }

    public void updateTask() {
        if (this.saluteTime > 0) {
            if (this.saluteTime == 10) {
                this.guard.stopServerAnimation("villager_salute");
                if (this.guard.getRNG().nextInt(3) == 0) {
                    this.guard.modifyHappy(2);
                }
            }
            this.guard.faceEntity((Entity)this.saluteTarget, 30.0f, 30.0f);
            --this.saluteTime;
        }
        super.updateTask();
    }

    private void startSalute() {
        this.lastSalute = this.guard.world.getTotalWorldTime();
        this.saluteTime = 50;
        this.guard.getNavigator().clearPath();
        this.guard.equipActionItem(ModItems.EMPTY_HAND_ITEM);
        this.guard.playServerAnimation("villager_salute");
    }

    private void stopSalute() {
        this.guard.unequipActionItem(ModItems.EMPTY_HAND_ITEM);
        this.guard.stopServerAnimation("villager_salute");
    }

    public void resetTask() {
        this.stopSalute();
        this.saluteTime = 0;
        super.resetTask();
    }
}

