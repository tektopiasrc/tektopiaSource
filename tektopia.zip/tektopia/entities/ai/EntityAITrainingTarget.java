/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.EntityCreature
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.ai.EntityAITarget
 *  net.minecraft.entity.item.EntityArmorStand
 */
package net.tangotek.tektopia.entities.ai;

import java.util.Collections;
import java.util.List;
import java.util.function.Predicate;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.ai.EntityAITarget;
import net.minecraft.entity.item.EntityArmorStand;
import net.tangotek.tektopia.entities.EntityGuard;
import net.tangotek.tektopia.structures.VillageStructure;
import net.tangotek.tektopia.structures.VillageStructureType;

public class EntityAITrainingTarget
extends EntityAITarget {
    EntityGuard guard;
    EntityLivingBase targetEntity;
    VillageStructure structure;
    protected final Predicate<EntityGuard> shouldPred;

    public EntityAITrainingTarget(EntityGuard guard, Predicate<EntityGuard> shouldPred) {
        super((EntityCreature)guard, false, false);
        this.guard = guard;
        this.setMutexBits(1);
        this.shouldPred = shouldPred;
    }

    public boolean shouldExecute() {
        if (this.guard.isAIFilterEnabled("practice_melee") && this.guard.hasVillage() && this.shouldPred.test(this.guard)) {
            List<VillageStructure> barracks = this.guard.getVillage().getStructures(VillageStructureType.BARRACKS);
            Collections.shuffle(barracks);
            for (VillageStructure str : barracks) {
                List<EntityArmorStand> armorStands = str.getEntitiesInside(EntityArmorStand.class);
                this.targetEntity = armorStands.stream().filter(a -> !str.isSpecialBlockOccupied(a.getPosition())).findAny().orElse(null);
                if (this.targetEntity == null) continue;
                this.structure = str;
                return true;
            }
        }
        return false;
    }

    public boolean shouldContinueExecuting() {
        if (this.guard.wantsPractice() <= 0) {
            return false;
        }
        return super.shouldContinueExecuting();
    }

    protected double getTargetDistance() {
        return 240.0;
    }

    public void startExecuting() {
        this.guard.setAttackTarget(this.targetEntity);
        this.structure.occupySpecialBlock(this.targetEntity.getPosition());
        super.startExecuting();
    }

    public void resetTask() {
        super.resetTask();
        this.structure.vacateSpecialBlock(this.targetEntity.getPosition());
        this.targetEntity = null;
        this.structure = null;
    }
}

