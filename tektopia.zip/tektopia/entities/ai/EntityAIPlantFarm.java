/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.init.Blocks
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.math.BlockPos
 */
package net.tangotek.tektopia.entities.ai;

import java.util.function.Predicate;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.tangotek.tektopia.ProfessionType;
import net.tangotek.tektopia.entities.EntityFarmer;
import net.tangotek.tektopia.entities.EntityVillagerTek;
import net.tangotek.tektopia.entities.ai.EntityAIMoveToBlock;

public class EntityAIPlantFarm
extends EntityAIMoveToBlock {
    private boolean active = false;
    private int plantTime = 0;
    private IBlockState plantState = null;
    protected final EntityVillagerTek villager;

    public EntityAIPlantFarm(EntityVillagerTek entityIn) {
        super(entityIn);
        this.villager = entityIn;
    }

    private Predicate<BlockPos> isPlantable() {
        return bp -> this.villager.world.getBlockState(bp).getBlock() == Blocks.FARMLAND && this.villager.world.isAirBlock(bp.up());
    }

    @Override
    protected BlockPos getDestinationBlock() {
        BlockPos farmPos = this.villager.getVillage().requestFarmland(this.isPlantable());
        if (farmPos != null) {
            BlockPos cropPos = farmPos.up();
            this.plantState = this.checkNearbyCrops(cropPos);
            if (this.plantState != null && this.villager.isAIFilterEnabled("plant_" + this.plantState.getBlock().getUnlocalizedName())) {
                Item seedItem = EntityFarmer.getSeed(this.plantState);
                Predicate<ItemStack> seedPred = i -> i.getItem() == seedItem;
                if (this.villager.getInventory().getItemCount(seedPred) >= 1) {
                    return cropPos;
                }
                this.villager.setItemThought(seedItem);
            }
        }
        return null;
    }

    @Override
    public boolean shouldExecute() {
        if (this.villager.isAITick() && this.villager.hasVillage() && this.villager.isWorkTime()) {
            return super.shouldExecute();
        }
        return false;
    }

    @Override
    public void startExecuting() {
        this.active = true;
        super.startExecuting();
    }

    @Override
    public boolean shouldContinueExecuting() {
        return this.active;
    }

    @Override
    void updateMovementMode() {
        this.villager.setMovementMode(this.villager.getDefaultMovement());
    }

    @Override
    public void updateTask() {
        super.updateTask();
        if (this.plantTime > 0) {
            --this.plantTime;
            if (this.plantTime == 10) {
                this.stopPlanting();
                this.plantCrop();
            } else if (this.plantTime <= 0) {
                this.active = false;
            }
        }
    }

    @Override
    protected void onStuck() {
        this.active = false;
        super.onStuck();
    }

    @Override
    protected void onArrival() {
        this.startPlanting();
        super.onArrival();
    }

    private void startPlanting() {
        float ANIMATION_TIME = 50.0f;
        if (this.isPlantable().test(this.destinationPos.down())) {
            int animationCycles = this.villager.getSkillLerp(ProfessionType.FARMER, 6, 1);
            this.plantTime = (int)(50.0f * (float)animationCycles / 30.0f * 20.0f) + 10;
            this.villager.getNavigator().clearPath();
            this.villager.playServerAnimation("villager_take");
        } else {
            this.active = false;
        }
    }

    private void stopPlanting() {
        this.villager.stopServerAnimation("villager_take");
    }

    private void plantCrop() {
        if (this.isNearDestination(4.0) && this.isPlantable().test(this.destinationPos.down())) {
            this.villager.world.setBlockState(this.destinationPos, this.plantState, 2);
            this.villager.modifyHunger(-1);
            Item seedItem = EntityFarmer.getSeed(this.plantState);
            this.villager.getInventory().removeItems((Predicate<ItemStack>) is -> is.getItem() == seedItem, 1);
            this.villager.tryAddSkill(ProfessionType.FARMER, 16);
        }
    }

    private IBlockState checkNearbyCrops(BlockPos pos) {
        Block[] cropBlocks;
        IBlockState bestState = null;
        for (Block b : cropBlocks = new Block[]{Blocks.WHEAT, Blocks.POTATOES, Blocks.CARROTS, Blocks.BEETROOTS}) {
            int count = this.countNearbyCrop(pos, b);
            if (count >= 2) {
                return b.getDefaultState();
            }
            if (count != 1 || bestState != null) continue;
            bestState = b.getDefaultState();
        }
        return bestState;
    }

    private int countNearbyCrop(BlockPos pos, Block block) {
        int count = 0;
        if (this.villager.world.getBlockState(pos.west()).getBlock() == block) {
            ++count;
        }
        if (this.villager.world.getBlockState(pos.east()).getBlock() == block) {
            ++count;
        }
        if (this.villager.world.getBlockState(pos.north()).getBlock() == block) {
            ++count;
        }
        if (this.villager.world.getBlockState(pos.south()).getBlock() == block) {
            ++count;
        }
        return count;
    }

    @Override
    public void resetTask() {
        this.active = false;
        this.stopPlanting();
        super.resetTask();
    }
}

