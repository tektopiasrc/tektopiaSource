/*
 * Decompiled with CFR 0.152.
 */
package net.tangotek.tektopia.entities.ai;

import java.util.function.Predicate;
import net.tangotek.tektopia.ModSoundEvents;
import net.tangotek.tektopia.entities.EntityVillageNavigator;
import net.tangotek.tektopia.entities.EntityVillagerTek;
import net.tangotek.tektopia.entities.ai.EntityAIWanderStructure;

public class EntityAITavernVisit
extends EntityAIWanderStructure {
    public EntityAITavernVisit(EntityVillagerTek v, Predicate<EntityVillagerTek> shouldPred) {
        super(v, EntityVillagerTek.findLocalTavern(), shouldPred, 0);
    }

    @Override
    public boolean shouldExecute() {
        return super.shouldExecute() && this.villager.isAIFilterEnabled("visit_tavern");
    }

    @Override
    public boolean shouldContinueExecuting() {
        if (this.villager.isWorkTime() || this.villager.shouldSleep() || this.villager.getHappy() >= this.villager.getMaxHappy()) {
            return false;
        }
        return super.shouldContinueExecuting();
    }

    @Override
    public void updateTask() {
        super.updateTask();
        if (this.hasArrived()) {
            if (this.villager.isSitting()) {
                if (this.villager.getRNG().nextInt(300) == 0) {
                    this.villager.modifyHappy(1);
                    if (this.villager.world.getEntitiesWithinAABB(EntityVillageNavigator.class, this.villager.getEntityBoundingBox().grow(8.0)).size() > 1) {
                        this.villager.playSound(ModSoundEvents.villagerSocialize, 0.4f + this.villager.getRNG().nextFloat() * 0.7f, this.villager.getRNG().nextFloat() * 0.4f + 0.8f);
                    }
                    if (this.villager.getRNG().nextInt(5) == 0) {
                        this.villager.cheerBeer(2);
                    }
                }
            } else if (this.villager.getRNG().nextInt(400) == 0) {
                this.villager.modifyHappy(1);
            }
        }
    }
}

