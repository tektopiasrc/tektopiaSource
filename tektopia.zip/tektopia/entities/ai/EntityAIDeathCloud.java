/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Predicate
 *  com.google.common.base.Predicates
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.ai.EntityAIBase
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.Blocks
 *  net.minecraft.util.EntitySelectors
 *  net.minecraft.util.math.BlockPos
 */
package net.tangotek.tektopia.entities.ai;

import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.EntitySelectors;
import net.minecraft.util.math.BlockPos;
import net.tangotek.tektopia.ModSoundEvents;
import net.tangotek.tektopia.entities.EntityDeathCloud;
import net.tangotek.tektopia.entities.EntityNecromancer;

public class EntityAIDeathCloud
extends EntityAIBase {
    private EntityNecromancer necro;
    private EntityPlayer targetPlayer;
    private int cooldownTick = 0;
    private int castTime;
    private BlockPos targetPos;
    private final Predicate<Entity> entityPredicate;

    public EntityAIDeathCloud(EntityNecromancer n) {
        this.necro = n;
        this.setMutexBits(1);
        this.entityPredicate = Predicates.and(EntitySelectors.CAN_AI_TARGET, e -> e.isEntityAlive() && this.necro.getEntitySenses().canSee(e));
    }

    public boolean shouldExecute() {
        if (this.necro.isAITick() && this.necro.ticksExisted > this.cooldownTick && !this.necro.hasVillagerDied()) {
            this.targetPlayer = this.necro.world.getClosestPlayer(this.necro.posX, this.necro.posY, this.necro.posZ, 16.0, this.entityPredicate);
            if (this.targetPlayer != null) {
                this.targetPos = this.targetPlayer.getPosition();
                if (!this.targetPlayer.onGround && this.necro.world.getBlockState(this.targetPos.down()).getBlock().equals(Blocks.AIR)) {
                    this.targetPos = this.targetPos.down();
                }
                return true;
            }
        }
        return false;
    }

    public void startExecuting() {
        this.startCast();
        super.startExecuting();
    }

    public boolean shouldContinueExecuting() {
        return this.castTime > 0;
    }

    public boolean isInterruptible() {
        return false;
    }

    public void updateTask() {
        if (this.castTime > 0) {
            --this.castTime;
            if (this.castTime >= 37) {
                if (this.castTime == 37) {
                    this.createCloud();
                } else if (this.castTime == 33) {
                    this.necro.playSound(ModSoundEvents.deathCircle, this.necro.world.rand.nextFloat() * 0.4f + 1.2f, this.necro.world.rand.nextFloat() * 0.4f + 0.8f);
                }
                if (this.castTime > 70) {
                    this.necro.faceEntity((Entity)this.targetPlayer, 30.0f, 30.0f);
                }
            }
            if (this.castTime == 0) {
                this.necro.stopServerAnimation("necro_cast_forward");
            }
        }
        super.updateTask();
    }

    private void createCloud() {
        EntityDeathCloud cloud = new EntityDeathCloud(this.necro.world, this.targetPos.getX(), this.targetPos.getY(), this.targetPos.getZ());
        cloud.setRadius(3.0f);
        cloud.setWaitTime(10);
        cloud.setDuration(40 + this.necro.getLevel() * 30);
        cloud.setRadiusPerTick(0.03f);
        this.necro.world.spawnEntity((Entity)cloud);
        this.necro.playSound(ModSoundEvents.deathSummonEnd);
    }

    private void startCast() {
        this.cooldownTick = this.necro.ticksExisted + this.necro.getLevelCooldown(this.necro.getRNG().nextInt(160) + 160);
        this.castTime = 80;
        this.necro.getNavigator().clearPath();
        this.necro.playServerAnimation("necro_cast_forward");
    }

    private void stopCast() {
        this.necro.stopServerAnimation("necro_cast_forward");
    }

    public void resetTask() {
        this.stopCast();
        this.castTime = 0;
        super.resetTask();
    }
}

