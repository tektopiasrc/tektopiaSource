/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.init.MobEffects
 *  net.minecraft.potion.PotionEffect
 *  net.minecraft.util.math.BlockPos
 */
package net.tangotek.tektopia.entities.ai;

import net.minecraft.entity.Entity;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.math.BlockPos;
import net.tangotek.tektopia.EntityTagType;
import net.tangotek.tektopia.ModEntities;
import net.tangotek.tektopia.entities.EntityVillagerTek;
import net.tangotek.tektopia.entities.ai.EntityAIMoveToBlock;
import net.tangotek.tektopia.structures.VillageStructure;
import net.tangotek.tektopia.structures.VillageStructureType;

public class EntityAILeadAnimalToStructure
extends EntityAIMoveToBlock {
    private final VillageStructureType structureType;
    private VillageStructure destinationStructure;
    protected final EntityVillagerTek villager;
    private boolean active = false;
    private int pathTick = 0;
    private final EntityTagType entTagType;

    public EntityAILeadAnimalToStructure(EntityVillagerTek v, VillageStructureType structureType, EntityTagType tagType) {
        super(v);
        this.villager = v;
        this.structureType = structureType;
        this.destinationStructure = null;
        this.entTagType = tagType;
    }

    protected VillageStructure getDestinationStructure() {
        return this.villager.getVillage().getNearestStructure(this.structureType, this.villager.getPosition());
    }

    @Override
    protected BlockPos getDestinationBlock() {
        this.destinationPos = null;
        if (this.villager.getVillage() != null && this.villager.getLeadAnimal() != null && this.villager.isWorkTime()) {
            this.destinationStructure = this.getDestinationStructure();
            if (this.destinationStructure != null) {
                this.destinationPos = this.destinationStructure.getSafeSpot();
            }
        }
        return this.destinationPos;
    }

    @Override
    public boolean shouldExecute() {
        if (this.villager.isAITick()) {
            return super.shouldExecute();
        }
        return false;
    }

    @Override
    public void startExecuting() {
        this.active = true;
        this.pathTick = 30;
        super.startExecuting();
    }

    @Override
    public boolean shouldContinueExecuting() {
        return this.active;
    }

    @Override
    void updateMovementMode() {
        this.villager.setMovementMode(this.villager.getDefaultMovement());
    }

    @Override
    public void updateTask() {
        if (this.villager.getLeadAnimal() != null) {
            if (this.villager.getLeadAnimal().getDistanceSq((Entity)this.villager) > 40.0) {
                this.teleportAnimal(this.villager.getPosition());
            }
            if (!this.villager.getLeadAnimal().isEntityAlive()) {
                this.active = false;
            } else if (this.villager.getLeadAnimal().getLeashHolder() != this.villager) {
                this.active = false;
            }
        }
        --this.pathTick;
        if (this.pathTick <= 0) {
            this.updateAnimalPath();
            if (this.villager.getRNG().nextInt(8) == 0) {
                this.villager.modifyHunger(-1);
            }
            this.pathTick = 30;
        }
        super.updateTask();
    }

    private void updateAnimalPath() {
        this.villager.getLeadAnimal().addPotionEffect(new PotionEffect(MobEffects.SPEED, 40));
        this.villager.getLeadAnimal().getNavigator().tryMoveToEntityLiving((Entity)this.villager, (double)this.villager.getLeadAnimal().getAIMoveSpeed() * 1.2);
    }

    private void teleportAnimal(BlockPos pos) {
        this.villager.getLeadAnimal().setPositionAndUpdate((double)pos.getX(), (double)pos.getY(), (double)pos.getZ());
    }

    @Override
    protected void onArrival() {
        this.active = false;
        super.onArrival();
    }

    @Override
    protected void onStuck() {
        this.active = false;
        super.onStuck();
    }

    @Override
    protected void onPathFailed(BlockPos pos) {
        this.active = false;
        super.onPathFailed(pos);
    }

    @Override
    public void resetTask() {
        if (this.villager.getLeadAnimal() != null) {
            if (!this.destinationStructure.isBlockInside(this.villager.getLeadAnimal().getPosition())) {
                this.teleportAnimal(this.destinationStructure.getSafeSpot());
            }
            if (this.entTagType != null) {
                ModEntities.makeTaggedEntity((Entity)this.villager.getLeadAnimal(), this.entTagType);
            }
            this.villager.getLeadAnimal().clearLeashed(true, false);
            this.villager.setLeadAnimal(null);
        }
        this.active = false;
        this.destinationStructure = null;
        super.resetTask();
    }
}

