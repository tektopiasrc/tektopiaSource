/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Vec3i
 */
package net.tangotek.tektopia.entities.ai;

import java.util.function.Predicate;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import net.tangotek.tektopia.entities.EntityVillagerTek;
import net.tangotek.tektopia.entities.ai.EntityAIMoveToBlock;
import net.tangotek.tektopia.pathing.BasePathingNode;

public abstract class EntityAIPatrolPoint
extends EntityAIMoveToBlock {
    protected final Predicate<EntityVillagerTek> shouldPred;
    protected final EntityVillagerTek villager;
    protected final int distanceFromPoint;
    protected final int waitTime;
    private int waitRemaining;

    public EntityAIPatrolPoint(EntityVillagerTek v, Predicate<EntityVillagerTek> shouldPred, int distanceFromPoint, int waitTime) {
        super(v);
        this.villager = v;
        this.distanceFromPoint = distanceFromPoint;
        this.shouldPred = shouldPred;
        this.waitTime = 200;
    }

    @Override
    public boolean shouldExecute() {
        if (this.villager.isAITick() && this.navigator.hasVillage() && this.shouldPred.test(this.villager)) {
            return super.shouldExecute();
        }
        return false;
    }

    @Override
    public boolean shouldContinueExecuting() {
        if (this.waitRemaining > 0) {
            return true;
        }
        return super.shouldContinueExecuting();
    }

    protected abstract BlockPos getPatrolPoint();

    private BlockPos randomNearbyBlock(BlockPos pos, int xz) {
        return pos.add(this.villager.getRNG().nextInt(xz * 2) - xz, 0, this.villager.getRNG().nextInt(xz * 2) - xz);
    }

    @Override
    protected BlockPos getDestinationBlock() {
        BlockPos point = this.getPatrolPoint();
        if (point != null && this.villager.getRNG().nextInt(4) > 0) {
            for (int i = 0; i < 20; ++i) {
                BlockPos testBlock = this.randomNearbyBlock(point, this.distanceFromPoint);
                BasePathingNode baseNode = this.villager.getVillage().getPathingGraph().getNodeYRange(testBlock.getX(), testBlock.getY() - 5, testBlock.getY() + 5, testBlock.getZ());
                if (baseNode == null) continue;
                return baseNode.getBlockPos();
            }
        }
        return point;
    }

    @Override
    protected void onArrival() {
        this.waitRemaining = this.villager.getRNG().nextInt(this.waitTime) + this.waitTime;
        super.onArrival();
    }

    @Override
    public void updateTask() {
        super.updateTask();
        if (this.hasArrived()) {
            --this.waitRemaining;
        }
    }

    @Override
    public void startExecuting() {
        this.waitRemaining = 0;
        super.startExecuting();
    }

    @Override
    void updateMovementMode() {
        this.villager.setMovementMode(this.villager.getDefaultMovement());
    }

    @Override
    protected boolean isNearWalkPos() {
        return this.navigator.getPosition().distanceSq((Vec3i)this.destinationPos) < 4.0;
    }
}

