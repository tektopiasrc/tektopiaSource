/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Predicate
 *  com.google.common.base.Predicates
 *  net.minecraft.entity.Entity
 *  net.minecraft.util.EntitySelectors
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.util.math.Vec3i
 */
package net.tangotek.tektopia.entities.ai;

import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.util.EntitySelectors;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;
import net.tangotek.tektopia.ModSoundEvents;
import net.tangotek.tektopia.VillagerRole;
import net.tangotek.tektopia.entities.EntityVillagerTek;
import net.tangotek.tektopia.entities.ai.EntityAIMoveToBlock;
import net.tangotek.tektopia.pathing.BasePathingNode;
import net.tangotek.tektopia.structures.VillageStructure;
import net.tangotek.tektopia.structures.VillageStructureHome;

public class EntityAIFleeEntity
extends EntityAIMoveToBlock {
    private final Predicate<Entity> entityPredicate;
    private final EntityVillagerTek villager;
    private final float avoidDistance;
    private Entity fleeEntity;
    private BlockPos destPos;

    public EntityAIFleeEntity(EntityVillagerTek v, Predicate<Entity> inPred, float avoidDistanceIn) {
        super(v);
        this.villager = v;
        this.avoidDistance = avoidDistanceIn;
        this.setMutexBits(1);
        this.entityPredicate = Predicates.and(new Predicate[]{EntitySelectors.CAN_AI_TARGET, (Predicate<Entity>)(e -> e.isEntityAlive() && this.villager.getEntitySenses().canSee(e)), inPred});
    }

    @Override
    public boolean shouldExecute() {
        List fleeEnts;
        if (this.villager.isAITick() && this.villager.hasVillage() && !(fleeEnts = this.villager.world.getEntitiesInAABBexcluding((Entity)this.villager, this.villager.getEntityBoundingBox().grow((double)this.avoidDistance, 8.0, (double)this.avoidDistance), this.entityPredicate)).isEmpty()) {
            this.fleeEntity = (Entity)fleeEnts.get(0);
            VillageStructureHome home = this.villager.getHome();
            if (home != null && home.isBlockInside(this.villager.getPosition()) && VillageStructure.isWoodDoor(this.villager.world, home.getDoor()) && !home.isBlockInside(this.fleeEntity.getPosition())) {
                return false;
            }
            BlockPos fleeBlock = this.findRandomTargetAwayFrom(this.fleeEntity);
            if (fleeBlock != null) {
                this.destPos = fleeBlock;
                return super.shouldExecute();
            }
        }
        return false;
    }

    protected BlockPos findRandomTargetAwayFrom(Entity fleeEntity) {
        Vec3d fleeDelta;
        Vec3d villagerPos = this.villager.getPositionVector();
        Vec3d enemyPos = this.fleeEntity.getPositionVector();
        if (this.villager.getBedPos() != null) {
            if (this.villager.getDistanceSq(this.villager.getBedPos()) < 256.0) {
                return this.villager.getBedPos();
            }
            fleeDelta = new Vec3d((Vec3i)this.villager.getBedPos()).subtract(villagerPos);
        } else {
            fleeDelta = this.villager.hasVillage() ? (this.villager.getPosition().distanceSq((Vec3i)this.villager.getVillage().getOrigin()) < 1600.0 ? villagerPos.subtract(enemyPos) : this.villager.getPositionVector().subtract(new Vec3d((Vec3i)this.villager.getVillage().getOrigin()))) : villagerPos.subtract(enemyPos);
        }
        Vec3d fleeDeltaNorm = fleeDelta.normalize();
        Vec3d fleeDir = new Vec3d(fleeDeltaNorm.x, 0.0, fleeDeltaNorm.y);
        if (this.villager.hasVillage() && this.villager.getVillage().getAABB().contains(villagerPos) && villagerPos.add(fleeDir).squareDistanceTo(enemyPos) < villagerPos.squareDistanceTo(enemyPos) && villagerPos.add(fleeDir = fleeDir.rotateYaw(60.0f)).squareDistanceTo(enemyPos) < villagerPos.squareDistanceTo(enemyPos)) {
            fleeDir = fleeDir.rotateYaw(-120.0f);
        }
        Vec3d fleePos = this.villager.getPositionVector().add(fleeDir.scale(16.0));
        BlockPos fleeBlock = new BlockPos(fleePos.x, fleePos.y, fleePos.z);
        for (int i = 0; i < 20; ++i) {
            BlockPos testBlock = this.randomNearbyBlock(fleeBlock, i + 3);
            BasePathingNode baseNode = this.villager.getVillage().getPathingGraph().getNodeYRange(testBlock.getX(), testBlock.getY() - 5, testBlock.getY() + 5, testBlock.getZ());
            if (baseNode == null) continue;
            return baseNode.getBlockPos();
        }
        return null;
    }

    private BlockPos randomNearbyBlock(BlockPos pos, int xz) {
        return pos.add(this.villager.getRNG().nextInt(xz * 2) - xz, 0, this.villager.getRNG().nextInt(xz * 2) - xz);
    }

    @Override
    public void startExecuting() {
        if (!(this.fleeEntity instanceof EntityVillagerTek)) {
            if (!this.villager.isRole(VillagerRole.DEFENDER)) {
                this.villager.modifyHappy(-2);
            }
            if (this.villager.getRNG().nextInt(2) == 0) {
                this.villager.playSound(ModSoundEvents.villagerAfraid);
            }
        }
        super.startExecuting();
    }

    @Override
    void updateMovementMode() {
        this.villager.setMovementMode(EntityVillagerTek.MovementMode.RUN);
    }

    @Override
    protected BlockPos getDestinationBlock() {
        return this.destPos;
    }

    @Override
    public void resetTask() {
        this.fleeEntity = null;
        super.resetTask();
    }
}

