/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.init.Items
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.math.BlockPos
 */
package net.tangotek.tektopia.entities.ai;

import java.util.List;
import java.util.function.Predicate;

import net.minecraft.entity.Entity;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.tangotek.tektopia.ItemTagType;
import net.tangotek.tektopia.ModItems;
import net.tangotek.tektopia.ProfessionType;
import net.tangotek.tektopia.entities.EntityChild;
import net.tangotek.tektopia.entities.EntityTeacher;
import net.tangotek.tektopia.entities.ai.EntityAIMoveToBlock;
import net.tangotek.tektopia.structures.VillageStructure;
import net.tangotek.tektopia.structures.VillageStructureSchool;
import net.tangotek.tektopia.structures.VillageStructureType;
import net.tangotek.tektopia.tickjob.TickJob;

public class EntityAISchoolTeach
extends EntityAIMoveToBlock {
    private VillageStructureSchool school = null;
    private int idleTime = 0;
    private boolean gestured = false;
    private EntityChild watchStudent = null;
    protected final EntityTeacher teacher;

    public EntityAISchoolTeach(EntityTeacher v) {
        super(v);
        this.teacher = v;
    }

    @Override
    public boolean shouldExecute() {
        if (this.teacher.isAITick("teach_school") && this.teacher.hasVillage()) {
            if (EntityTeacher.isSchoolTime(this.teacher.world)) {
                return super.shouldExecute();
            }
        }
        return false;
    }

    @Override
    public boolean shouldContinueExecuting() {
        if (!this.teacher.hasVillage() || !this.teacher.getVillage().isStructureValid(this.school)) {
            return false;
        }
        if (!EntityTeacher.isSchoolTime(this.teacher.world)) {
            return false;
        }
        if (this.idleTime > 0) {
            return true;
        }
        return super.shouldContinueExecuting();
    }

    @Override
    void updateMovementMode() {
        this.teacher.setMovementMode(this.teacher.getDefaultMovement());
    }

    @Override
    public void startExecuting() {
        super.startExecuting();
    }

    @Override
    protected BlockPos findWalkPos() {
        return this.destinationPos;
    }

    @Override
    protected boolean isNearWalkPos() {
        return super.isNearWalkPos();
    }

    @Override
    protected BlockPos getDestinationBlock() {
        VillageStructure struct = this.teacher.getVillage().getNearestStructure(VillageStructureType.SCHOOL, this.teacher.getPosition());
        if (struct != null) {
            this.school = (VillageStructureSchool)struct;
            BlockPos pos = this.school.getRandomFloorTile();
            if (pos != null) {
                return pos;
            }
        }
        return null;
    }

    @Override
    public void updateTask() {
        super.updateTask();
        if (this.hasArrived() && this.watchStudent != null && this.watchStudent.isEntityAlive()) {
            this.teacher.faceEntity((Entity)this.watchStudent, 60.0f, 40.0f);
        }
        if (this.idleTime > 0) {
            --this.idleTime;
        }
        if (this.idleTime > 240 && !this.gestured && this.teacher.getRNG().nextInt(150) == 0) {
            List<ItemStack> bookItems;
            this.gestured = true;
            int studentsInside = this.school.getEntitiesInside(EntityChild.class).size();
            if (studentsInside > 2 && !(bookItems = this.teacher.getInventory().removeItems((Predicate<ItemStack>) p -> p.getItem() == Items.BOOK && !p.isItemEnchanted(), 1)).isEmpty()) {
                int maxGain = 2;
                if (ModItems.isTaggedItem(bookItems.get(0), ItemTagType.VILLAGER)) {
                    maxGain = 1;
                }
                int maxIntGain = maxGain;
                this.teacher.playServerAnimation("villager_teach");
                this.teacher.addJob(new TickJob(8, 0, false, () -> this.teacher.equipActionItem(new ItemStack(Items.BOOK))));
                this.teacher.addJob(new TickJob(50, 0, false, () -> this.teachAll(maxIntGain)));
                this.teacher.addJob(new TickJob(90, 0, false, () -> this.teacher.unequipActionItem()));
                this.teacher.addJob(new TickJob(100, 0, false, () -> this.teacher.stopServerAnimation("villager_teach")));
            }
            if (studentsInside > 0) {
                this.teacher.tryAddSkill(ProfessionType.TEACHER, 4);
            } else {
                this.teacher.throttledSadness(-2);
            }
        }
    }

    private void teachAll(int max) {
        List<EntityChild> students = this.school.getEntitiesInside(EntityChild.class);
        for (EntityChild child : students) {
            int intGain = this.teacher.getRNG().nextInt(this.teacher.getSkillLerp(ProfessionType.TEACHER, 1, max));
            child.addIntelligence(intGain);
        }
        this.teacher.tryAddSkill(ProfessionType.TEACHER, 2);
    }

    @Override
    protected void onArrival() {
        this.idleTime = 200 + this.teacher.getRNG().nextInt(200);
        this.teacher.modifyHunger(-1);
        List<EntityChild> students = this.school.getEntitiesInside(EntityChild.class);
        if (!students.isEmpty()) {
            this.watchStudent = students.get(this.teacher.getRNG().nextInt(students.size()));
        }
        super.onArrival();
    }

    @Override
    public void resetTask() {
        this.idleTime = 0;
        this.watchStudent = null;
        this.gestured = false;
        super.resetTask();
    }
}

