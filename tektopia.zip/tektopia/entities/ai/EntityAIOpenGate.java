/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockFenceGate
 *  net.minecraft.block.properties.IProperty
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.ai.EntityAIBase
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.pathfinding.Path
 *  net.minecraft.pathfinding.PathPoint
 *  net.minecraft.util.math.BlockPos
 */
package net.tangotek.tektopia.entities.ai;

import net.minecraft.block.Block;
import net.minecraft.block.BlockFenceGate;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.pathfinding.Path;
import net.minecraft.pathfinding.PathPoint;
import net.minecraft.util.math.BlockPos;
import net.tangotek.tektopia.entities.EntityVillagerTek;
import net.tangotek.tektopia.pathing.PathNavigateVillager2;

public class EntityAIOpenGate
extends EntityAIBase {
    private EntityVillagerTek villager;
    protected BlockPos gatePosition = BlockPos.ORIGIN;
    protected BlockFenceGate gateBlock;
    boolean hasStoppedDoorInteraction;
    float entityPositionX;
    float entityPositionZ;
    int closeDoorTemporisation;

    public EntityAIOpenGate(EntityVillagerTek v) {
        this.villager = v;
    }

    public boolean shouldExecute() {
        if (!this.villager.collidedHorizontally) {
            return false;
        }
        PathNavigateVillager2 pathNavigate = (PathNavigateVillager2)this.villager.getNavigator();
        Path path = pathNavigate.getPath();
        if (path != null && !path.isFinished() && pathNavigate.getEnterDoors()) {
            for (int i = 0; i < Math.min(path.getCurrentPathIndex() + 2, path.getCurrentPathLength()); ++i) {
                PathPoint pathpoint = path.getPathPointFromIndex(i);
                this.gatePosition = new BlockPos(pathpoint.x, pathpoint.y + 1, pathpoint.z);
                if (!(this.villager.getDistanceSq(this.gatePosition.getX(), this.villager.posY, this.gatePosition.getZ()) <= 2.25)) continue;
                this.gateBlock = this.getBlockGate(this.gatePosition);
                if (this.gateBlock == null) continue;
                return true;
            }
            this.gatePosition = new BlockPos((Entity)this.villager);
            this.gateBlock = this.getBlockGate(this.gatePosition);
            return this.gateBlock != null;
        }
        return false;
    }

    public boolean shouldContinueExecuting() {
        return this.closeDoorTemporisation > 0 && !this.hasStoppedDoorInteraction;
    }

    public void startExecuting() {
        this.closeDoorTemporisation = 20;
        this.toggleGate(this.gatePosition, true);
        this.hasStoppedDoorInteraction = false;
        this.entityPositionX = (float)((double)((float)this.gatePosition.getX() + 0.5f) - this.villager.posX);
        this.entityPositionZ = (float)((double)((float)this.gatePosition.getZ() + 0.5f) - this.villager.posZ);
    }

    public void updateTask() {
        float f1;
        float f = (float)((double)((float)this.gatePosition.getX() + 0.5f) - this.villager.posX);
        float f2 = this.entityPositionX * f + this.entityPositionZ * (f1 = (float)((double)((float)this.gatePosition.getZ() + 0.5f) - this.villager.posZ));
        if (f2 < 0.0f) {
            this.hasStoppedDoorInteraction = true;
        }
        --this.closeDoorTemporisation;
        super.updateTask();
    }

    private BlockFenceGate getBlockGate(BlockPos pos) {
        IBlockState iblockstate = this.villager.world.getBlockState(pos);
        Block block = iblockstate.getBlock();
        return block instanceof BlockFenceGate ? (BlockFenceGate)block : null;
    }

    public void resetTask() {
        this.toggleGate(this.gatePosition, false);
    }

    private void toggleGate(BlockPos gatePosition, boolean open) {
        IBlockState state = this.villager.world.getBlockState(gatePosition);
        if (this.getBlockGate(gatePosition) != null && (Boolean)state.getValue((IProperty)BlockFenceGate.OPEN) != open) {
            state = state.withProperty((IProperty)BlockFenceGate.OPEN, (Comparable)Boolean.valueOf(open));
            this.villager.world.setBlockState(gatePosition, state, 10);
            this.villager.world.playEvent((EntityPlayer)null, (Boolean)state.getValue((IProperty)BlockFenceGate.OPEN) != false ? 1008 : 1014, gatePosition, 0);
        }
    }
}

