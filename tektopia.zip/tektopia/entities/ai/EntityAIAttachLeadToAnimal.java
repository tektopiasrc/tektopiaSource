/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.passive.EntityAnimal
 *  net.minecraft.init.Items
 *  net.minecraft.item.ItemStack
 *  net.minecraft.pathfinding.PathNavigateGround
 *  net.minecraft.util.math.BlockPos
 */
package net.tangotek.tektopia.entities.ai;

import java.util.function.Predicate;
import net.minecraft.entity.Entity;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.pathfinding.PathNavigateGround;
import net.minecraft.util.math.BlockPos;
import net.tangotek.tektopia.entities.EntityMerchant;
import net.tangotek.tektopia.entities.EntityVillagerTek;
import net.tangotek.tektopia.entities.ai.EntityAIFollow;

public abstract class EntityAIAttachLeadToAnimal
extends EntityAIFollow {
    protected EntityAnimal targetAnimal = null;
    private boolean active = false;
    private ItemStack leadItem = new ItemStack(Items.LEAD);
    private int leashTime = 0;
    private Predicate<EntityVillagerTek> shouldPred;
    protected final EntityVillagerTek villager;

    public EntityAIAttachLeadToAnimal(EntityVillagerTek v, Predicate<EntityVillagerTek> shouldPred) {
        super(v);
        this.villager = v;
        this.shouldPred = shouldPred;
    }

    @Override
    public boolean shouldExecute() {
        if (this.villager.isAITick() && this.villager.hasVillage() && this.shouldPred != null && this.shouldPred.test(this.villager)) {
            return super.shouldExecute();
        }
        return false;
    }

    @Override
    public void startExecuting() {
        this.active = true;
        this.villager.equipActionItem(this.leadItem);
        super.startExecuting();
    }

    @Override
    public boolean shouldContinueExecuting() {
        return this.targetAnimal != null && this.active;
    }

    @Override
    public void updateTask() {
        if (this.leashTime > 0) {
            this.villager.getLookHelper().setLookPosition((double)this.destinationPos.getX(), (double)this.destinationPos.getY(), (double)this.destinationPos.getZ(), 30.0f, 30.0f);
            --this.leashTime;
            if (this.leashTime == 0) {
                this.attachLeash();
                this.active = false;
            }
        } else {
            super.updateTask();
        }
    }

    public boolean isInterruptible() {
        return this.leashTime <= 0;
    }

    @Override
    protected void onArrival() {
        if (this.targetAnimal.getLeashHolder() instanceof EntityMerchant) {
            this.targetAnimal.clearLeashed(true, false);
        }
        if (this.targetAnimal.getLeashHolder() != null) {
            this.active = false;
        } else {
            this.startLeash();
        }
        super.onArrival();
    }

    @Override
    protected void onStuck() {
        this.active = false;
        super.onStuck();
    }

    @Override
    protected void onPathFailed(BlockPos pos) {
        this.active = false;
        super.onPathFailed(pos);
    }

    protected void attachLeash() {
        this.targetAnimal.setLeashHolder((Entity)this.villager, true);
        this.villager.setLeadAnimal(this.targetAnimal);
        this.villager.throttledSadness(-3);
        if (this.targetAnimal.getNavigator() instanceof PathNavigateGround) {
            PathNavigateGround navGround = (PathNavigateGround)this.targetAnimal.getNavigator();
            navGround.getNodeProcessor().setCanEnterDoors(true);
            navGround.getNodeProcessor().setCanOpenDoors(true);
        }
        this.active = false;
    }

    private void startLeash() {
        this.villager.debugOut("Attaching lead to animal [ " + this.targetAnimal.getPositionVector() + "]");
        this.leashTime = 36;
        this.villager.getNavigator().clearPath();
        this.villager.playServerAnimation("villager_take");
    }

    private void stopLeash() {
        this.villager.stopServerAnimation("villager_take");
    }

    @Override
    public void resetTask() {
        this.leashTime = 0;
        this.active = false;
        this.targetAnimal = null;
        this.villager.unequipActionItem(this.leadItem);
        this.stopLeash();
        super.resetTask();
    }
}

