/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockDoor
 *  net.minecraft.block.material.Material
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLiving
 *  net.minecraft.entity.ai.EntityAIBase
 *  net.minecraft.pathfinding.Path
 *  net.minecraft.pathfinding.PathPoint
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 */
package net.tangotek.tektopia.entities.ai;

import net.minecraft.block.Block;
import net.minecraft.block.BlockDoor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.pathfinding.Path;
import net.minecraft.pathfinding.PathPoint;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.tangotek.tektopia.entities.EntityVillagerTek;
import net.tangotek.tektopia.pathing.PathNavigateVillager2;

public class EntityAIUseDoor
extends EntityAIBase {
    boolean closeDoor;
    int closeDoorTimer;
    protected EntityLiving entity;
    protected BlockPos doorPosition = BlockPos.ORIGIN;
    protected BlockDoor doorBlock;

    public EntityAIUseDoor(EntityLiving entitylivingIn, boolean shouldClose) {
        this.entity = entitylivingIn;
        this.closeDoor = shouldClose;
    }

    public boolean shouldExecute() {
        if (!this.entity.collidedHorizontally) {
            return false;
        }
        PathNavigateVillager2 pathNavigate = (PathNavigateVillager2)this.entity.getNavigator();
        Path path = pathNavigate.getPath();
        if (path != null && !path.isFinished() && pathNavigate.getEnterDoors()) {
            for (int i = 0; i < Math.min(path.getCurrentPathIndex() + 2, path.getCurrentPathLength()); ++i) {
                PathPoint pathpoint = path.getPathPointFromIndex(i);
                this.doorPosition = new BlockPos(pathpoint.x, pathpoint.y + 1, pathpoint.z);
                if (!(this.entity.getDistanceSq((double)this.doorPosition.getX(), this.entity.posY, (double)this.doorPosition.getZ()) <= 2.25)) continue;
                this.doorBlock = this.getBlockDoor(this.doorPosition);
                if (this.doorBlock == null) continue;
                return true;
            }
            this.doorPosition = new BlockPos((Entity)this.entity).up();
            this.doorBlock = this.getBlockDoor(this.doorPosition);
            return this.doorBlock != null;
        }
        return false;
    }

    private BlockDoor getBlockDoor(BlockPos pos) {
        IBlockState iblockstate = this.entity.world.getBlockState(pos);
        Block block = iblockstate.getBlock();
        return block instanceof BlockDoor && iblockstate.getMaterial() == Material.WOOD ? (BlockDoor)block : null;
    }

    public boolean shouldContinueExecuting() {
        return this.closeDoor && this.closeDoorTimer >= 0;
    }

    private boolean isDoorClear() {
        return this.entity.world.getEntitiesWithinAABB(EntityVillagerTek.class, new AxisAlignedBB(this.doorPosition)).isEmpty();
    }

    public void startExecuting() {
        this.closeDoorTimer = 25;
        this.openDoor(true);
    }

    private void openDoor(boolean open) {
        this.doorBlock.toggleDoor(this.entity.world, this.doorPosition, open);
    }

    public void resetTask() {
        if (this.closeDoor) {
            this.openDoor(false);
        }
    }

    public void updateTask() {
        --this.closeDoorTimer;
        if (this.closeDoorTimer == 0 && !this.isDoorClear()) {
            this.openDoor(true);
            this.closeDoorTimer = 25;
        }
        super.updateTask();
    }
}

