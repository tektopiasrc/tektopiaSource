/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityCreature
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.ai.EntityAIBase
 *  net.minecraft.entity.monster.EntityMob
 *  net.minecraft.entity.passive.EntityAnimal
 *  net.minecraft.pathfinding.Path
 */
package net.tangotek.tektopia.entities.ai;

import java.util.Collections;
import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.pathfinding.Path;
import net.tangotek.tektopia.ModSoundEvents;
import net.tangotek.tektopia.entities.EntityNecromancer;
import net.tangotek.tektopia.entities.EntitySpiritSkull;

public class EntityAISoulLink
extends EntityAIBase {
    private EntityNecromancer necro;
    private EntitySpiritSkull skull;
    private EntityCreature target;
    private int abilityTime = 0;
    private final int ABILITY_LENGTH = 22;

    public EntityAISoulLink(EntityNecromancer v) {
        this.necro = v;
        this.setMutexBits(1);
    }

    public boolean shouldExecute() {
        this.target = null;
        if (this.necro.isAITick() && this.necro.isReadyForSkull()) {
            Path path;
            List<EntityAnimal> animals = this.necro.world.getEntitiesWithinAABB(EntityAnimal.class, this.necro.getEntityBoundingBox().grow(20.0));
            this.target = animals.stream().filter(a -> this.isCreatureInRange((EntityCreature)a) && !this.necro.isCreatureSkulled((EntityCreature)a)).findAny().orElse(null);
            if (this.target == null) {
                List<EntityMob> mobs = this.necro.world.getEntitiesWithinAABB(EntityMob.class, this.necro.getEntityBoundingBox().grow(20.0));
                Collections.shuffle(mobs);
                this.target = mobs.stream().filter(m -> {
                    if (!this.isCreatureInRange((EntityCreature)m)) return false;
                    if (!m.isEntityAlive()) return false;
                    if (!EntityNecromancer.isMinion((EntityLivingBase)m)) return false;
                    if (this.necro.isCreatureSkulled((EntityCreature)m)) return false;
                    return true;
                }).findAny().orElse(null);
            }
            if (this.target != null && ((path = this.necro.getNavigator().getPathToPos(this.target.getPosition())) == null || path.getCurrentPathLength() <= 1)) {
                this.target = null;
            }
        }
        return this.target != null;
    }

    private boolean isCreatureInRange(EntityCreature c) {
        return c.getDistanceSq((Entity)this.necro) < 400.0;
    }

    public void startExecuting() {
        this.startAbility();
    }

    public boolean shouldContinueExecuting() {
        return this.abilityTime > 0;
    }

    public boolean isInterruptible() {
        return false;
    }

    public void updateTask() {
        if (this.abilityTime > 0) {
            --this.abilityTime;
            if (this.abilityTime == 12) {
                this.spawnSkull();
            }
        }
        this.necro.getLookHelper().setLookPositionWithEntity((Entity)this.target, 30.0f, 30.0f);
        super.updateTask();
    }

    private void startAbility() {
        this.abilityTime = 22;
        this.necro.getNavigator().clearPath();
        this.necro.playServerAnimation("necro_siphon");
        this.necro.playSound(ModSoundEvents.deathSkullLeave, this.necro.world.rand.nextFloat() * 0.4f + 1.2f, this.necro.world.rand.nextFloat() * 0.4f + 0.8f);
        this.necro.setSpellTarget((Entity)this.target);
    }

    private void stopAbility() {
        this.necro.stopServerAnimation("necro_siphon");
        this.necro.setSpellTarget(null);
    }

    private void spawnSkull() {
        this.skull = new EntitySpiritSkull(this.necro.world);
        this.skull.setLocationAndAngles(this.target.posX, this.target.posY + (double)this.target.getEyeHeight(), this.target.posZ, this.target.rotationYaw, 0.0f);
        this.necro.world.spawnEntity((Entity)this.skull);
        this.skull.setSkullCreature(this.target);
        this.necro.addSkull(this.skull);
        EntityNecromancer.makeMinion((EntityLivingBase)this.target, this.necro);
    }

    public void resetTask() {
        this.stopAbility();
        this.abilityTime = 0;
    }
}

