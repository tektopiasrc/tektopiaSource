/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 */
package net.tangotek.tektopia.entities.ai;

import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.tangotek.tektopia.ModSoundEvents;
import net.tangotek.tektopia.ProfessionType;
import net.tangotek.tektopia.entities.EntityCleric;
import net.tangotek.tektopia.entities.EntityVillagerTek;
import net.tangotek.tektopia.entities.ai.EntityAIFollow;

public class EntityAIHeal
extends EntityAIFollow {
    private boolean arrived = false;
    private int castTime = 0;
    private EntityCleric cleric;
    private final int CAST_TIME = 80;
    private final int HUNGER_COST = 8;
    private final double healRange;
    private EntityVillagerTek healVillager = null;

    public EntityAIHeal(EntityVillagerTek entityIn, double range) {
        super(entityIn);
        this.cleric = (EntityCleric)entityIn;
        this.healRange = range;
    }

    @Override
    public boolean shouldExecute() {
        this.healVillager = null;
        if (this.cleric.isAIFilterEnabled("cast_heal") && this.cleric.hasVillage() && !this.cleric.isSleeping() && this.cleric.getHunger() > 16) {
            List healCandidates;
            if (this.cleric.getHealth() < this.cleric.getMaxHealth()) {
                this.healVillager = this.cleric;
            }
            if (this.healVillager == null) {
                this.healVillager = this.cleric.getVillage().getActiveDefender(this.cleric.getPosition());
                if (this.healVillager != null && this.inRange() && this.healVillager.getHealth() >= this.healVillager.getMaxHealth()) {
                    this.healVillager = null;
                }
            }
            if (this.healVillager == null && this.cleric.isAITick() && !(healCandidates = this.cleric.world.getEntitiesWithinAABB(EntityVillagerTek.class, this.cleric.getEntityBoundingBox().grow(30.0, 8.0, 30.0), v -> v.getHealth() < v.getMaxHealth())).isEmpty()) {
                this.healVillager = (EntityVillagerTek)((Object)healCandidates.get(0));
            }
            if (this.healVillager != null) {
                return super.shouldExecute();
            }
        }
        return false;
    }

    @Override
    protected void onArrival() {
        if (!this.arrived) {
            this.tryHeal();
        }
        this.arrived = true;
        super.onArrival();
    }

    @Override
    public void startExecuting() {
        super.startExecuting();
    }

    protected boolean inRange() {
        if (this.getFollowTarget() != null) {
            double distSq = this.getFollowTarget().getDistanceSq((Entity)this.cleric);
            return distSq < this.healRange * this.healRange;
        }
        return false;
    }

    @Override
    protected boolean isNearWalkPos() {
        return this.inRange();
    }

    public boolean isInterruptible() {
        return this.castTime <= 0;
    }

    protected void tryHeal() {
        if (this.cleric.isEntityAlive() && this.followTarget.isEntityAlive() && this.inRange() && this.followTarget.getHealth() < this.followTarget.getMaxHealth()) {
            this.castTime = 80;
            this.cleric.playServerAnimation("villager_summon");
            this.cleric.modifyHunger(-8);
            this.cleric.getNavigator().clearPath();
            this.setArrived();
            this.cleric.setSpellTarget((Entity)this.healVillager);
            this.cleric.playSound(ModSoundEvents.healingSource);
        }
    }

    @Override
    public void updateTask() {
        --this.castTime;
        if (this.castTime == 36) {
            this.cleric.playSound(ModSoundEvents.villagerEnchant);
            if (this.healVillager.isEntityAlive() && this.healVillager.getHealth() < this.healVillager.getMaxHealth()) {
                this.healVillager.heal(this.cleric.getSkillLerp(ProfessionType.CLERIC, 3, 6));
                this.healVillager.playSound(ModSoundEvents.healingTarget);
                this.healVillager.modifyHappy(10);
                this.cleric.modifyHappy(2);
                this.cleric.tryAddSkill(ProfessionType.CLERIC, 3);
            }
        }
        super.updateTask();
    }

    @Override
    protected EntityLivingBase getFollowTarget() {
        return this.healVillager;
    }

    @Override
    protected boolean shouldFollow() {
        if (this.castTime > 0) {
            return false;
        }
        return super.shouldFollow();
    }

    @Override
    public void resetTask() {
        this.cleric.setMovementMode(this.cleric.getDefaultMovement());
        this.cleric.stopServerAnimation("villager_summon");
        this.cleric.setSpellTarget(null);
        this.arrived = false;
        this.castTime = 0;
        super.resetTask();
    }

    @Override
    public boolean shouldContinueExecuting() {
        if (this.castTime > 0) {
            return true;
        }
        if (!this.healVillager.isEntityAlive()) {
            return false;
        }
        if (this.inRange() && this.healVillager.getHealth() >= this.healVillager.getMaxHealth()) {
            return false;
        }
        return super.shouldContinueExecuting();
    }

    @Override
    void updateMovementMode() {
        this.cleric.setMovementMode(EntityVillagerTek.MovementMode.RUN);
    }
}

