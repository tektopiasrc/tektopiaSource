/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.BlockHorizontal
 *  net.minecraft.block.properties.IProperty
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.util.math.Vec3i
 */
package net.tangotek.tektopia.entities.ai;

import java.util.function.Predicate;
import net.minecraft.block.BlockHorizontal;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;
import net.tangotek.tektopia.ProfessionType;
import net.tangotek.tektopia.entities.EntityTeacher;
import net.tangotek.tektopia.entities.EntityVillagerTek;
import net.tangotek.tektopia.entities.ai.EntityAIMoveToBlock;
import net.tangotek.tektopia.structures.VillageStructure;
import net.tangotek.tektopia.structures.VillageStructureSchool;
import net.tangotek.tektopia.structures.VillageStructureType;
import net.tangotek.tektopia.tickjob.TickJob;

public class EntityAISchoolAttend
extends EntityAIMoveToBlock {
    private BlockPos chairPos;
    private VillageStructureSchool school;
    private int learnTime = 0;
    protected final EntityVillagerTek villager;
    private final Predicate<EntityVillagerTek> shouldPred;

    public EntityAISchoolAttend(EntityVillagerTek v, Predicate<EntityVillagerTek> shouldPred) {
        super(v);
        this.villager = v;
        this.shouldPred = shouldPred;
    }

    @Override
    public boolean shouldExecute() {
        if (this.villager.isAITick("attend_school") && this.villager.hasVillage() && this.shouldPred.test(this.villager) && this.villager.isWorkTime() && super.shouldExecute() && this.school != null) {
            if (this.school.hasTeacherInside()) {
                return true;
            }
            this.villager.setThought(EntityVillagerTek.VillagerThought.TEACHER);
        }
        return false;
    }

    @Override
    public boolean shouldContinueExecuting() {
        if (this.hasArrived() && this.chairPos != null && this.school.isValid() && this.school.hasTeacherInside() && EntityTeacher.isSchoolTime(this.villager.world)) {
            return true;
        }
        return super.shouldContinueExecuting();
    }

    @Override
    void updateMovementMode() {
        if (this.villager.getRNG().nextInt(5) == 0) {
            this.villager.setMovementMode(EntityVillagerTek.MovementMode.SULK);
            this.villager.modifyHappy(-10);
        } else {
            this.villager.setMovementMode(this.villager.getDefaultMovement());
        }
    }

    @Override
    public void startExecuting() {
        super.startExecuting();
    }

    @Override
    protected BlockPos findWalkPos() {
        return this.destinationPos;
    }

    @Override
    protected boolean isNearWalkPos() {
        if (this.chairPos != null) {
            return this.chairPos != null && this.chairPos.distanceSq((Vec3i)this.villager.getPosition()) <= 1.0;
        }
        return super.isNearWalkPos();
    }

    @Override
    protected BlockPos getDestinationBlock() {
        VillageStructure struct = this.villager.getVillage().getNearestStructure(VillageStructureType.SCHOOL, this.villager.getPosition());
        if (struct != null) {
            this.school = (VillageStructureSchool)struct;
            if (this.school.hasTeacherInside()) {
                this.chairPos = this.school.tryVillagerSit(this.villager);
                if (this.chairPos != null) {
                    return this.chairPos;
                }
            }
        }
        return null;
    }

    @Override
    public void updateTask() {
        if (this.learnTime > 0) {
            --this.learnTime;
            if (this.learnTime % 10 == 0) {
                this.moveToSitPos();
            }
            if (this.learnTime == 90) {
                EntityTeacher teacher = this.school.getTeacherInside();
                if (teacher != null) {
                    int schoolEvent = this.villager.getRNG().nextInt(teacher.getSkillLerp(ProfessionType.TEACHER, 18, 9));
                    if (schoolEvent <= 2) {
                        this.villager.addIntelligence(1);
                    } else {
                        if (schoolEvent <= 7) {
                            this.villager.playServerAnimation("villager_sit_raise");
                            this.villager.addJob(new TickJob(80, 0, false, () -> this.villager.playServerAnimation("villager_sit")));
                            teacher.throttledSadness(-1);
                        }
                        teacher.tryAddSkill(ProfessionType.TEACHER, 50);
                    }
                }
            } else if (this.learnTime <= 0) {
                this.startLearn();
            }
        }
        super.updateTask();
    }

    @Override
    protected void onArrival() {
        if (this.chairPos != null) {
            this.villager.setMovementMode(this.villager.getDefaultMovement());
            this.startSit();
            this.startLearn();
        }
        super.onArrival();
    }

    private void startLearn() {
        this.learnTime = 150 + this.villager.getRNG().nextInt(150);
        if (this.school.hasTeacherInside()) {
            this.learnTime -= this.school.getTeacherInside().getSkill(ProfessionType.TEACHER);
        }
    }

    private EnumFacing getChairFacing() {
        if (this.chairPos != null && this.villager.world.isBlockLoaded(this.chairPos)) {
            IBlockState state = this.villager.world.getBlockState(this.chairPos);
            EnumFacing enumfacing = state.getBlock() instanceof BlockHorizontal ? ((EnumFacing)state.getValue((IProperty)BlockHorizontal.FACING)).getOpposite() : null;
            return enumfacing;
        }
        return null;
    }

    private int getChairAxis() {
        EnumFacing facing = this.getChairFacing();
        if (facing != null) {
            return facing.getHorizontalIndex();
        }
        return -1;
    }

    private void startSit() {
        int chairAxis = this.getChairAxis();
        if (chairAxis >= 0) {
            this.moveToSitPos();
            this.villager.onStartSit(chairAxis);
        }
    }

    private Vec3d getSitPos() {
        return new Vec3d((double)this.destinationPos.getX() + 0.5, (double)this.destinationPos.getY() + this.villager.getSitOffset(), (double)this.destinationPos.getZ() + 0.5);
    }

    private void moveTo(Vec3d pos) {
        this.villager.setLocationAndAngles(pos.x, pos.y, pos.z, this.villager.rotationYaw, this.villager.rotationPitch);
        this.villager.motionX = 0.0;
        this.villager.motionY = 0.0;
        this.villager.motionZ = 0.0;
    }

    private void moveToSitPos() {
        Vec3d sitPos = this.getSitPos();
        if (this.villager.getPositionVector().squareDistanceTo(sitPos.x, sitPos.y, sitPos.z) > 0.05) {
            this.moveTo(sitPos);
        }
    }

    @Override
    public void resetTask() {
        if (this.chairPos != null && this.school != null && this.school.isValid()) {
            this.school.vacateSpecialBlock(this.chairPos);
            this.chairPos = null;
        }
        this.villager.setMovementMode(this.villager.getDefaultMovement());
        this.villager.onStopSit();
        this.learnTime = 0;
        super.resetTask();
    }
}

