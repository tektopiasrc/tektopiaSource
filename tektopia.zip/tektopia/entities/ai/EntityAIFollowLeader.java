/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityCreature
 *  net.minecraft.entity.ai.EntityAIBase
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.MathHelper
 *  net.minecraftforge.common.MinecraftForge
 *  net.minecraftforge.event.entity.living.LivingSetAttackTargetEvent
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package net.tangotek.tektopia.entities.ai;

import java.util.Random;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.living.LivingSetAttackTargetEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.tangotek.tektopia.entities.EntityVillageNavigator;
import net.tangotek.tektopia.pathing.BasePathingNode;

public class EntityAIFollowLeader
extends EntityAIBase {
    private final EntityCreature creature;
    private final EntityVillageNavigator leader;
    private final double movementSpeed;
    private final int clusterSize;
    private int nextTick = 0;
    private BlockPos followPos;
    private boolean farAway = false;

    public EntityAIFollowLeader(EntityCreature creatureIn, EntityVillageNavigator leader, int clusterSize, double speedIn) {
        this.creature = creatureIn;
        this.movementSpeed = speedIn;
        this.clusterSize = clusterSize;
        this.leader = leader;
        this.nextTick = this.getTickRate(creatureIn);
        this.setMutexBits(1);
        MinecraftForge.EVENT_BUS.register((Object)this);
    }

    @SubscribeEvent
    public void onLivingSetAttackTargetEvent(LivingSetAttackTargetEvent event) {
        if (event.getEntity() == this.creature && this.farAway && event.getTarget() != null) {
            this.creature.setAttackTarget(null);
        }
    }

    public boolean shouldExecute() {
        if (this.leader.isDead) {
            this.creature.setDead();
        }
        if (this.creature.isEntityAlive() && this.leader.hasVillage() && (this.farAway || this.creature.ticksExisted > this.nextTick)) {
            this.nextTick += 20;
            boolean bl = this.farAway = this.creature.getDistanceSq((Entity)this.leader) > 900.0;
            if (this.farAway) {
                this.creature.setAttackTarget(null);
            }
            if (this.creature.getAttackTarget() == null) {
                this.followPos = this.getFollowPos(this.leader, this.leader.getNavigator().noPath() ? 4.0f : 10.0f, this.clusterSize);
                if (this.followPos != null && this.creature.getDistanceSq(this.followPos) > (double)(this.clusterSize * this.clusterSize)) {
                    return true;
                }
            }
        }
        return false;
    }

    private BlockPos getFollowPos(EntityVillageNavigator leader, float forwardDist, int clusterSize) {
        float distance = forwardDist;
        float f1 = MathHelper.sin((float)(leader.rotationYaw * ((float)Math.PI / 180)));
        float f2 = MathHelper.cos((float)(leader.rotationYaw * ((float)Math.PI / 180)));
        double behindX = -distance * f1;
        double behindZ = distance * f2;
        BlockPos testPos = new BlockPos(leader.posX + behindX, leader.posY, leader.posZ + behindZ);
        for (int i = 0; i < 20; ++i) {
            BlockPos testBlock = this.randomNearbyBlock(testPos, clusterSize);
            BasePathingNode baseNode = leader.getVillage().getPathingGraph().getNodeYRange(testBlock.getX(), testBlock.getY() - 5, testBlock.getY() + 5, testBlock.getZ());
            if (baseNode == null || leader.getVillage().isInStructure(testBlock)) continue;
            return baseNode.getBlockPos();
        }
        return null;
    }

    private BlockPos randomNearbyBlock(BlockPos pos, int xz) {
        Random rnd = this.leader.getRNG();
        int x = MathHelper.getInt((Random)rnd, (int)(-xz), (int)xz);
        int z = MathHelper.getInt((Random)rnd, (int)(-xz), (int)xz);
        return pos.add(x, 0, z);
    }

    public boolean shouldContinueExecuting() {
        return !this.creature.getNavigator().noPath();
    }

    public void startExecuting() {
        this.nextTick = this.creature.ticksExisted + this.getTickRate(this.creature);
        this.creature.getNavigator().tryMoveToXYZ((double)this.followPos.getX(), (double)this.followPos.getY(), (double)this.followPos.getZ(), this.movementSpeed);
    }

    private int getTickRate(EntityCreature creature) {
        return creature.world.rand.nextInt(30) + 60;
    }
}

