/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.leviathanstudio.craftstudio.common.animation.AnimationHandler
 *  javax.annotation.Nullable
 *  net.minecraft.block.Block
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.IEntityLivingData
 *  net.minecraft.entity.SharedMonsterAttributes
 *  net.minecraft.entity.ai.EntityAIBase
 *  net.minecraft.entity.passive.EntityAnimal
 *  net.minecraft.entity.passive.EntityChicken
 *  net.minecraft.entity.passive.EntityCow
 *  net.minecraft.entity.passive.EntityPig
 *  net.minecraft.entity.passive.EntitySheep
 *  net.minecraft.init.Blocks
 *  net.minecraft.init.Items
 *  net.minecraft.init.SoundEvents
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemAxe
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.ItemTool
 *  net.minecraft.network.datasync.DataParameter
 *  net.minecraft.network.datasync.DataSerializer
 *  net.minecraft.network.datasync.DataSerializers
 *  net.minecraft.network.datasync.EntityDataManager
 *  net.minecraft.util.DamageSource
 *  net.minecraft.util.SoundEvent
 *  net.minecraft.world.DifficultyInstance
 *  net.minecraft.world.World
 */
package net.tangotek.tektopia.entities;

import com.leviathanstudio.craftstudio.common.animation.AnimationHandler;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.function.Predicate;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityChicken;
import net.minecraft.entity.passive.EntityCow;
import net.minecraft.entity.passive.EntityPig;
import net.minecraft.entity.passive.EntitySheep;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemTool;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializer;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.DamageSource;
import net.minecraft.util.SoundEvent;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.World;
import net.tangotek.tektopia.EntityTagType;
import net.tangotek.tektopia.ItemTagType;
import net.tangotek.tektopia.ModEntities;
import net.tangotek.tektopia.ModItems;
import net.tangotek.tektopia.ProfessionType;
import net.tangotek.tektopia.TekVillager;
import net.tangotek.tektopia.VillagerRole;
import net.tangotek.tektopia.entities.EntityVillagerTek;
import net.tangotek.tektopia.entities.ai.EntityAIAttachLeadToButcherAnimal;
import net.tangotek.tektopia.entities.ai.EntityAICraftItems;
import net.tangotek.tektopia.entities.ai.EntityAIKillInStructure;
import net.tangotek.tektopia.entities.ai.EntityAILeadAnimalToStructure;
import net.tangotek.tektopia.entities.ai.EntityAIMeleeTarget;
import net.tangotek.tektopia.entities.crafting.Recipe;
import net.tangotek.tektopia.storage.UpgradeItemDesire;
import net.tangotek.tektopia.structures.VillageStructureType;

public class EntityButcher
extends EntityVillagerTek {
    protected static AnimationHandler animHandler = TekVillager.getNewAnimationHandler(EntityButcher.class);
    private static final DataParameter<Boolean> RETRIEVE_CHICKENS = EntityDataManager.createKey(EntityButcher.class, (DataSerializer)DataSerializers.BOOLEAN);
    private static final DataParameter<Boolean> RETRIEVE_COWS = EntityDataManager.createKey(EntityButcher.class, (DataSerializer)DataSerializers.BOOLEAN);
    private static final DataParameter<Boolean> RETRIEVE_PIGS = EntityDataManager.createKey(EntityButcher.class, (DataSerializer)DataSerializers.BOOLEAN);
    private static final DataParameter<Boolean> RETRIEVE_SHEEP = EntityDataManager.createKey(EntityButcher.class, (DataSerializer)DataSerializers.BOOLEAN);
    private static final DataParameter<Boolean> BUTCHER_ANIMALS = EntityDataManager.createKey(EntityButcher.class, (DataSerializer)DataSerializers.BOOLEAN);
    private static List<Recipe> craftSet = EntityButcher.buildCraftSet();
    private static final Map<String, DataParameter<Boolean>> RECIPE_PARAMS;

    public EntityButcher(World worldIn) {
        super(worldIn, ProfessionType.BUTCHER, VillagerRole.VILLAGER.value);
    }

    @Override
    public AnimationHandler getAnimationHandler() {
        return animHandler;
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getAttributeMap().registerAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(5.0);
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        craftSet.forEach(r -> this.registerAIFilter(r.getAiFilter(), RECIPE_PARAMS.get(r.getAiFilter())));
        this.registerAIFilter("retrieve_chickens", RETRIEVE_CHICKENS);
        this.registerAIFilter("retrieve_cows", RETRIEVE_COWS);
        this.registerAIFilter("retrieve_pigs", RETRIEVE_PIGS);
        this.registerAIFilter("retrieve_sheep", RETRIEVE_SHEEP);
        this.registerAIFilter("butcher_animals", BUTCHER_ANIMALS);
    }

    @Override
    protected void initEntityAI() {
        super.initEntityAI();
        this.getDesireSet().addItemDesire(new UpgradeItemDesire("Axe", EntityButcher.getBestAxe(), 1, 1, 1, p -> p.isWorkTime()));
        craftSet.forEach(r -> this.getDesireSet().addRecipeDesire((Recipe)r));
        Runnable onHit = () -> {
            this.tryAddSkill(ProfessionType.BUTCHER, 8);
            this.modifyHunger(-5);
        };
        this.tasks.addTask(50, (EntityAIBase)new EntityAIMeleeTarget(this, p -> EntityButcher.getWeapon(this), EntityVillagerTek.VillagerThought.AXE, p -> p.isWorkTime() && p.isAIFilterEnabled("butcher_animals"), onHit, ProfessionType.BUTCHER));
        this.tasks.addTask(50, (EntityAIBase)new EntityAILeadAnimalToStructure(this, VillageStructureType.BUTCHER, EntityTagType.BUTCHERED));
        this.tasks.addTask(50, (EntityAIBase)new EntityAIAttachLeadToButcherAnimal(this, p -> p.isWorkTime()));
        this.tasks.addTask(50, (EntityAIBase)new EntityAICraftItems(this, craftSet, "villager_craft", null, 80, VillageStructureType.BUTCHER, Blocks.CRAFTING_TABLE, p -> p.isWorkTime()));
        this.targetTasks.addTask(1, (EntityAIBase)new EntityAIKillInStructure(this, VillageStructureType.BUTCHER, EntityAnimal.class, EntityButcher.isTarget(), p -> p.isWorkTime()));
    }

    @Override
    @Nullable
    public IEntityLivingData onInitialSpawn(DifficultyInstance difficulty, @Nullable IEntityLivingData livingdata) {
        this.getInventory().addItem(ModItems.makeTaggedItem(new ItemStack(Items.WOODEN_AXE), ItemTagType.VILLAGER));
        return super.onInitialSpawn(difficulty, livingdata);
    }

    public static Predicate<EntityLivingBase> isTarget() {
        return p -> p instanceof EntitySheep || p instanceof EntityCow || p instanceof EntityChicken || p instanceof EntityPig;
    }

    public static Function<ItemStack, Integer> getBestAxe() {
        return p -> {
            if (p.getItem() instanceof ItemAxe) {
                int score = p.getMaxDamage() * 10;
                if (ModItems.isTaggedItem(p, ItemTagType.VILLAGER)) {
                    ++score;
                }
                return score;
            }
            return -1;
        };
    }

    private static List<Recipe> buildCraftSet() {
        ArrayList<Recipe> recipes = new ArrayList<Recipe>();
        ArrayList<ItemStack> ingredients = new ArrayList<ItemStack>();
        ingredients.add(new ItemStack(Item.getItemFromBlock((Block)Blocks.LOG), 1, 99));
        Recipe recipe = new Recipe(ProfessionType.BUTCHER, "craft_wooden_axe", 3, new ItemStack(Items.WOODEN_AXE, 1), ingredients, 1, 1, v -> 12 - v.getSkillLerp(ProfessionType.BUTCHER, 1, 10), 1, p -> EntityButcher.getWeapon(p).isEmpty()){

            @Override
            public ItemStack craft(EntityVillagerTek villager) {
                ItemStack result = super.craft(villager);
                villager.modifyHappy(-5);
                return result;
            }
        };
        recipes.add(recipe);
        ingredients = new ArrayList();
        ingredients.add(new ItemStack(Items.LEATHER, 8));
        recipe = new Recipe(ProfessionType.BUTCHER, "craft_leather_chestplate", 2, new ItemStack((Item)Items.LEATHER_CHESTPLATE, 1), ingredients, 1, 1, v -> v.getSkillLerp(ProfessionType.BUTCHER, 8, 4), 1);
        recipes.add(recipe);
        ingredients = new ArrayList();
        ingredients.add(new ItemStack(Items.LEATHER, 7));
        recipe = new Recipe(ProfessionType.BUTCHER, "craft_leather_leggings", 2, new ItemStack((Item)Items.LEATHER_LEGGINGS, 1), ingredients, 1, 1, v -> v.getSkillLerp(ProfessionType.BUTCHER, 7, 3), 1);
        recipes.add(recipe);
        ingredients = new ArrayList();
        ingredients.add(new ItemStack(Items.LEATHER, 4));
        recipe = new Recipe(ProfessionType.BUTCHER, "craft_leather_boots", 3, new ItemStack((Item)Items.LEATHER_BOOTS, 1), ingredients, 1, 1, v -> v.getSkillLerp(ProfessionType.BUTCHER, 4, 2), 1);
        recipes.add(recipe);
        ingredients = new ArrayList();
        ingredients.add(new ItemStack(Items.LEATHER, 5));
        recipe = new Recipe(ProfessionType.BUTCHER, "craft_leather_helmet", 3, new ItemStack((Item)Items.LEATHER_HELMET, 1), ingredients, 1, 1, v -> v.getSkillLerp(ProfessionType.BUTCHER, 5, 3), 1);
        recipes.add(recipe);
        return recipes;
    }

    private static int getToolBonusValue(ItemTool tool) {
        if (tool != null) {
            if (tool.getToolMaterialName().equals("STONE")) {
                return 10;
            }
            if (tool.getToolMaterialName().equals("IRON")) {
                return 30;
            }
            if (tool.getToolMaterialName().equals("DIAMOND")) {
                return 45;
            }
        }
        return 0;
    }

    public void onKillEntity(EntityLivingBase entityLivingIn) {
        int bonusMeat = 0;
        int extraChance = this.getSkill(ProfessionType.BUTCHER);
        ItemStack tool = EntityButcher.getWeapon(this);
        if (!tool.isEmpty()) {
            extraChance += EntityButcher.getToolBonusValue((ItemTool)tool.getItem());
        }
        if (this.getRNG().nextInt(100) < extraChance) {
            ++bonusMeat;
        }
        if (this.getRNG().nextInt(100) < extraChance) {
            ++bonusMeat;
        }
        Item meat = null;
        SoundEvent soundEvent = null;
        if (entityLivingIn instanceof EntityCow) {
            meat = Items.BEEF;
            soundEvent = SoundEvents.ENTITY_COW_DEATH;
        } else if (entityLivingIn instanceof EntityPig) {
            meat = Items.PORKCHOP;
            soundEvent = SoundEvents.ENTITY_PIG_DEATH;
        } else if (entityLivingIn instanceof EntitySheep) {
            meat = Items.MUTTON;
            soundEvent = SoundEvents.ENTITY_SHEEP_DEATH;
        } else if (entityLivingIn instanceof EntityChicken) {
            meat = Items.CHICKEN;
            soundEvent = SoundEvents.ENTITY_CHICKEN_DEATH;
        }
        if (soundEvent != null) {
            this.playSound(soundEvent, 2.0f, this.getSoundPitch());
        }
        if (bonusMeat > 0 && this.world.getGameRules().getBoolean("doMobLoot")) {
            ItemStack meatStack = new ItemStack(meat, bonusMeat);
            if (ModEntities.isTaggedEntity((Entity)entityLivingIn, EntityTagType.VILLAGER)) {
                ModItems.makeTaggedItem(meatStack, ItemTagType.VILLAGER);
            }
            entityLivingIn.entityDropItem(meatStack, (float)bonusMeat);
        }
        super.onKillEntity(entityLivingIn);
    }

    public static ItemStack getWeapon(EntityVillagerTek villager) {
        List<ItemStack> weaponList = villager.getInventory().getItems(EntityButcher.getBestAxe(), 1);
        if (!weaponList.isEmpty()) {
            return weaponList.get(0);
        }
        return ItemStack.EMPTY;
    }

    public Predicate<ItemStack> isMeat() {
        return p -> p.getItem() == Items.BEEF || p.getItem() == Items.PORKCHOP || p.getItem() == Items.MUTTON || p.getItem() == Items.CHICKEN;
    }

    public Predicate<ItemStack> isAnimalProduct() {
        return p -> p.getItem() == Items.FEATHER || p.getItem() == Item.getItemFromBlock((Block)Blocks.WOOL) || p.getItem() == Items.EGG || p.getItem() == Items.LEATHER;
    }

    @Override
    public Predicate<ItemStack> isHarvestItem() {
        return p -> this.isMeat().test((ItemStack)p) || this.isAnimalProduct().test((ItemStack)p);
    }

    public boolean attackEntityAsMob(Entity entityIn) {
        float damage = (float)this.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).getAttributeValue();
        boolean flag = entityIn.attackEntityFrom(DamageSource.causeMobDamage((EntityLivingBase)this), damage);
        return flag;
    }

    @Override
    protected boolean canVillagerPickupItem(ItemStack itemIn) {
        return this.isHarvestItem().test(itemIn) || super.canVillagerPickupItem(itemIn);
    }

    static {
        animHandler.addAnim("tektopia", "villager_take", "butcher_m", false);
        animHandler.addAnim("tektopia", "villager_chop", "butcher_m", false);
        animHandler.addAnim("tektopia", "villager_craft", "butcher_m", false);
        EntityVillagerTek.setupAnimations(animHandler, "butcher_m");
        RECIPE_PARAMS = new HashMap<String, DataParameter<Boolean>>();
        craftSet.forEach(r -> RECIPE_PARAMS.put(r.getAiFilter(), (DataParameter<Boolean>)EntityDataManager.createKey(EntityButcher.class, (DataSerializer)DataSerializers.BOOLEAN)));
    }
}

