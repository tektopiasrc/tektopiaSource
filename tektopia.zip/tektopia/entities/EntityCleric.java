/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.leviathanstudio.craftstudio.common.animation.AnimationHandler
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.ai.EntityAIBase
 *  net.minecraft.network.datasync.DataParameter
 *  net.minecraft.network.datasync.DataSerializer
 *  net.minecraft.network.datasync.DataSerializers
 *  net.minecraft.network.datasync.EntityDataManager
 *  net.minecraft.util.EnumParticleTypes
 *  net.minecraft.util.SoundCategory
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.world.World
 */
package net.tangotek.tektopia.entities;

import com.leviathanstudio.craftstudio.common.animation.AnimationHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializer;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import net.tangotek.tektopia.ModSoundEvents;
import net.tangotek.tektopia.ProfessionType;
import net.tangotek.tektopia.TekVillager;
import net.tangotek.tektopia.Village;
import net.tangotek.tektopia.VillagerRole;
import net.tangotek.tektopia.entities.EntityVillagerTek;
import net.tangotek.tektopia.entities.ai.EntityAIBless;
import net.tangotek.tektopia.entities.ai.EntityAIFleeEntity;
import net.tangotek.tektopia.entities.ai.EntityAIHeal;
import net.tangotek.tektopia.entities.ai.EntityAIPatrolVillage;

public class EntityCleric
extends EntityVillagerTek {
    protected static AnimationHandler animHandler = TekVillager.getNewAnimationHandler(EntityCleric.class);
    private static final DataParameter<Integer> SPELL_TARGET = EntityDataManager.createKey(EntityCleric.class, (DataSerializer)DataSerializers.VARINT);
    private static final DataParameter<Boolean> CAST_BLESS = EntityDataManager.createKey(EntityCleric.class, (DataSerializer)DataSerializers.BOOLEAN);
    private static final DataParameter<Boolean> CAST_HEAL = EntityDataManager.createKey(EntityCleric.class, (DataSerializer)DataSerializers.BOOLEAN);
    private int handParticleTick = 0;

    public EntityCleric(World worldIn) {
        super(worldIn, ProfessionType.CLERIC, VillagerRole.VILLAGER.value | VillagerRole.DEFENDER.value);
        Runnable enchantRunner = new Runnable(){

            @Override
            public void run() {
                EntityCleric.this.world.playSound(EntityCleric.this.posX, EntityCleric.this.posY, EntityCleric.this.posZ, ModSoundEvents.villagerEnchant, SoundCategory.NEUTRAL, 1.0f, EntityCleric.this.rand.nextFloat() * 0.2f + 0.9f, false);
            }
        };
        if (this.world.isRemote) {
            this.addAnimationTrigger("tektopia:villager_summon", 12, enchantRunner);
            this.addAnimationTrigger("tektopia:villager_summon", 20, new Runnable(){

                @Override
                public void run() {
                    EntityCleric.this.handParticleTick = 25;
                }
            });
            this.addAnimationTrigger("tektopia:villager_summon", 32, enchantRunner);
        }
    }

    @Override
    public AnimationHandler getAnimationHandler() {
        return animHandler;
    }

    @Override
    protected void initEntityAI() {
        super.initEntityAI();
        this.addTask(49, new EntityAIHeal(this, 16.0));
        this.addTask(50, new EntityAIBless(this, 12.0));
        this.addTask(50, new EntityAIPatrolVillage(this, p -> !p.isSleepingTime()));
    }

    @Override
    public void attachToVillage(Village v) {
        super.attachToVillage(v);
        this.sleepOffset = v.getNextClericSleepOffset();
    }

    @Override
    protected void addTask(int priority, EntityAIBase task) {
        if (task instanceof EntityAIFleeEntity) {
            return;
        }
        super.addTask(priority, task);
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        this.dataManager.register(SPELL_TARGET, 0);
        this.registerAIFilter("cast_bless", CAST_BLESS);
        this.registerAIFilter("cast_heal", CAST_HEAL);
    }

    @Override
    public EntityVillagerTek.MovementMode getDefaultMovement() {
        if (this.village.enemySeenRecently()) {
            return EntityVillagerTek.MovementMode.RUN;
        }
        return super.getDefaultMovement();
    }

    public boolean isSpellcasting() {
        int entityId = (Integer)this.dataManager.get(SPELL_TARGET);
        return entityId > 0;
    }

    public Entity getSpellTargetEntity() {
        int entityId = (Integer)this.dataManager.get(SPELL_TARGET);
        if (entityId > 0) {
            return this.world.getEntityByID(entityId);
        }
        return null;
    }

    public void setSpellTarget(Entity entity) {
        if (entity == null) {
            this.dataManager.set(SPELL_TARGET, 0);
        } else {
            this.dataManager.set(SPELL_TARGET, entity.getEntityId());
        }
    }

    public void onUpdate() {
        super.onUpdate();
        if (this.world.isRemote && this.isSpellcasting() && this.handParticleTick > 0) {
            Entity spellTarget;
            double d0 = 0.7;
            double d1 = 0.7;
            double d2 = 0.7;
            float f = this.renderYawOffset * ((float)Math.PI / 180) + MathHelper.cos((float)((float)this.ticksExisted * 0.6662f)) * 0.25f;
            float f1 = MathHelper.cos((float)f);
            float f2 = MathHelper.sin((float)f);
            this.world.spawnParticle(EnumParticleTypes.SPELL_MOB, this.posX + (double)f1 * 0.6, this.posY + 2.0, this.posZ + (double)f2 * 0.6, d0, d1, d2, new int[]{0, 1, 1});
            this.world.spawnParticle(EnumParticleTypes.SPELL_MOB, this.posX - (double)f1 * 0.6, this.posY + 2.0, this.posZ - (double)f2 * 0.6, d0, d1, d2, new int[]{0, 1, 1});
            --this.handParticleTick;
            if (this.handParticleTick <= 4 && (spellTarget = this.getSpellTargetEntity()) != null) {
                for (int i = 0; i < 20; ++i) {
                    double dx = this.getRNG().nextGaussian() * 0.5;
                    double dz = this.getRNG().nextGaussian() * 0.5;
                    this.world.spawnParticle(EnumParticleTypes.VILLAGER_HAPPY, spellTarget.posX + dx, spellTarget.posY + this.getRNG().nextDouble() * 2.0, spellTarget.posZ + dz, 0.0, 0.8, 0.0, new int[]{0, 1, 1});
                }
            }
        }
    }

    static {
        animHandler.addAnim("tektopia", "villager_summon", "cleric_m", false);
        animHandler.addAnim("tektopia", "villager_cast_bless", "cleric_m", false);
        EntityVillagerTek.setupAnimations(animHandler, "cleric_m");
    }
}

