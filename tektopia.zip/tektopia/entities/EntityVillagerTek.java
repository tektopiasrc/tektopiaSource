/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Predicate
 *  com.leviathanstudio.craftstudio.common.animation.AnimationHandler
 *  javax.annotation.Nullable
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.particle.Particle
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLiving
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.IEntityLivingData
 *  net.minecraft.entity.SharedMonsterAttributes
 *  net.minecraft.entity.ai.EntityAIBase
 *  net.minecraft.entity.ai.EntityAISwimming
 *  net.minecraft.entity.ai.EntityAITasks$EntityAITaskEntry
 *  net.minecraft.entity.ai.attributes.IAttribute
 *  net.minecraft.entity.ai.attributes.IAttributeInstance
 *  net.minecraft.entity.ai.attributes.RangedAttribute
 *  net.minecraft.entity.item.EntityItem
 *  net.minecraft.entity.monster.EntityEvoker
 *  net.minecraft.entity.monster.EntityPigZombie
 *  net.minecraft.entity.monster.EntityVex
 *  net.minecraft.entity.monster.EntityVindicator
 *  net.minecraft.entity.monster.EntityWitherSkeleton
 *  net.minecraft.entity.monster.EntityZombie
 *  net.minecraft.entity.passive.EntityAnimal
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.entity.player.EntityPlayerMP
 *  net.minecraft.init.Items
 *  net.minecraft.init.SoundEvents
 *  net.minecraft.inventory.EntityEquipmentSlot
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemArmor
 *  net.minecraft.item.ItemStack
 *  net.minecraft.nbt.NBTBase
 *  net.minecraft.nbt.NBTTagCompound
 *  net.minecraft.nbt.NBTTagList
 *  net.minecraft.network.datasync.DataParameter
 *  net.minecraft.network.datasync.DataSerializer
 *  net.minecraft.network.datasync.DataSerializers
 *  net.minecraft.network.datasync.EntityDataManager
 *  net.minecraft.potion.PotionEffect
 *  net.minecraft.util.DamageSource
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.EnumParticleTypes
 *  net.minecraft.util.SoundCategory
 *  net.minecraft.util.SoundEvent
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.Vec3i
 *  net.minecraft.util.text.translation.I18n
 *  net.minecraft.world.DifficultyInstance
 *  net.minecraft.world.World
 *  net.minecraftforge.common.util.ITeleporter
 *  net.minecraftforge.fml.common.FMLCommonHandler
 *  net.minecraftforge.fml.common.network.NetworkRegistry$TargetPoint
 *  net.minecraftforge.fml.common.network.simpleimpl.IMessage
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 */
package net.tangotek.tektopia.entities;

import com.leviathanstudio.craftstudio.common.animation.AnimationHandler;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.UUID;
import java.util.function.Function;
import java.util.function.Predicate;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.particle.Particle;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAITasks;
import net.minecraft.entity.ai.attributes.IAttribute;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.ai.attributes.RangedAttribute;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.monster.EntityEvoker;
import net.minecraft.entity.monster.EntityPigZombie;
import net.minecraft.entity.monster.EntityVex;
import net.minecraft.entity.monster.EntityVindicator;
import net.minecraft.entity.monster.EntityWitherSkeleton;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializer;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.text.translation.I18n;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.World;
import net.minecraftforge.common.util.ITeleporter;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.tangotek.tektopia.EntityTagType;
import net.tangotek.tektopia.ItemTagType;
import net.tangotek.tektopia.ModEntities;
import net.tangotek.tektopia.ModItems;
import net.tangotek.tektopia.ModPotions;
import net.tangotek.tektopia.ModSoundEvents;
import net.tangotek.tektopia.ProfessionType;
import net.tangotek.tektopia.TekVillager;
import net.tangotek.tektopia.Village;
import net.tangotek.tektopia.VillageManager;
import net.tangotek.tektopia.VillagerRole;
import net.tangotek.tektopia.caps.IVillageData;
import net.tangotek.tektopia.client.ParticleThought;
import net.tangotek.tektopia.entities.EntityChild;
import net.tangotek.tektopia.entities.EntityNecromancer;
import net.tangotek.tektopia.entities.EntityVillageNavigator;
import net.tangotek.tektopia.entities.ai.EntityAIDeliverToStorage2;
import net.tangotek.tektopia.entities.ai.EntityAIEatFood;
import net.tangotek.tektopia.entities.ai.EntityAIFleeEntity;
import net.tangotek.tektopia.entities.ai.EntityAIGenericMove;
import net.tangotek.tektopia.entities.ai.EntityAIIdleCheck;
import net.tangotek.tektopia.entities.ai.EntityAIOpenGate;
import net.tangotek.tektopia.entities.ai.EntityAIReadBook;
import net.tangotek.tektopia.entities.ai.EntityAIRetrieveFromStorage2;
import net.tangotek.tektopia.entities.ai.EntityAISleep;
import net.tangotek.tektopia.entities.ai.EntityAITavernVisit;
import net.tangotek.tektopia.entities.ai.EntityAIUseDoor;
import net.tangotek.tektopia.entities.ai.EntityAIWanderStructure;
import net.tangotek.tektopia.items.ItemProfessionToken;
import net.tangotek.tektopia.network.PacketVillagerThought;
import net.tangotek.tektopia.storage.ItemDesireSet;
import net.tangotek.tektopia.storage.UpgradeItemDesire;
import net.tangotek.tektopia.storage.VillagerInventory;
import net.tangotek.tektopia.structures.VillageStructure;
import net.tangotek.tektopia.structures.VillageStructureHome;
import net.tangotek.tektopia.structures.VillageStructureSchool;
import net.tangotek.tektopia.structures.VillageStructureType;
import net.tangotek.tektopia.tickjob.TickJob;

public abstract class EntityVillagerTek
extends EntityVillageNavigator {
    public static final IAttribute MAX_HUNGER = new RangedAttribute((IAttribute)null, "generic.hunger", 100.0, 0.0, 100.0).setDescription("Hunger").setShouldWatch(true);
    public static final IAttribute MAX_HAPPY = new RangedAttribute((IAttribute)null, "generic.happy", 100.0, 0.0, 100.0).setDescription("Happy").setShouldWatch(true);
    public static final IAttribute MAX_INTELLIGENCE = new RangedAttribute((IAttribute)null, "generic.intelligence", 100.0, 0.0, 100.0).setDescription("Intelligence").setShouldWatch(true);
    private static final DataParameter<Integer> HUNGER = EntityDataManager.createKey(EntityVillagerTek.class, (DataSerializer)DataSerializers.VARINT);
    private static final DataParameter<Integer> HAPPY = EntityDataManager.createKey(EntityVillagerTek.class, (DataSerializer)DataSerializers.VARINT);
    private static final DataParameter<Integer> INTELLIGENCE = EntityDataManager.createKey(EntityVillagerTek.class, (DataSerializer)DataSerializers.VARINT);
    private static final DataParameter<Integer> FORCE_AXIS = EntityDataManager.createKey(EntityVillagerTek.class, (DataSerializer)DataSerializers.VARINT);
    private static final DataParameter<Boolean> SLEEPING = EntityDataManager.createKey(EntityVillagerTek.class, (DataSerializer)DataSerializers.BOOLEAN);
    private static final DataParameter<Boolean> SITTING = EntityDataManager.createKey(EntityVillagerTek.class, (DataSerializer)DataSerializers.BOOLEAN);
    private static final DataParameter<ItemStack> ACTION_ITEM = EntityDataManager.createKey(EntityVillagerTek.class, (DataSerializer)DataSerializers.ITEM_STACK);
    private static final DataParameter<Byte> MOVEMENT_MODE = EntityDataManager.createKey(EntityVillagerTek.class, (DataSerializer)DataSerializers.BYTE);
    private static final DataParameter<Integer> BLESSED = EntityDataManager.createKey(EntityVillagerTek.class, (DataSerializer)DataSerializers.VARINT);
    private static final DataParameter<Boolean> VISIT_TAVERN = EntityDataManager.createKey(EntityVillagerTek.class, (DataSerializer)DataSerializers.BOOLEAN);
    private static final DataParameter<Boolean> READ_BOOK = EntityDataManager.createKey(EntityVillagerTek.class, (DataSerializer)DataSerializers.BOOLEAN);
    public static int SLEEP_DURATION = 8000;
    public static int SLEEP_START_TIME = 16000;
    public static int SLEEP_END_TIME = SLEEP_START_TIME + SLEEP_DURATION;
    public static int WORK_START_TIME = 500;
    public static int WORK_END_TIME = 11500;
    private static final boolean ALL_MALES = false;
    private static final boolean ALL_FEMALES = false;
    protected static final int DEFAULT_JOB_PRIORITY = 50;
    private PacketVillagerThought nextThought = null;
    private static int[] recentEatPenalties = new int[]{2, 0, -3, -7, -12, -18};
    private static final Map<ProfessionType, DataParameter<Integer>> SKILLS = new EnumMap<ProfessionType, DataParameter<Integer>>(ProfessionType.class);
    protected ItemDesireSet desireSet;
    protected VillagerInventory villagerInventory;
    protected BlockPos bedPos = null;
    protected BlockPos homeFrame = null;
    protected EntityAnimal leadAnimal = null;
    private MovementMode lastMovementMode;
    private VillageStructure lastCrowdCheck = null;
    protected int sleepOffset = 0;
    protected int wantsLearning = 0;
    protected boolean wantsTavern = false;
    protected int lastSadTick = 0;
    protected int lastSadThrottle = 200;
    private int idle = 0;
    protected int daysAlive = 0;
    private int dayCheckTime = 0;
    private final ProfessionType professionType;
    private Map<String, DataParameter<Boolean>> aiFilters;
    private LinkedList<Integer> recentEats = new LinkedList();

    public EntityVillagerTek(World worldIn, ProfessionType profType, int roleMask) {
        super(worldIn, roleMask);
        this.professionType = profType;
        this.setCanPickUpLoot(true);
        this.villagerInventory = new VillagerInventory(this, "Items", false, 27);
        this.setSize(0.6f, 1.95f);
        this.setHunger(this.getMaxHunger());
        this.setHappy(this.getMaxHappy());
        this.setIntelligence(0);
        ModEntities.makeTaggedEntity((Entity)this, EntityTagType.VILLAGER);
        Runnable foodChomp = () -> this.world.playSound(this.posX, this.posY, this.posZ, SoundEvents.ENTITY_GENERIC_EAT, SoundCategory.NEUTRAL, 1.0f, this.rand.nextFloat() * 0.2f + 0.9f, false);
        Runnable doneEating = () -> {
            this.unequipActionItem();
            if (this.getRNG().nextInt(12) == 0) {
                this.world.playSound(this.posX, this.posY, this.posZ, SoundEvents.ENTITY_PLAYER_BURP, SoundCategory.NEUTRAL, 1.0f, this.rand.nextFloat() * 0.2f + 0.9f, false);
            }
        };
        if (this.world.isRemote) {
            this.addAnimationTrigger("tektopia:villager_eat", 25, foodChomp);
            this.addAnimationTrigger("tektopia:villager_eat", 50, foodChomp);
            this.addAnimationTrigger("tektopia:villager_eat", 75, foodChomp);
            this.addAnimationTrigger("tektopia:villager_eat", 90, doneEating);
        }
        if (!worldIn.isRemote) {
            this.randomizeGoals();
            if (this.professionType != null && this.getBaseSkill(this.professionType) < 1) {
                this.setSkill(this.professionType, 1);
            }
        }
    }

    protected static void setupAnimations(AnimationHandler animHandler, String modelName) {
        EntityVillageNavigator.setupAnimations(animHandler, modelName);
        animHandler.addAnim("tektopia", "villager_eat", modelName, false);
        animHandler.addAnim("tektopia", "villager_sleep", modelName, true);
        animHandler.addAnim("tektopia", "villager_sit", modelName, true);
        animHandler.addAnim("tektopia", "villager_sit_cheer", modelName, false);
        animHandler.addAnim("tektopia", "villager_walk", modelName, true);
        animHandler.addAnim("tektopia", "villager_walk_sad", modelName, true);
        animHandler.addAnim("tektopia", "villager_run", modelName, true);
        animHandler.addAnim("tektopia", "villager_read", modelName, false);
    }

    protected void initEntityAIBase() {
        Function<ItemStack, Integer> bestFood = p -> EntityAIEatFood.getFoodScore(p.getItem(), this);
        this.getDesireSet().addItemDesire(new UpgradeItemDesire("Food", bestFood, 1, 3, 4, p -> p.isHungry() || p.isStoragePriority()));
        this.addTask(50, new EntityAIEatFood(this));
        this.addTask(50, new EntityAIRetrieveFromStorage2(this));
        this.addTask(50, new EntityAISleep(this));
        this.addTask(50, new EntityAIDeliverToStorage2(this));
        this.addTask(50, new EntityAITavernVisit(this, p -> p.wantsTavern() && !p.isWorkTime() && !p.shouldSleep()));
        this.addTask(50, new EntityAIWanderStructure(this, EntityVillagerTek.getVillagerHome(), p -> !p.isWorkTime() && !this.wantsTavern(), 12));
        this.addTask(50, new EntityAIReadBook(this));
        this.addTask(60, new EntityAIGenericMove(this, p -> p.isWorkTime() && p.hasVillage() && p.getIdle() > 100, v -> this.village.getLastVillagerPos(), MovementMode.WALK, null, null));
        this.addTask(150, new EntityAIIdleCheck(this));
    }

    protected void initEntityAI() {
        this.desireSet = new ItemDesireSet();
        this.addTask(0, (EntityAIBase)new EntityAISwimming((EntityLiving)this));
        this.addTask(1, new EntityAIFleeEntity(this, (com.google.common.base.Predicate<Entity>)((com.google.common.base.Predicate)p -> this.isFleeFrom((Entity)p)), 16.0f));
        this.addTask(15, new EntityAIUseDoor((EntityLiving)this, true));
        this.addTask(15, new EntityAIOpenGate(this));
        this.initEntityAIBase();
    }

    @Nullable
    public IEntityLivingData onInitialSpawn(DifficultyInstance difficulty, @Nullable IEntityLivingData livingdata) {
        this.setCustomNameTag(this.generateName());
        double intel = this.getRNG().nextGaussian() * 10.0;
        if (intel < 0.0) {
            intel *= 0.3;
        }
        intel = Math.max(intel + 10.0, 2.0);
        this.setIntelligence((int)intel);
        return super.onInitialSpawn(difficulty, livingdata);
    }

    public String generateName() {
        String nameTytpe = this.isMale() ? "malename" : "femalename";
        String firstSTotal = I18n.translateToLocal((String)("villager." + nameTytpe + ".total"));
        int firstTotal = Integer.parseInt(firstSTotal);
        String lastSTotal = I18n.translateToLocal((String)"villager.lastname.total");
        int lastTotal = Integer.parseInt(lastSTotal);
        String firstName = I18n.translateToLocal((String)("villager." + nameTytpe + "." + this.getRNG().nextInt(firstTotal)));
        String lastName = I18n.translateToLocal((String)("villager.lastname." + this.getRNG().nextInt(lastTotal)));
        return firstName + " " + lastName;
    }

    public String getLastName() {
        String name = this.getCustomNameTag();
        String[] splitNames = name.split("\\s+");
        if (splitNames.length >= 2) {
            return splitNames[1];
        }
        return "";
    }

    public String getFirstName() {
        String name = this.getCustomNameTag();
        String[] splitNames = name.split("\\s+");
        if (splitNames.length >= 2) {
            return splitNames[0];
        }
        return "";
    }

    public String getDebugName() {
        return ((Object)((Object)this)).getClass().getSimpleName() + this.getEntityId();
    }

    public ProfessionType getProfessionType() {
        return this.professionType;
    }

    protected boolean hasTavern() {
        return this.hasVillage() && this.getVillage().hasStructure(VillageStructureType.TAVERN);
    }

    protected boolean wantsTavern() {
        if (this.getHappy() >= 100 || !this.hasTavern()) {
            return false;
        }
        if (!this.isWorkTime() && (this.getHappy() < 70 || this.wantsTavern)) {
            return true;
        }
        return this.getHappy() < 10;
    }

    protected void addTask(int priority, EntityAIBase task) {
        this.tasks.addTask(priority, task);
    }

    public boolean isDeliveryTime() {
        return this.isWorkTime();
    }

    @Override
    protected void setupServerJobs() {
        super.setupServerJobs();
        this.addJob(new TickJob(60, 120, true, new CleanUpRunnable(this)));
        this.addJob(new TickJob(23900, 200, true, new GoalRandomizerRunnable(this)));
        this.addJob(new TickJob(80, 10, true, () -> {
            if (this.isStarving()) {
                this.attackEntityFrom(DamageSource.STARVE, 1.0f);
            }
        }));
        this.addJob(new TickJob(30, 30, true, () -> this.scanForEnemies()));
        this.addJob(new TickJob(100, 200, true, () -> this.fixOffGraph()));
        this.addJob(new TickJob(200, 300, true, () -> this.dayCheck()));
        this.addJob(new TickJob(200, 100, true, () -> this.crowdingCheck()));
        this.addJob(new TickJob(40, 100, true, new BedCheckRunnable(this)));
        this.addJob(new TickJob(20, 30, false, () -> {
            VillageManager vm = VillageManager.get(this.world);
            vm.addScanBox(new AxisAlignedBB(this.getPosition()).grow(64.0));
        }));
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getAttributeMap().registerAttribute(MAX_HUNGER);
        this.getAttributeMap().registerAttribute(MAX_HAPPY);
        this.getAttributeMap().registerAttribute(MAX_INTELLIGENCE);
        this.getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(64.0);
        this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.4);
        this.getEntityAttribute(MAX_HUNGER).setBaseValue(100.0);
        this.getEntityAttribute(MAX_HAPPY).setBaseValue(100.0);
        this.getEntityAttribute(MAX_INTELLIGENCE).setBaseValue(100.0);
        this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(20.0);
        this.dataManager.set(HUNGER, this.getMaxHunger());
        this.dataManager.set(HAPPY, this.getMaxHappy());
        this.dataManager.set(INTELLIGENCE, this.getMaxIntelligence());
        this.dataManager.set(FORCE_AXIS, -1);
        this.dataManager.set(SLEEPING, false);
        this.dataManager.set(SITTING, false);
        this.dataManager.set(ACTION_ITEM, ItemStack.EMPTY);
        this.dataManager.set(MOVEMENT_MODE, MovementMode.WALK.id);
        this.dataManager.set(BLESSED, 0);
        for (DataParameter<Integer> dataParameter : SKILLS.values()) {
            this.dataManager.set(dataParameter, 0);
        }
        for (DataParameter dataParameter : this.aiFilters.values()) {
            this.dataManager.set(dataParameter, true);
        }
    }

    @Override
    protected void entityInit() {
        this.aiFilters = new HashMap<String, DataParameter<Boolean>>();
        this.registerAIFilter("read_book", READ_BOOK);
        this.registerAIFilter("visit_tavern", VISIT_TAVERN);
        this.dataManager.register(HUNGER, 0);
        this.dataManager.register(HAPPY, 0);
        this.dataManager.register(INTELLIGENCE, 1);
        this.dataManager.register(FORCE_AXIS, -1);
        this.dataManager.register(SLEEPING, false);
        this.dataManager.register(SITTING, false);
        this.dataManager.register(ACTION_ITEM, ItemStack.EMPTY);
        this.dataManager.register(MOVEMENT_MODE, (byte)0);
        this.dataManager.register(BLESSED, 0);
        for (DataParameter<Integer> skill : SKILLS.values()) {
            this.dataManager.register(skill, 0);
        }
        super.entityInit();
        this.onStopSit();
    }

    public boolean isAITick(String aiFilter) {
        return super.isAITick() && this.isAIFilterEnabled(aiFilter);
    }

    protected boolean villageHasStorageCount(Predicate<ItemStack> pred, int count) {
        if (this.hasVillage()) {
            return this.getVillage().getStorageCount(pred) >= count;
        }
        return false;
    }

    protected void crowdingCheck() {
        VillageStructure struct;
        if (!this.isSleeping() && (struct = this.getCurrentStructure()) != this.lastCrowdCheck) {
            float crowdFactor;
            this.lastCrowdCheck = struct;
            if (struct != null && (crowdFactor = struct.getCrowdedFactor()) > 0.0f) {
                int CROWD_PENALTY = -5;
                this.setThought(VillagerThought.CROWDED);
                int penalty = (int)(-5.0f * crowdFactor);
                this.modifyHappy(penalty);
                this.debugOut("Crowding penalty [" + penalty + "] in " + struct.type.name() + " at " + this.getPosition());
            }
        }
    }

    public int getDaysAlive() {
        return this.daysAlive;
    }

    protected void dayCheck() {
        int curTime = (int)Village.getTimeOfDay(this.world);
        if (curTime < this.dayCheckTime) {
            this.dayCheckTime = curTime;
            ++this.daysAlive;
            this.onNewDay();
        } else {
            this.dayCheckTime = curTime;
        }
    }

    protected void onNewDay() {
        this.randomizeGoals();
    }

    protected void fixOffGraph() {
        Village v;
        if (!this.hasVillage() && (v = VillageManager.get(this.world).getNearestVillage(this.getPosition(), 130)) != null) {
            BlockPos bestPos = null;
            double bestDist = Double.MAX_VALUE;
            for (BlockPos testPos : BlockPos.getAllInBox((BlockPos)this.getPosition().add(-3, -3, -3), (BlockPos)this.getPosition().add(3, 3, 3))) {
                if (!v.getPathingGraph().isInGraph(testPos)) continue;
                double dist = this.getPosition().distanceSq((Vec3i)testPos);
                if (bestPos != null && !(dist < bestDist)) continue;
                bestPos = testPos;
                bestDist = dist;
            }
            if (bestPos != null) {
                this.setPositionAndUpdate(bestPos.getX(), bestPos.getY(), bestPos.getZ());
            }
        }
    }

    protected void scanForEnemies() {
        if (!this.isRole(VillagerRole.VENDOR) && !this.isRole(VillagerRole.VISITOR)) {
            ListIterator itr = this.world.getEntitiesWithinAABB(EntityLiving.class, this.getEntityBoundingBox().grow(30.0, 6.0, 30.0), this.isEnemy()).listIterator();
            while (itr.hasNext()) {
                double enemyRange;
                double distMe;
                IAttributeInstance attribute;
                EntityLiving enemy = (EntityLiving)itr.next();
                if (this.canEntityBeSeen((Entity)enemy) && this.hasVillage()) {
                    this.getVillage().addOrRenewEnemy((EntityLivingBase)enemy, 1);
                }
                if ((attribute = enemy.getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE)) == null || !((distMe = enemy.getDistanceSq((Entity)this)) < (enemyRange = attribute.getAttributeValue() * attribute.getAttributeValue()))) continue;
                if (enemy.getAttackTarget() == null) {
                    enemy.setAttackTarget((EntityLivingBase)this);
                    continue;
                }
                double distTarget = enemy.getDistanceSq((Entity)enemy.getAttackTarget());
                if (distMe < distTarget) {
                    enemy.setAttackTarget((EntityLivingBase)this);
                    continue;
                }
                if (!this.hasVillage()) continue;
                boolean meIndoors = this.getVillage().isInStructure(this.getPosition());
                boolean currentTargetIndoors = this.getVillage().isInStructure(enemy.getAttackTarget().getPosition());
                if (meIndoors || !currentTargetIndoors) continue;
                enemy.setAttackTarget((EntityLivingBase)this);
            }
        }
    }

    public void damageArmor(float damage) {
        if (damage < 1.0f) {
            damage = 1.0f;
        }
        int finalDmg = (int)damage;
        this.getArmorInventoryList().forEach(a -> {
            if (a.getItem() instanceof ItemArmor && this.getRNG().nextBoolean()) {
                this.damageItem((ItemStack)a, finalDmg);
            }
        });
    }

    public void damageItem(ItemStack itemStack, int amount) {
        int itemDamage = ModItems.isTaggedItem(itemStack, ItemTagType.VILLAGER) ? amount : amount * 5;
        ItemStack oldItem = null;
        if (itemStack.getItemDamage() + itemDamage >= itemStack.getMaxDamage()) {
            oldItem = itemStack.copy();
        }
        itemStack.damageItem(itemDamage, (EntityLivingBase)this);
        if (itemStack.isEmpty() && oldItem != null) {
            this.onInventoryUpdated(oldItem);
        }
    }

    @Nullable
    public Entity changeDimension(int dimensionIn, ITeleporter teleporter) {
        return null;
    }

    public boolean canBePushed() {
        if (this.isSitting() || this.isSleeping()) {
            return false;
        }
        return super.canBePushed();
    }

    protected void collideWithEntity(Entity entityIn) {
        if (!this.isSitting()) {
            if (entityIn instanceof EntityVillagerTek && this.isDoorNearby(1, 1)) {
                return;
            }
            super.collideWithEntity(entityIn);
        }
    }

    protected void collideWithNearbyEntities() {
        if (!this.isSitting() && !this.isSleeping()) {
            super.collideWithNearbyEntities();
        }
    }

    protected boolean isDoorNearby(int xx, int zz) {
        for (int x = -xx; x <= xx; ++x) {
            for (int z = -zz; z <= zz; ++z) {
                BlockPos bp = this.getPosition().east(x).north(z);
                if (!VillageStructure.isWoodDoor(this.world, bp) && !VillageStructure.isGate(this.world, bp)) continue;
                return true;
            }
        }
        return false;
    }

    protected SoundEvent getAmbientSound() {
        if (this.isSleeping() && this.world.rand.nextInt(2) == 0) {
            return ModSoundEvents.villagerSleep;
        }
        return null;
    }

    protected void bedCheck() {
        if (this.hasVillage()) {
            VillageStructureHome home;
            VillageStructure struct;
            if (this.getBedPos() != null && this.homeFrame != null && (struct = this.village.getStructureFromFrame(this.homeFrame)) != null && struct instanceof VillageStructureHome && !(home = (VillageStructureHome)struct).canVillagerSleep(this)) {
                this.clearHome();
            }
            if (this.getBedPos() == null) {
                if (this.homeFrame != null) {
                    struct = this.village.getStructureFromFrame(this.homeFrame);
                    if (struct != null && struct instanceof VillageStructureHome) {
                        home = (VillageStructureHome)struct;
                        if (home.canVillagerSleep(this) && !home.isFull()) {
                            this.homeFrame = null;
                            home.addResident(this);
                        } else {
                            this.clearHome();
                        }
                    } else if (this.ticksExisted > 200) {
                        this.clearHome();
                    }
                } else {
                    VillageStructureHome home2 = this.village.getAvailableHome(this);
                    if (home2 != null) {
                        home2.addResident(this);
                    }
                }
            }
        }
    }

    public VillageStructure getCurrentStructure() {
        if (this.hasVillage()) {
            return this.getVillage().getStructure(this.getPosition());
        }
        return null;
    }

    public static Function<EntityVillagerTek, VillageStructure> findLocalTavern() {
        return p -> {
            VillageStructure tavern;
            if (p.hasVillage() && (tavern = p.getVillage().getNearestStructure(VillageStructureType.TAVERN, p.getPosition())) != null) {
                return tavern;
            }
            return null;
        };
    }

    public static Function<EntityVillagerTek, VillageStructure> getVillagerHome() {
        return p -> {
            if (p.hasHome()) {
                return p.getVillage().getStructureFromFrame(p.homeFrame);
            }
            return null;
        };
    }

    @Override
    public void attachToVillage(Village v) {
        super.attachToVillage(v);
        this.sleepOffset = this.genOffset(400);
        if (this.isRole(VillagerRole.VILLAGER)) {
            v.addResident(this);
        }
        if (this.getIntelligence() < 1) {
            this.setIntelligence(1);
        }
    }

    @Override
    protected void detachVillage() {
        if (this.hasVillage()) {
            this.village.removeResident(this);
        }
        super.detachVillage();
    }

    protected int genOffset(int range) {
        return this.getRNG().nextInt(range) - range / 2;
    }

    protected void randomizeGoals() {
        this.wantsLearning = this.getRNG().nextInt(100) < 28 && this.getIntelligence() < this.getMaxIntelligence() ? this.getRNG().nextInt(6) + 3 : 0;
        this.wantsTavern = this.getRNG().nextInt(10) < 3;
    }

    private static void cleanUpInventory(EntityVillagerTek v) {
        v.cleanUpInventory();
    }

    protected void cleanUpInventory() {
    }

    protected void onNewPotionEffect(PotionEffect effect) {
        if (effect.getPotion() == ModPotions.potionBless) {
            this.dataManager.set(BLESSED,effect.getAmplifier());
        }
        super.onNewPotionEffect(effect);
    }

    protected void onFinishedPotionEffect(PotionEffect effect) {
        if (effect.getPotion() == ModPotions.potionBless) {
            this.dataManager.set(BLESSED, 0);
        }
        super.onFinishedPotionEffect(effect);
    }

    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();
        if (this.getLeashed() && this.getRNG().nextInt(this.getHappy() < 50 ? 30 : 50) == 0) {
            this.modifyHappy(-1);
            if (this.getHappy() <= 0) {
                this.clearLeashed(true, true);
            }
        }
        if (!this.isWorldRemote()) {
            ++this.lastSadTick;
            if (this.nextThought != null && this.ticksExisted % 80 == 0) {
                TekVillager.NETWORK.sendToAllAround((IMessage)this.nextThought, new NetworkRegistry.TargetPoint(this.getDimension(), this.posX, this.posY, this.posZ, 64.0));
                this.nextThought = null;
            }
        }
    }

    @Override
    @SideOnly(value=Side.CLIENT)
    protected void startWalking() {
        MovementMode mode = this.getMovementMode();
        if (mode != this.lastMovementMode) {
            if (this.lastMovementMode != null) {
                this.stopWalking();
            }
            this.lastMovementMode = mode;
            if (mode != null) {
                this.playClientAnimation(mode.anim);
            }
        }
    }

    @Override
    @SideOnly(value=Side.CLIENT)
    protected void stopWalking() {
        if (this.lastMovementMode != null) {
            this.stopClientAnimation(this.lastMovementMode.anim);
            this.lastMovementMode = null;
        }
    }

    public BlockPos getBedPos() {
        return this.bedPos;
    }

    @Override
    @SideOnly(value=Side.CLIENT)
    public void setPositionAndRotationDirect(double x, double y, double z, float yaw, float pitch, int posRotationIncrements, boolean teleport) {
        super.setPositionAndRotationDirect(x, y, z, yaw, pitch, 1, teleport);
    }

    public void setHome(BlockPos bedPos, BlockPos homeFrame) {
        this.bedPos = bedPos;
        this.homeFrame = homeFrame;
    }

    public void clearHome() {
        this.bedPos = null;
        this.homeFrame = null;
    }

    public boolean hasHome() {
        return this.hasVillage() && this.homeFrame != null;
    }

    public VillageStructureHome getHome() {
        if (this.hasHome()) {
            VillageStructureHome home = (VillageStructureHome)this.village.getStructureFromFrame(this.homeFrame);
            return home;
        }
        return null;
    }

    public void addVillagerPosition() {
        if (this.hasVillage()) {
            this.getVillage().addVillagerPosition(this);
        }
    }

    public final int getMaxHunger() {
        return (int)this.getEntityAttribute(MAX_HUNGER).getAttributeValue();
    }

    public int getHunger() {
        return (Integer)this.dataManager.get(HUNGER);
    }

    public void setHunger(int hunger) {
        if (this.isRole(VillagerRole.VILLAGER)) {
            this.dataManager.set(HUNGER, MathHelper.clamp((int)hunger, (int)0, (int)this.getMaxHunger()));
            if (hunger < 0 && this.isHungry()) {
                this.setThought(VillagerThought.HUNGRY);
            }
        }
    }

    public final int getMaxHappy() {
        return (int)this.getEntityAttribute(MAX_HAPPY).getAttributeValue();
    }

    public int getHappy() {
        return (Integer)this.dataManager.get(HAPPY);
    }

    public int setHappy(int happy) {
        int prevHappy = this.getHappy();
        this.dataManager.set(HAPPY, MathHelper.clamp((int)happy, (int)0, (int)this.getMaxHappy()));
        return this.getHappy() - prevHappy;
    }

    public final int getMaxIntelligence() {
        return (int)this.getEntityAttribute(MAX_INTELLIGENCE).getAttributeValue();
    }

    public int getIntelligence() {
        int intel = Math.max((Integer)this.dataManager.get(INTELLIGENCE), 1);
        return intel;
    }

    public void setIntelligence(int intel) {
        this.dataManager.set(INTELLIGENCE, MathHelper.clamp((int)intel, (int)1, (int)this.getMaxIntelligence()));
    }

    public int getBlessed() {
        return (Integer)this.dataManager.get(BLESSED);
    }

    public int getSkill(ProfessionType pt) {
        int skill = this.getBaseSkill(pt);
        if (pt == this.getProfessionType()) {
            skill += this.getBlessed();
        }
        return Math.min(skill, 100);
    }

    public int getBaseSkill(ProfessionType pt) {
        int skill = (Integer)this.dataManager.get(SKILLS.get((Object)pt));
        return Math.min(skill, 100);
    }

    public int getSkillLerp(ProfessionType pt, int min, int max) {
        if (min < max) {
            return (int)MathHelper.clampedLerp((double)min, (double)max, (double)((double)this.getSkill(pt) / 100.0));
        }
        return (int)MathHelper.clampedLerp((double)max, (double)min, (double)((100.0 - (double)this.getSkill(pt)) / 100.0));
    }

    public void setSkill(ProfessionType pt, int val) {
        this.debugOut("Skill Change - " + pt.name + " --> " + val);
        this.dataManager.set(SKILLS.get(pt), MathHelper.clamp((int)val, (int)0, (int)100));
    }

    public int getForceAxis() {
        return (Integer)this.dataManager.get(FORCE_AXIS);
    }

    public void setForceAxis(int axes) {
        this.dataManager.set(FORCE_AXIS, axes);
    }

    public boolean isSleeping() {
        return (Boolean)this.dataManager.get(SLEEPING);
    }

    public boolean isSitting() {
        return (Boolean)this.dataManager.get(SITTING);
    }

    public MovementMode getMovementMode() {
        MovementMode mode = MovementMode.valueOf((Byte)this.dataManager.get(MOVEMENT_MODE));
        return mode;
    }

    public void setMovementMode(MovementMode mode) {
        this.dataManager.set(MOVEMENT_MODE, mode.id);
    }

    protected void setSleeping(boolean sleep) {
        this.dataManager.set(SLEEPING, sleep);
    }

    public void setSitting(boolean sit) {
        this.dataManager.set(SITTING, sit);
    }

    public boolean isHungry() {
        return this.getHunger() < 30;
    }

    public boolean isStarving() {
        return this.getHunger() <= 0;
    }

    public boolean shouldSleep() {
        return this.isSleepingTime() || !this.isRole(VillagerRole.DEFENDER) && this.getHealth() < this.getMaxHealth() * 0.5f;
    }

    public boolean isSleepingTime() {
        return Village.isTimeOfDay(this.world, SLEEP_START_TIME + this.sleepOffset + (this.wantsTavern() ? 4000 : 0), SLEEP_END_TIME + this.sleepOffset);
    }

    public boolean isWorkTime() {
        return Village.isTimeOfDay(this.world, WORK_START_TIME, WORK_END_TIME, this.sleepOffset) && !this.world.isRaining();
    }

    public boolean isLearningTime() {
        if (this.wantsLearning > 0 && Village.isTimeOfDay(this.world, this.sleepOffset + 2500, this.sleepOffset + 8000)) {
            return this.isAIFilterEnabled("read_book");
        }
        return false;
    }

    public void addIntelligence(int delta) {
        if (delta > 0 && this.getIntelligence() < 100 && this.getRNG().nextInt(100) * 2 > this.getIntelligence()) {
            this.setIntelligence(this.getIntelligence() + delta);
            this.setItemThought(Items.BOOK);
            --this.wantsLearning;
        }
    }

    public void addIntelligenceDelay(int delta, int ticks) {
        this.addJob(new TickJob(ticks, 0, false, () -> this.addIntelligence(delta)));
    }

    public void incrementSkill(ProfessionType pt) {
        List<EntityChild> children;
        this.setSkill(pt, this.getBaseSkill(pt) + 1);
        this.setItemThought(ModItems.getProfessionToken(pt));
        this.skillUpdated(pt);
        if (!this.isChild() && !(children = this.world.getEntitiesWithinAABB(EntityChild.class, this.getEntityBoundingBox().grow(12.0, 8.0, 12.0))).isEmpty()) {
            children.forEach(c -> {
                VillageStructure struct;
                boolean proximityLearn = true;
                if (c.hasVillage() && (struct = c.getVillage().getStructure(c.getPosition())) != null && struct instanceof VillageStructureSchool) {
                    proximityLearn = false;
                }
                if (proximityLearn && c.getSkill(pt) < this.getSkill(pt) / 2) {
                    int chance = Math.max(c.getBaseSkill(pt) / 2, 1);
                    if (c.getRNG().nextInt(chance) == 0) {
                        c.incrementSkill(pt);
                    }
                }
            });
        }
    }

    public void setIdle(int idle) {
        this.idle = idle;
    }

    public int getIdle() {
        return this.idle;
    }

    protected void skillUpdated(ProfessionType pt) {
    }

    public void tryAddSkill(ProfessionType pt, int chance) {
        double skill;
        if (!this.world.isRemote && (skill = (double)this.getBaseSkill(pt)) < 100.0) {
            double intel = Math.max((double)this.getIntelligence(), 5.0);
            double gapMod = 1.0 / Math.pow(skill / intel, 2.0);
            double intMod = 0.2;
            double intCheck = Math.min(gapMod * 0.2, 1.0);
            int rate = FMLCommonHandler.instance().getMinecraftServerInstance().getWorld(0).getGameRules().getInt("villagerSkillRate");
            double roll = this.world.rand.nextDouble();
            double rollModded = roll * (double)rate / 100.0;
            if (rollModded <= intCheck && this.world.rand.nextInt(chance) == 0) {
                this.incrementSkill(pt);
            }
        }
    }

    public void modifyHungerDelay(int delta, int ticks) {
        this.addJob(new TickJob(ticks, 0, false, () -> this.modifyHunger(delta)));
    }

    public void modifyHunger(int delta) {
        if (delta < 0 && this.hasVillage() && !this.getVillage().hasStructure(VillageStructureType.STORAGE)) {
            return;
        }
        this.setHunger(this.getHunger() + delta);
    }

    public void modifyHappyDelay(int delta, int ticks) {
        this.addJob(new TickJob(ticks, 0, false, () -> this.modifyHappy(delta)));
    }

    public void modifyHappy(int delta) {
        if (delta > 0) {
            this.world.setEntityState((Entity)this, (byte)14);
            if (this.getRNG().nextInt(6) == 0 && !this.isSleeping()) {
                this.playSound(ModSoundEvents.villagerHappy);
            }
        } else if (delta < 0) {
            this.world.setEntityState((Entity)this, (byte)13);
            if (this.getRNG().nextInt(2) == 0 && !this.isSleeping()) {
                this.playSound(ModSoundEvents.villagerAngry);
            }
        }
        int realChange = this.setHappy(this.getHappy() + delta);
        if (this.hasVillage() && realChange != 0) {
            this.getVillage().trackHappy(realChange);
        }
    }

    public void throttledSadness(int delta) {
        if (this.lastSadTick > this.lastSadThrottle && this.getRNG().nextBoolean()) {
            this.addJob(new TickJob(20, 60, false, () -> this.modifyHappy(delta)));
            this.lastSadTick = 0;
            this.lastSadThrottle = 50 + this.getRNG().nextInt(100);
        }
    }

    public void cheerBeer(int happy) {
        int offset = this.getRNG().nextInt(25);
        if (!this.isPlayingAnimation("villager_sit_cheer")) {
            if (this.isSitting()) {
                this.addJob(new TickJob(offset, 0, false, () -> this.playServerAnimation("villager_sit_cheer")));
                this.addJob(new TickJob(8 + offset, 0, false, () -> this.equipActionItem(new ItemStack((Item)ModItems.beer))));
                this.addJob(new TickJob(52 + offset, 0, false, () -> this.unequipActionItem()));
                this.addJob(new TickJob(58 + offset, 0, false, () -> {
                    if (this.isSitting()) {
                        this.playServerAnimation("villager_sit");
                    }
                }));
            }
            this.addJob(new TickJob(10 + offset * 2, 0, false, () -> this.playSound(ModSoundEvents.villagerHappy, 1.2f, this.getRNG().nextFloat() * 0.4f + 0.8f)));
            this.addJob(new TickJob(40, 0, false, () -> this.modifyHappy(happy)));
        }
    }

    public void addTrackingPlayer(EntityPlayerMP player) {
        super.addTrackingPlayer(player);
        if (!this.curAnim.isEmpty()) {
            this.playServerAnimation(this.curAnim);
        }
    }

    @Override
    public float getAIMoveSpeed() {
        float baseSpeed;
        float modifiedSpeed = baseSpeed = 0.45f * this.getMovementMode().speedMult;
        int blessed = this.getBlessed();
        if (blessed > 0) {
            modifiedSpeed = (float)((double)modifiedSpeed * (1.05 + (double)blessed * 0.002));
        }
        return modifiedSpeed;
    }

    public void setLeadAnimal(EntityAnimal animal) {
        this.leadAnimal = animal;
    }

    public EntityAnimal getLeadAnimal() {
        return this.leadAnimal;
    }

    protected boolean canDespawn() {
        return false;
    }

    public VillagerInventory getInventory() {
        return this.villagerInventory;
    }

    public ItemDesireSet getDesireSet() {
        return this.desireSet;
    }

    public void onStorageChange(ItemStack storageItem) {
        this.desireSet.onStorageUpdated(this, storageItem);
    }

    public void onInventoryUpdated(ItemStack updatedItem) {
        this.desireSet.onInventoryUpdated(this, updatedItem);
    }

    protected boolean canVillagerPickupItem(ItemStack itemIn) {
        return false;
    }

    public boolean hasNoGravity() {
        return this.isSitting() || super.hasNoGravity();
    }

    public double getSitOffset() {
        return 0.0;
    }

    public void onStartSit(int sitAxis) {
        this.setForceAxis(sitAxis);
        this.setSitting(true);
        this.equipActionItem(ModItems.EMPTY_HAND_ITEM);
        if (!this.curAnim.isEmpty() && this.curAnim != "villager_sit") {
            this.stopServerAnimation(this.curAnim);
        }
        this.playServerAnimation("villager_sit");
    }

    public void onStopSit() {
        this.setSitting(false);
        this.setForceAxis(-1);
        this.stopServerAnimation("villager_sit");
        this.setNoGravity(false);
        this.unequipActionItem(ModItems.EMPTY_HAND_ITEM);
    }

    public void onStartSleep(int sleepAxis) {
        this.setForceAxis(sleepAxis);
        this.setSleeping(true);
        if (!this.curAnim.isEmpty() && this.curAnim != "villager_sleep") {
            this.stopServerAnimation(this.curAnim);
        }
        this.playServerAnimation("villager_sleep");
    }

    public void onStopSleep() {
        if (this.isSleeping() && !this.isSleepingTime()) {
            this.checkSpawnHeart();
            this.modifyHappy(this.rand.nextInt(20) + 10);
        }
        this.setForceAxis(-1);
        this.setSleeping(false);
        this.stopServerAnimation("villager_sleep");
    }

    private void checkSpawnHeart() {
        int MIN_HAPPY = (int)((float)this.getMaxHappy() * 0.7f);
        if (this.hasVillage() && this.getHappy() >= MIN_HAPPY) {
            VillageStructure struct;
            IVillageData vd;
            float happyFactor = (float)(this.getMaxHappy() - this.getHappy()) / (float)(this.getMaxHappy() - MIN_HAPPY);
            int CONSTANT_DIFFICULTY = 15;
            int chance = 15 + this.village.getResidentCount() + (int)((float)this.village.getResidentCount() * happyFactor * 2.0f);
            if (this.getRNG().nextInt(chance) == 0 && this.hasVillage() && !this.isChild() && this.getProfessionType() != ProfessionType.NITWIT && (vd = this.getVillage().getTownData()) != null && this.bedPos != null && vd.isChildReady(this.world.getTotalWorldTime()) && (struct = EntityVillagerTek.getVillagerHome().apply(this)) != null && struct.type.isHome()) {
                VillageStructureHome home = (VillageStructureHome)struct;
                vd.childSpawned(this.world);
                this.addJob(new TickJob(100, 0, false, () -> {
                    ItemStack itemHeart = ModItems.createTaggedItem(ModItems.heart, ItemTagType.VILLAGER);
                    itemHeart.getSubCompound("village").setUniqueId("parent", this.getUniqueID());
                    EntityItem heartEntity = new EntityItem(this.world, (double)this.bedPos.getX(), (double)(this.bedPos.getY() + 1), (double)this.bedPos.getZ(), itemHeart);
                    this.world.spawnEntity((Entity)heartEntity);
                }));
            }
        }
    }

    public MovementMode getDefaultMovement() {
        if (this.getHappy() < this.getMaxHappy() / 5) {
            return MovementMode.SULK;
        }
        return MovementMode.WALK;
    }

    @Override
    public void updateMovement(boolean arrived) {
        if (this.world.rand.nextInt(50) == 0) {
            this.modifyHunger(-1);
        }
        if (!arrived && this.hasVillage() && this.getRNG().nextInt(20) == 0) {
            this.addVillagerPosition();
        }
    }

    @Override
    public void resetMovement() {
        super.resetMovement();
    }

    protected ItemStack modifyPickUpStack(ItemStack itemStack) {
        return itemStack;
    }

    public void updateEquipmentIfNeeded(EntityItem itemEntity) {
        ItemStack modStack;
        ItemStack itemStack = itemEntity.getItem();
        if (this.canVillagerPickupItem(itemStack) && ModItems.canVillagerSee(itemStack) && !(modStack = this.modifyPickUpStack(itemStack.copy())).isEmpty()) {
            ItemStack leftOverStack = this.villagerInventory.addItem(modStack);
            if (leftOverStack.isEmpty()) {
                itemEntity.setDead();
            } else {
                int actuallyTaken = modStack.getCount() - leftOverStack.getCount();
                int newCount = itemStack.getCount() - actuallyTaken;
                if (newCount <= 0) {
                    itemEntity.setDead();
                } else {
                    itemStack.setCount(newCount);
                }
            }
        }
    }

    public boolean isEntityInvulnerable(DamageSource source) {
        if (source == DamageSource.IN_WALL) {
            return true;
        }
        return super.isEntityInvulnerable(source);
    }

    public boolean attackEntityFrom(DamageSource source, float amount) {
        float beforeHealth = this.getHealth();
        if (super.attackEntityFrom(source, amount)) {
            float afterHealth = this.getHealth();
            float actualDamage = beforeHealth - afterHealth;
            if (actualDamage > 0.0f) {
                if (!this.isRole(VillagerRole.DEFENDER)) {
                    this.modifyHappy(-8);
                }
                if (this.hasVillage() && actualDamage > 0.0f) {
                    this.getVillage().reportVillagerDamage(this, source, actualDamage);
                }
                if (this.isSleeping()) {
                    this.onStopSleep();
                }
            }
            return true;
        }
        return false;
    }

    public void onDeath(DamageSource cause) {
        if (this.hasVillage() && this.getBedPos() != null) {
            int happyMod = -25;
            if (this.isChild()) {
                happyMod *= 2;
            }
            List<EntityVillagerTek> villagers = this.world.getEntitiesWithinAABB(EntityVillagerTek.class, this.getEntityBoundingBox().grow(200.0), p -> p != this);
            for (EntityVillagerTek v : villagers) {
                if (v.getVillage() != this.getVillage() || v.getBedPos() == null || v.isSleeping()) continue;
                v.modifyHappy(happyMod - this.getRNG().nextInt(15));
            }
        }
        if (this.hasVillage() && this.isRole(VillagerRole.VILLAGER)) {
            this.getVillage().reportVillagerDeath(this, cause);
        }
        super.onDeath(cause);
        if (!this.world.isRemote) {
            this.dropAllItems();
        }
    }

    private void dropAllItems() {
        VillagerInventory inv = this.getInventory();
        for (int i = 0; i < inv.getSizeInventory(); ++i) {
            ItemStack itemStack = inv.getStackInSlot(i);
            if (itemStack.isEmpty()) continue;
            this.entityDropItem(itemStack, 0.5f);
        }
        inv.clear();
    }

    public void pickupItems(int grow) {
        for (EntityItem entityitem : this.world.getEntitiesWithinAABB(EntityItem.class, this.getEntityBoundingBox().grow((double)grow, 3.0, (double)grow))) {
            if (entityitem.isDead || entityitem.getItem().isEmpty() || entityitem.cannotPickup()) continue;
            this.updateEquipmentIfNeeded(entityitem);
        }
    }

    public void setThought(VillagerThought thought) {
        this.nextThought = new PacketVillagerThought(this, thought, thought.getScale());
    }

    public void setItemThought(Item item) {
        ModEntities.sendItemThought((Entity)this, item);
    }

    @SideOnly(value=Side.CLIENT)
    public void handleStatusUpdate(byte id) {
        if (id == 12) {
            this.spawnParticles(EnumParticleTypes.HEART);
        } else if (id == 13) {
            this.spawnParticles(EnumParticleTypes.VILLAGER_ANGRY);
        } else if (id == 14) {
            this.spawnParticles(EnumParticleTypes.VILLAGER_HAPPY);
        } else {
            super.handleStatusUpdate(id);
        }
    }

    @SideOnly(value=Side.CLIENT)
    private void spawnParticles(EnumParticleTypes particleType) {
        for (int i = 0; i < 5; ++i) {
            double d0 = this.rand.nextGaussian() * 0.02;
            double d1 = this.rand.nextGaussian() * 0.02;
            double d2 = this.rand.nextGaussian() * 0.02;
            this.world.spawnParticle(particleType, this.posX + (double)(this.rand.nextFloat() * this.width * 2.0f) - (double)this.width, this.posY + 1.0 + (double)(this.rand.nextFloat() * this.height), this.posZ + (double)(this.rand.nextFloat() * this.width * 2.0f) - (double)this.width, d0, d1, d2, new int[0]);
        }
    }

    @SideOnly(value=Side.CLIENT)
    public void handleThought(PacketVillagerThought msg) {
        ParticleThought part = new ParticleThought(this.world, Minecraft.getMinecraft().getTextureManager(), (Entity)this, msg.getScale(), msg.getThought().getTex());
        Minecraft.getMinecraft().effectRenderer.addEffect((Particle)part);
    }

    public boolean processInteract(EntityPlayer player, EnumHand hand) {
        ItemProfessionToken token;
        ItemStack itemStack = player.getHeldItem(hand);
        if (itemStack.getItem() == Items.NAME_TAG) {
            itemStack.interactWithEntity(player, (EntityLivingBase)this, hand);
            return true;
        }
        if (itemStack.getItem() instanceof ItemProfessionToken && this.hasVillage() && this.canConvertProfession((token = (ItemProfessionToken)itemStack.getItem()).getProfessionType()) && (ModItems.isItemVillageBound(itemStack, this.getVillage()) || !ModItems.isItemVillageBound(itemStack)) && !this.world.isRemote) {
            itemStack.shrink(1);
            EntityVillagerTek villager = token.createVillager(this.world, this);
            if (villager != null) {
                villager.setLocationAndAngles(this.posX, this.posY, this.posZ, this.rotationYaw, this.rotationPitch);
                villager.onInitialSpawn(this.world.getDifficultyForLocation(this.getPosition()), null);
                villager.cloneFrom(this);
                this.world.spawnEntity((Entity)villager);
                player.playSound(SoundEvents.ENTITY_ILLAGER_CAST_SPELL, 1.0f, 1.0f);
                return true;
            }
            return false;
        }
        if (!this.world.isRemote) {
            player.openGui((Object)TekVillager.instance, 0, this.world, this.getEntityId(), 0, 0);
            this.getNavigator().clearPath();
        }
        if (player.isSneaking()) {
            this.debugSpam();
        }
        return true;
    }

    protected void debugSpam() {
        this.debugOut("+ + + + + + + + + + + + + +");
        this.debugOut("Debug for " + this.getDebugName());
        this.getInventory().debugSpam();
        for (EntityAITasks.EntityAITaskEntry task : this.tasks.taskEntries) {
            if (!task.using) continue;
            this.debugOut("    Active Task: " + task.action.getClass().getSimpleName());
        }
        this.debugOut("Hunger: " + this.getHunger());
        this.debugOut("Happy: " + this.getHappy());
        this.debugOut("Health: " + this.getHealth());
        this.debugOut("Intelligence: " + this.getIntelligence());
        for (ProfessionType pt : ProfessionType.values()) {
            if (this.getBaseSkill(pt) <= 0) continue;
            this.debugOut("     " + pt.name + ": " + this.getBaseSkill(pt));
        }
        this.debugOut("^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^");
    }

    protected void registerAIFilter(String filterName, DataParameter<Boolean> param) {
        if (this.aiFilters.put(filterName, param) != null) {
            this.debugOut("ERROR: registerAIFilter( " + filterName + " ).  Double registration");
        }
        this.dataManager.register(param, true);
    }

    protected void removeAIFilter(String filterName) {
        this.aiFilters.remove(filterName);
    }

    public List<String> getAIFilters() {
        return new ArrayList<String>(this.aiFilters.keySet());
    }

    public boolean isAIFilterEnabled(String filterName) {
        DataParameter<Boolean> param = this.aiFilters.get(filterName);
        if (param != null) {
            boolean result = (Boolean)this.dataManager.get(param);
            return result;
        }
        this.debugOut("ERROR: (isAIFilterEnabled) AI Filter " + filterName + " does not exist!");
        this.debugOut("ERROR: (isAIFilterEnabled) AI Filter " + filterName + " does not exist!");
        this.debugOut("ERROR: (isAIFilterEnabled) AI Filter " + filterName + " does not exist!");
        this.debugOut("ERROR: (isAIFilterEnabled) AI Filter " + filterName + " does not exist!");
        this.debugOut("ERROR: (isAIFilterEnabled) AI Filter " + filterName + " does not exist!");
        return true;
    }

    public void setAIFilter(String filterName, boolean enabled) {
        DataParameter<Boolean> param = this.aiFilters.get(filterName);
        if (param != null) {
            this.debugOut("AI Filer " + filterName + " -> " + enabled);
            this.dataManager.set(param, enabled);
        } else {
            this.debugOut("ERROR: (setAIFilter) AI Filter " + filterName + " does not exist!");
        }
    }

    public boolean canConvertProfession(ProfessionType pt) {
        return pt != this.professionType && pt != ProfessionType.CAPTAIN;
    }

    public void setRevengeTarget(@Nullable EntityLivingBase target) {
        if (target instanceof EntityPlayer) {
            return;
        }
        super.setRevengeTarget(target);
        if (this.hasVillage() && target != null) {
            this.getVillage().addOrRenewEnemy(target, 5);
            if (this.isEntityAlive()) {
                this.world.setEntityState((Entity)this, (byte)14);
            }
        }
    }

    @Override
    public void notifyDataManagerChange(DataParameter<?> key) {
        super.notifyDataManagerChange(key);
        if (MOVEMENT_MODE.equals(key) && this.isWalking()) {
            this.startWalking();
        }
    }

    public void equipActionItem(ItemStack toolItem) {
        this.dataManager.set(ACTION_ITEM, toolItem.copy());
    }

    public ItemStack getActionItem() {
        return (ItemStack)this.dataManager.get(ACTION_ITEM);
    }

    public void unequipActionItem() {
        this.dataManager.set(ACTION_ITEM, ItemStack.EMPTY);
    }

    public void unequipActionItem(ItemStack actionItem) {
        if (actionItem != null && actionItem.getItem() == this.getActionItem().getItem()) {
            this.dataManager.set(ACTION_ITEM, ItemStack.EMPTY);
        }
    }

    public com.google.common.base.Predicate<Entity> isEnemy() {
        return e -> this.isHostile().test(e) || e instanceof EntityLivingBase && EntityNecromancer.isMinion((EntityLivingBase)e);
    }

    public com.google.common.base.Predicate<Entity> isHostile() {
        return e -> e instanceof EntityZombie && !(e instanceof EntityPigZombie) || e instanceof EntityWitherSkeleton || e instanceof EntityEvoker || e instanceof EntityVex || e instanceof EntityVindicator || e instanceof EntityNecromancer;
    }

    public boolean isFleeFrom(Entity e) {
        return this.isHostile().test(e);
    }

    public void addRecentEat(Item item) {
        this.recentEats.add(Item.getIdFromItem((Item)item));
        while (this.recentEats.size() > 5) {
            this.recentEats.remove();
        }
    }

    public int getRecentEatModifier(Item item) {
        int itemId = Item.getIdFromItem((Item)item);
        int eatCount = MathHelper.clamp((int)((int)this.recentEats.stream().filter(i -> i == itemId).count()), (int)0, (int)5);
        return recentEatPenalties[eatCount];
    }

    public static Function<ItemStack, Integer> foodBetterThan(EntityVillagerTek v, int foodValue) {
        return p -> {
            int val = EntityVillagerTek.foodValue(v).apply((ItemStack)p);
            return val > foodValue ? val : -1;
        };
    }

    public static Function<ItemStack, Integer> foodValue(EntityVillagerTek v) {
        return p -> (int)((ModItems.isTaggedItem(p, ItemTagType.VILLAGER) ? 1.0f : 0.5f) * (float)EntityVillagerTek.foodItemValue(v).apply(p.getItem()).intValue());
    }

    public static Function<Item, Integer> foodItemValue(EntityVillagerTek v) {
        return i -> EntityAIEatFood.getFoodScore(i, v);
    }

    public boolean isVillageMember(Village v) {
        return this.getVillage() == v && this.getBedPos() != null;
    }

    public boolean isMale() {
        return this.getUniqueID().getLeastSignificantBits() % 2L == 0L;
    }

    public Predicate<ItemStack> isHarvestItem() {
        return p -> false;
    }

    public void equipBestGear() {
    }

    public void equipBestGear(EntityEquipmentSlot slot, Function<ItemStack, Integer> bestFunc) {
        ItemStack oldGear;
        ItemStack bestItem = this.getItemStackFromSlot(slot);
        int bestScore = bestFunc.apply(bestItem);
        int swapSlot = -1;
        for (int i = 0; i < this.getInventory().getSizeInventory(); ++i) {
            ItemStack itemStack = this.getInventory().getStackInSlot(i);
            int thisScore = bestFunc.apply(itemStack);
            if (thisScore <= bestScore) continue;
            bestScore = thisScore;
            bestItem = itemStack;
            swapSlot = i;
        }
        if (swapSlot >= 0) {
            ItemStack oldGear2 = this.getItemStackFromSlot(slot);
            this.setItemStackToSlot(slot, bestItem);
            this.getInventory().setInventorySlotContents(swapSlot, oldGear2);
            this.debugOut("Equipping new gear: " + bestItem + "   Removing old gear: " + oldGear2);
        } else if (bestScore == -1 && !(oldGear = this.getItemStackFromSlot(slot)).isEmpty()) {
            this.setItemStackToSlot(slot, ItemStack.EMPTY);
            this.getInventory().addItem(oldGear);
        }
    }

    protected void cloneFrom(EntityVillagerTek source) {
        this.setCustomNameTag(source.getCustomNameTag());
        while (source.isMale() != this.isMale()) {
            this.setUniqueId(UUID.randomUUID());
        }
        this.setHappy(source.getHappy());
        this.setIntelligence(source.getIntelligence());
        this.setHunger(source.getHunger());
        this.villagerInventory.mergeItems(source.villagerInventory);
        this.bedPos = source.bedPos;
        this.homeFrame = source.homeFrame;
        this.daysAlive = source.daysAlive;
        this.dayCheckTime = source.dayCheckTime;
        source.applySkillsTo(this);
        this.getInventory().cloneFrom(source.getInventory());
        source.setDead();
    }

    protected void applySkillsTo(EntityVillagerTek target) {
        for (ProfessionType pt : SKILLS.keySet()) {
            int skill = this.getBaseSkill(pt);
            if (skill <= target.getBaseSkill(pt) || !pt.canCopy) continue;
            target.setSkill(pt, skill);
        }
    }

    public void writeEntityToNBT(NBTTagCompound compound) {
        super.writeEntityToNBT(compound);
        compound.setInteger("happy", this.getHappy());
        compound.setInteger("hunger", this.getHunger());
        compound.setInteger("intelligence", this.getIntelligence());
        compound.setInteger("daysAlive", this.daysAlive);
        compound.setInteger("dayCheckTime", this.dayCheckTime);
        for (ProfessionType pt : SKILLS.keySet()) {
            if (!pt.canCopy) continue;
            compound.setInteger(pt.name, this.getBaseSkill(pt));
        }
        for (String filterName : this.aiFilters.keySet()) {
            compound.setBoolean("ai_" + filterName, this.isAIFilterEnabled(filterName));
        }
        compound.setBoolean("hasHome", this.homeFrame != null);
        if (this.homeFrame != null) {
            this.writeBlockPosNBT(compound, "homeFrame", this.homeFrame);
        }
        compound.setIntArray("recentEats", this.recentEats.stream().mapToInt(i -> i).toArray());
        this.villagerInventory.writeNBT(compound);
    }

    public void readEntityFromNBT(NBTTagCompound compound) {
        super.readEntityFromNBT(compound);
        this.setHappy(compound.getInteger("happy"));
        this.setHunger(compound.getInteger("hunger"));
        this.setIntelligence(compound.getInteger("intelligence"));
        this.daysAlive = compound.getInteger("daysAlive");
        this.dayCheckTime = compound.getInteger("dayCheckTime");
        for (ProfessionType pt : SKILLS.keySet()) {
            if (!pt.canCopy) continue;
            this.setSkill(pt, compound.getInteger(pt.name));
        }
        for (String filterName : this.aiFilters.keySet()) {
            String key = "ai_" + filterName;
            if (compound.hasKey(key)) {
                this.setAIFilter(filterName, compound.getBoolean("ai_" + filterName));
                continue;
            }
            this.setAIFilter(filterName, true);
        }
        boolean hasHome = compound.getBoolean("hasHome");
        if (hasHome) {
            this.homeFrame = this.readBlockPosNBT(compound, "homeFrame");
        }
        this.recentEats.clear();
        int[] eats = compound.getIntArray("recentEats");
        Arrays.stream(eats).forEach(i -> this.recentEats.add(i));
        this.setNoGravity(false);
        this.villagerInventory.readNBT(compound);
        this.getDesireSet().forceUpdate();
    }

    protected BlockPos readBlockPosNBT(NBTTagCompound compound, String key) {
        NBTTagList nbttaglist = compound.getTagList(key, 6);
        return new BlockPos(nbttaglist.getDoubleAt(0), nbttaglist.getDoubleAt(1), nbttaglist.getDoubleAt(2));
    }

    protected void writeBlockPosNBT(NBTTagCompound compound, String key, BlockPos val) {
        compound.setTag(key, (NBTBase)this.newDoubleNBTList(new double[]{val.getX(), val.getY(), val.getZ()}));
    }

    static {
        for (ProfessionType pt : ProfessionType.values()) {
            SKILLS.put(pt, (DataParameter<Integer>)EntityDataManager.createKey(EntityVillagerTek.class, (DataSerializer)DataSerializers.VARINT));
        }
    }

    private static class BedCheckRunnable
    implements Runnable {
        private final WeakReference<EntityVillagerTek> villager;

        public BedCheckRunnable(EntityVillagerTek v) {
            this.villager = new WeakReference<EntityVillagerTek>(v);
        }

        @Override
        public void run() {
            if (this.villager.get() != null) {
                ((EntityVillagerTek)((Object)this.villager.get())).bedCheck();
            }
        }
    }

    private static class GoalRandomizerRunnable
    implements Runnable {
        private final WeakReference<EntityVillagerTek> villager;

        public GoalRandomizerRunnable(EntityVillagerTek v) {
            this.villager = new WeakReference<EntityVillagerTek>(v);
        }

        @Override
        public void run() {
            if (this.villager.get() != null) {
                ((EntityVillagerTek)((Object)this.villager.get())).randomizeGoals();
            }
        }
    }

    private static class CleanUpRunnable
    implements Runnable {
        private final WeakReference<EntityVillagerTek> villager;

        public CleanUpRunnable(EntityVillagerTek v) {
            this.villager = new WeakReference<EntityVillagerTek>(v);
        }

        @Override
        public void run() {
            if (this.villager.get() != null) {
                ((EntityVillagerTek)((Object)this.villager.get())).cleanUpInventory();
            }
        }
    }

    public static enum VillagerThought {
        BED(115, "red_bed.png"),
        HUNGRY(116, "food.png"),
        PICK(117, "iron_pick.png"),
        HOE(118, "iron_hoe.png"),
        AXE(119, "iron_axe.png"),
        SWORD(120, "iron_sword.png"),
        BOOKSHELF(121, "bookshelf.png"),
        PIG_FOOD(122, "pig_carrot.png"),
        SHEEP_FOOD(123, "sheep_wheat.png"),
        COW_FOOD(124, "cow_wheat.png"),
        CHICKEN_FOOD(125, "chicken_seeds.png"),
        BUCKET(126, "bucket.png"),
        SHEARS(127, "shears.png"),
        TAVERN(128, "structure_tavern.png"),
        NOTEBLOCK(129, "noteblock.png"),
        TEACHER(130, "prof_teacher.png"),
        TORCH(131, "torch.png"),
        INSOMNIA(132, "insomnia.png"),
        CROWDED(133, "crowded.png"),
        DO_NOT_USE(999, "meh.png");

        private int numVal;
        private String texture;

        private VillagerThought(int val, String tex) {
            this.numVal = val;
            this.texture = tex;
        }

        public int getVal() {
            return this.numVal;
        }

        public String getTex() {
            return this.texture;
        }

        public float getScale() {
            return 1.0f;
        }

        public static VillagerThought valueOf(int val) {
            for (VillagerThought thought : VillagerThought.values()) {
                if (thought.numVal != val) continue;
                return thought;
            }
            return null;
        }
    }

    public static enum MovementMode {
        WALK((byte)1, 1.0f, "villager_walk"),
        SKIP((byte)2, 1.1f, "villager_skip"),
        RUN((byte)3, 1.4f, "villager_run"),
        SULK((byte)4, 0.7f, "villager_walk_sad");

        public float speedMult;
        public byte id;
        public String anim;

        private MovementMode(byte id, float mult, String anim) {
            this.speedMult = mult;
            this.id = id;
            this.anim = anim;
        }

        public static MovementMode valueOf(byte id) {
            for (MovementMode mode : MovementMode.values()) {
                if (mode.id != id) continue;
                return mode;
            }
            return null;
        }
    }
}

