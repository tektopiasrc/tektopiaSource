/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Optional
 *  com.leviathanstudio.craftstudio.common.animation.AnimationHandler
 *  javax.annotation.Nullable
 *  net.minecraft.block.Block
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.entity.ai.EntityAIBase
 *  net.minecraft.init.Blocks
 *  net.minecraft.network.datasync.DataParameter
 *  net.minecraft.network.datasync.DataSerializer
 *  net.minecraft.network.datasync.DataSerializers
 *  net.minecraft.network.datasync.EntityDataManager
 *  net.minecraft.util.EnumParticleTypes
 *  net.minecraft.util.SoundCategory
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.world.World
 */
package net.tangotek.tektopia.entities;

import com.google.common.base.Optional;
import com.leviathanstudio.craftstudio.common.animation.AnimationHandler;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.init.Blocks;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializer;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.tangotek.tektopia.ModSoundEvents;
import net.tangotek.tektopia.ProfessionType;
import net.tangotek.tektopia.TekVillager;
import net.tangotek.tektopia.Village;
import net.tangotek.tektopia.VillagerRole;
import net.tangotek.tektopia.entities.EntityVillagerTek;
import net.tangotek.tektopia.entities.ai.EntityAIEarthReform;
import net.tangotek.tektopia.entities.ai.EntityAIGrowth;

public class EntityDruid
extends EntityVillagerTek {
    protected static AnimationHandler animHandler = TekVillager.getNewAnimationHandler(EntityDruid.class);
    private static final DataParameter<Optional<BlockPos>> SPELL_EARTH_REFORM = EntityDataManager.createKey(EntityDruid.class, (DataSerializer)DataSerializers.OPTIONAL_BLOCK_POS);
    protected static final DataParameter<Optional<BlockPos>> SPELL_BLOCK = EntityDataManager.createKey(EntityDruid.class, (DataSerializer)DataSerializers.OPTIONAL_BLOCK_POS);
    private static final DataParameter<Boolean> CAST_EARTH_REFORM = EntityDataManager.createKey(EntityDruid.class, (DataSerializer)DataSerializers.BOOLEAN);
    private static final DataParameter<Boolean> CAST_GROWTH_CROPS = EntityDataManager.createKey(EntityDruid.class, (DataSerializer)DataSerializers.BOOLEAN);
    private static final DataParameter<Boolean> CAST_GROWTH_TREES = EntityDataManager.createKey(EntityDruid.class, (DataSerializer)DataSerializers.BOOLEAN);
    private static final int[] blockStateIds;
    private int earthReformTicks = 0;
    private int growthTicks = 0;
    private BlockPos clientSpellBlock;
    private boolean growthFirst = true;

    public EntityDruid(World worldIn) {
        super(worldIn, ProfessionType.DRUID, VillagerRole.VILLAGER.value);
        Runnable runner = () -> this.world.playSound(this.posX, this.posY, this.posZ, ModSoundEvents.earthBlast, SoundCategory.NEUTRAL, 1.0f, this.rand.nextFloat() * 0.2f + 0.9f, false);
        if (this.world.isRemote) {
            this.addAnimationTrigger("tektopia:villager_cast_forward", 64, runner);
        }
    }

    @Override
    public AnimationHandler getAnimationHandler() {
        return animHandler;
    }

    @Override
    protected void initEntityAI() {
        super.initEntityAI();
        this.growthFirst = this.getRNG().nextBoolean();
        this.tasks.addTask(50, (EntityAIBase)new EntityAIEarthReform(this));
        this.tasks.addTask(50, (EntityAIBase)new EntityAIGrowth(this, 6.0));
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        this.dataManager.register(SPELL_EARTH_REFORM, Optional.absent());
        this.dataManager.register(SPELL_BLOCK, Optional.absent());
        this.registerAIFilter("cast_earth_reform", CAST_EARTH_REFORM);
        this.registerAIFilter("cast_growth_crops", CAST_GROWTH_CROPS);
        this.registerAIFilter("cast_growth_trees", CAST_GROWTH_TREES);
    }

    @Override
    protected void randomizeGoals() {
        super.randomizeGoals();
        this.growthFirst = this.getRNG().nextBoolean();
    }

    @Override
    public void addVillagerPosition() {
    }

    public BlockPos getSpellBlock() {
        return (BlockPos)((Optional)this.dataManager.get(SPELL_BLOCK)).orNull();
    }

    public void setSpellBlock(BlockPos castingPos) {
        if (castingPos == null) {
            this.dataManager.set(SPELL_BLOCK, Optional.absent());
        } else {
            this.dataManager.set(SPELL_BLOCK, Optional.of(castingPos));
        }
    }

    public void setCastingEarthReform(BlockPos pos) {
        this.getDataManager().set(SPELL_EARTH_REFORM, Optional.fromNullable(pos));
    }

    @Nullable
    public BlockPos getCastingEarthReform() {
        return (BlockPos)((Optional)this.getDataManager().get(SPELL_EARTH_REFORM)).orNull();
    }

    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();
        if (this.world.isRemote && !this.isSleeping()) {
            BlockPos earthPos;
            int i;
            this.clientSpellBlock = this.getSpellBlock();
            if (this.clientSpellBlock != null) {
                ++this.growthTicks;
                int range = this.getGrowthRange();
                this.spawnRadialParticle(this.getPositionVector(), range, this.growthTicks * 3, 4, EnumParticleTypes.TOTEM);
                int particles = this.growthTicks > 40 ? 7 : 1;
                for (i = 0; i < particles; ++i) {
                    this.world.spawnParticle(EnumParticleTypes.TOTEM, (double)this.clientSpellBlock.getX() + 0.5 + this.getRNG().nextGaussian() * (double)range, (double)this.clientSpellBlock.getY() + 0.5, (double)this.clientSpellBlock.getZ() + 0.5 + this.getRNG().nextGaussian() * (double)range, this.getRNG().nextGaussian() * 0.1, (double)this.rand.nextFloat(), this.getRNG().nextGaussian() * 0.1, new int[0]);
                }
            } else {
                this.growthTicks = 0;
            }
            if ((earthPos = this.getCastingEarthReform()) != null) {
                ++this.earthReformTicks;
                if (this.earthReformTicks < 44) {
                    int count = this.earthReformTicks / 3 + 1;
                    for (i = 0; i < count; ++i) {
                        double dx = this.getRNG().nextGaussian();
                        double dz = this.getRNG().nextGaussian();
                        double dy = this.getRNG().nextGaussian();
                        if (i > 0) {
                            this.world.spawnParticle(EnumParticleTypes.BLOCK_DUST, this.posX + dx, this.posY + dy, this.posZ + dz, 0.0, (double)this.getRNG().nextFloat() * 0.5, 0.0, new int[]{blockStateIds[this.getRNG().nextInt(blockStateIds.length)]});
                            continue;
                        }
                        this.world.spawnParticle(EnumParticleTypes.TOTEM, this.posX + dx, this.posY + dy, this.posZ + dz, 0.0, (double)this.getRNG().nextFloat() * 0.5, 0.0, new int[]{blockStateIds[this.getRNG().nextInt(blockStateIds.length)]});
                    }
                } else if (this.earthReformTicks < 55) {
                    Vec3d vec = new Vec3d((double)earthPos.getX(), (double)earthPos.getY(), (double)earthPos.getZ());
                    vec = vec.subtract(this.getPositionVector()).normalize().scale(0.8);
                    for (i = 0; i < 3; ++i) {
                        double dx = this.getRNG().nextGaussian() * 0.1;
                        double dy = this.getRNG().nextGaussian() * 0.1;
                        double dz = this.getRNG().nextGaussian() * 0.1;
                        this.world.spawnParticle(EnumParticleTypes.TOTEM, this.posX + dx + vec.x, this.posY + 1.3 + dy, this.posZ + dz + vec.z, vec.x * 4.0, 0.0, vec.z * 4.0, new int[0]);
                    }
                }
            } else {
                this.earthReformTicks = 0;
                if (this.getRNG().nextInt(10) == 0) {
                    double dx = this.getRNG().nextGaussian() * 0.3;
                    double dz = this.getRNG().nextGaussian() * 0.3;
                    double dy = (double)this.getRNG().nextFloat() * 0.5;
                    this.world.spawnParticle(EnumParticleTypes.TOTEM, this.posX + dx, this.posY + dy + 0.2, this.posZ + dz, 0.0, (double)this.getRNG().nextFloat() * 0.25, 0.0, new int[]{blockStateIds[this.getRNG().nextInt(blockStateIds.length)]});
                }
            }
        }
    }

    private void spawnRadialParticle(Vec3d pos, double radius, float angle, int count, EnumParticleTypes type) {
        for (int i = 0; i < count; ++i) {
            this.world.spawnParticle(type, pos.x + (double)MathHelper.cos((float)(angle + (float)i)) * radius, pos.y + 0.5, pos.z + (double)MathHelper.sin((float)(angle + (float)i)) * radius, 0.0, (double)this.rand.nextFloat() * 0.2, 0.0, new int[0]);
        }
    }

    public int getGrowthRange() {
        int range = MathHelper.clamp((int)(this.getRNG().nextInt(this.getSkill(ProfessionType.DRUID)) / 30), (int)0, (int)2);
        return range;
    }

    public boolean isGrowTime() {
        if (!this.isAIFilterEnabled("cast_earth_reform")) {
            return Village.isTimeOfDay(this.world, 0L, 13000L);
        }
        if (this.growthFirst) {
            return Village.isTimeOfDay(this.world, 0L, 6000L);
        }
        return Village.isTimeOfDay(this.world, 6000L, 13000L);
    }

    public boolean isEarthReformTime() {
        if (!this.isAIFilterEnabled("cast_growth_trees") && !this.isAIFilterEnabled("cast_growth_crops")) {
            return Village.isTimeOfDay(this.world, 0L, 13000L);
        }
        if (this.growthFirst) {
            return Village.isTimeOfDay(this.world, 6000L, 13000L);
        }
        return Village.isTimeOfDay(this.world, 0L, 6000L);
    }

    static {
        int[] nArray = new int[4];
        nArray[0] = Block.getStateId((IBlockState)Blocks.DIRT.getDefaultState());
        nArray[1] = Block.getStateId((IBlockState)Blocks.DIRT.getDefaultState());
        nArray[2] = Block.getStateId((IBlockState)Blocks.STONE.getDefaultState());
        nArray[3] = Block.getStateId((IBlockState)Blocks.COBBLESTONE.getDefaultState());
        blockStateIds = nArray;
        animHandler.addAnim("tektopia", "villager_cast_forward", "druid_m", false);
        animHandler.addAnim("tektopia", "villager_cast_grow", "druid_m", false);
        EntityVillagerTek.setupAnimations(animHandler, "druid_m");
    }
}

