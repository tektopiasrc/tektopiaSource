/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.BlockBed
 *  net.minecraft.block.BlockBed$EnumPartType
 *  net.minecraft.block.BlockDoor
 *  net.minecraft.block.BlockFlowerPot
 *  net.minecraft.block.BlockFlowerPot$EnumFlowerType
 *  net.minecraft.block.properties.IProperty
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.init.Blocks
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.world.World
 *  net.minecraft.world.gen.structure.StructureBoundingBox
 *  net.minecraft.world.gen.structure.StructureVillagePieces$House3
 *  net.minecraft.world.gen.structure.StructureVillagePieces$Start
 */
package net.tangotek.tektopia.generation;

import java.util.Random;
import net.minecraft.block.BlockBed;
import net.minecraft.block.BlockDoor;
import net.minecraft.block.BlockFlowerPot;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.gen.structure.StructureBoundingBox;
import net.minecraft.world.gen.structure.StructureVillagePieces;
import net.tangotek.tektopia.ModBlocks;
import net.tangotek.tektopia.generation.TekStructureVillagePieces;
import net.tangotek.tektopia.structures.VillageStructureType;

public class TekHouse6
extends StructureVillagePieces.House3 {
    private int craftingIndex;
    private int villagersSpawned;

    public TekHouse6(StructureVillagePieces.Start start, int type, Random rand, StructureBoundingBox bbox, EnumFacing facing) {
        super(start, type, rand, bbox, facing);
        this.craftingIndex = rand.nextInt(4);
    }

    public TekHouse6() {
    }

    public boolean addComponentParts(World worldIn, Random randomIn, StructureBoundingBox structureBoundingBoxIn) {
        boolean result = super.addComponentParts(worldIn, randomIn, structureBoundingBoxIn);
        if (!this.isZombieInfested) {
            this.placeBedPiece(worldIn, structureBoundingBoxIn, 3, 1, 8, EnumFacing.NORTH, BlockBed.EnumPartType.FOOT);
            this.placeBedPiece(worldIn, structureBoundingBoxIn, 3, 1, 9, EnumFacing.NORTH, BlockBed.EnumPartType.HEAD);
            this.placeBedPiece(worldIn, structureBoundingBoxIn, 5, 1, 8, EnumFacing.NORTH, BlockBed.EnumPartType.FOOT);
            this.placeBedPiece(worldIn, structureBoundingBoxIn, 5, 1, 9, EnumFacing.NORTH, BlockBed.EnumPartType.HEAD);
            this.placeBedPiece(worldIn, structureBoundingBoxIn, 7, 1, 8, EnumFacing.NORTH, BlockBed.EnumPartType.FOOT);
            this.placeBedPiece(worldIn, structureBoundingBoxIn, 7, 1, 9, EnumFacing.NORTH, BlockBed.EnumPartType.HEAD);
            switch (this.craftingIndex) {
                case 0: {
                    this.setBlockState(worldIn, Blocks.CRAFTING_TABLE.getDefaultState(), 4, 1, 9, structureBoundingBoxIn);
                    this.setBlockState(worldIn, Blocks.FLOWER_POT.getDefaultState().withProperty((IProperty)BlockFlowerPot.CONTENTS, (Comparable)BlockFlowerPot.EnumFlowerType.MUSHROOM_RED), 4, 2, 9, structureBoundingBoxIn);
                    break;
                }
                case 1: {
                    this.setBlockState(worldIn, Blocks.CRAFTING_TABLE.getDefaultState(), 6, 1, 9, structureBoundingBoxIn);
                    break;
                }
                case 2: {
                    this.setBlockState(worldIn, Blocks.CRAFTING_TABLE.getDefaultState(), 7, 1, 4, structureBoundingBoxIn);
                    this.setBlockState(worldIn, Blocks.FLOWER_POT.getDefaultState().withProperty((IProperty)BlockFlowerPot.CONTENTS, (Comparable)BlockFlowerPot.EnumFlowerType.MUSHROOM_RED), 7, 2, 4, structureBoundingBoxIn);
                    break;
                }
                case 3: {
                    this.setBlockState(worldIn, Blocks.CRAFTING_TABLE.getDefaultState(), 7, 1, 2, structureBoundingBoxIn);
                }
            }
            if (randomIn.nextBoolean()) {
                this.setBlockState(worldIn, ModBlocks.blockChair.getDefaultState().withProperty((IProperty)BlockDoor.FACING, (Comparable)EnumFacing.SOUTH), 2, 1, 4, structureBoundingBoxIn);
            }
            if (randomIn.nextBoolean()) {
                this.setBlockState(worldIn, ModBlocks.blockChair.getDefaultState().withProperty((IProperty)BlockDoor.FACING, (Comparable)EnumFacing.NORTH), 4, 1, 1, structureBoundingBoxIn);
            }
            this.placeTorch(worldIn, EnumFacing.WEST, 7, 1, 6, structureBoundingBoxIn);
            this.placeBedPiece(worldIn, structureBoundingBoxIn, 6, 1, 5, EnumFacing.EAST, BlockBed.EnumPartType.FOOT);
            this.placeBedPiece(worldIn, structureBoundingBoxIn, 7, 1, 5, EnumFacing.EAST, BlockBed.EnumPartType.HEAD);
            this.placeBedPiece(worldIn, structureBoundingBoxIn, 6, 1, 3, EnumFacing.EAST, BlockBed.EnumPartType.FOOT);
            this.placeBedPiece(worldIn, structureBoundingBoxIn, 7, 1, 3, EnumFacing.EAST, BlockBed.EnumPartType.HEAD);
            this.placeBedPiece(worldIn, structureBoundingBoxIn, 6, 1, 1, EnumFacing.EAST, BlockBed.EnumPartType.FOOT);
            this.placeBedPiece(worldIn, structureBoundingBoxIn, 7, 1, 1, EnumFacing.EAST, BlockBed.EnumPartType.HEAD);
        }
        return result;
    }

    public BlockPos getBlockPos(int x, int y, int z) {
        return new BlockPos(this.getXWithOffset(x, z), this.getYWithOffset(y), this.getZWithOffset(x, z));
    }

    protected void createVillageDoor(World w, StructureBoundingBox bb, Random rand, int x, int y, int z, EnumFacing facing) {
        super.createVillageDoor(w, bb, rand, x, y, z, facing);
        TekStructureVillagePieces.addStructureFrame(w, bb, this.getBlockPos(x, y, z), VillageStructureType.HOME6);
    }

    private void placeBedPiece(World worldIn, StructureBoundingBox bbox, int x, int y, int z, EnumFacing facing, BlockBed.EnumPartType partType) {
        this.setBlockState(worldIn, Blocks.AIR.getDefaultState(), x, y + 1, z, bbox);
        IBlockState bedState = Blocks.BED.getDefaultState().withProperty((IProperty)BlockBed.OCCUPIED, (Comparable)Boolean.valueOf(false)).withProperty((IProperty)BlockBed.FACING, (Comparable)facing);
        this.setBlockState(worldIn, bedState.withProperty((IProperty)BlockBed.PART, (Comparable)partType), x, y, z, bbox);
    }

    protected void spawnVillagers(World worldIn, StructureBoundingBox structurebb, int x, int y, int z, int count) {
    }
}

