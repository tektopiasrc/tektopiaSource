/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.BlockDoor
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.item.EntityItemFrame
 *  net.minecraft.entity.passive.EntityVillager
 *  net.minecraft.init.Items
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Vec3i
 *  net.minecraft.world.IBlockAccess
 *  net.minecraft.world.World
 *  net.minecraft.world.gen.structure.MapGenStructureIO
 *  net.minecraft.world.gen.structure.StructureBoundingBox
 *  net.minecraftforge.fml.common.registry.VillagerRegistry
 *  net.minecraftforge.fml.common.registry.VillagerRegistry$IVillageCreationHandler
 */
package net.tangotek.tektopia.generation;

import java.util.List;
import java.util.Random;
import net.minecraft.block.BlockDoor;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItemFrame;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.init.Items;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraft.world.gen.structure.MapGenStructureIO;
import net.minecraft.world.gen.structure.StructureBoundingBox;
import net.minecraftforge.fml.common.registry.VillagerRegistry;
import net.tangotek.tektopia.ItemTagType;
import net.tangotek.tektopia.ModItems;
import net.tangotek.tektopia.entities.EntityBard;
import net.tangotek.tektopia.entities.EntityBlacksmith;
import net.tangotek.tektopia.entities.EntityCleric;
import net.tangotek.tektopia.entities.EntityDruid;
import net.tangotek.tektopia.entities.EntityFarmer;
import net.tangotek.tektopia.entities.EntityGuard;
import net.tangotek.tektopia.entities.EntityLumberjack;
import net.tangotek.tektopia.entities.EntityNitwit;
import net.tangotek.tektopia.entities.EntityVillagerTek;
import net.tangotek.tektopia.generation.TekHouse2;
import net.tangotek.tektopia.generation.TekHouse2Handler;
import net.tangotek.tektopia.generation.TekHouse2b;
import net.tangotek.tektopia.generation.TekHouse2bHandler;
import net.tangotek.tektopia.generation.TekHouse6;
import net.tangotek.tektopia.generation.TekHouse6Handler;
import net.tangotek.tektopia.generation.TekStorageHall;
import net.tangotek.tektopia.generation.TekStorageHallHandler;
import net.tangotek.tektopia.generation.TekTownHall;
import net.tangotek.tektopia.generation.TekTownHallHandler;
import net.tangotek.tektopia.structures.VillageStructureType;

public class TekStructureVillagePieces {
    public static void registerVillagePieces() {
        System.out.println("Registering Tek Village Structures");
        MapGenStructureIO.registerStructureComponent(TekTownHall.class, (String)"TekTownHall");
        MapGenStructureIO.registerStructureComponent(TekStorageHall.class, (String)"TekStorage");
        MapGenStructureIO.registerStructureComponent(TekHouse6.class, (String)"TekHouse6");
        MapGenStructureIO.registerStructureComponent(TekHouse2.class, (String)"TekHouse2");
        MapGenStructureIO.registerStructureComponent(TekHouse2b.class, (String)"TekHouse2b");
        VillagerRegistry.instance().registerVillageCreationHandler((VillagerRegistry.IVillageCreationHandler)new TekTownHallHandler());
        VillagerRegistry.instance().registerVillageCreationHandler((VillagerRegistry.IVillageCreationHandler)new TekStorageHallHandler());
        VillagerRegistry.instance().registerVillageCreationHandler((VillagerRegistry.IVillageCreationHandler)new TekHouse6Handler());
        VillagerRegistry.instance().registerVillageCreationHandler((VillagerRegistry.IVillageCreationHandler)new TekHouse2Handler());
        VillagerRegistry.instance().registerVillageCreationHandler((VillagerRegistry.IVillageCreationHandler)new TekHouse2bHandler());
    }

    public static EntityItemFrame addStructureFrame(World worldIn, StructureBoundingBox bbox, BlockPos doorPos, VillageStructureType structType) {
        EnumFacing facing = BlockDoor.getFacing((IBlockAccess)worldIn, (BlockPos)doorPos).getOpposite();
        BlockPos framePos = doorPos.offset(facing, 1).offset(facing.rotateY(), 1).up();
        if (bbox.isVecInside((Vec3i)framePos)) {
            EntityItemFrame itemFrame = new EntityItemFrame(worldIn, framePos, facing);
            itemFrame.setDisplayedItem(structType.itemStack);
            worldIn.spawnEntity((Entity)itemFrame);
            return itemFrame;
        }
        return null;
    }

    public static void replaceVillagers(World world, Random ran, double x1, double y1, double z1, double x2, double y2, double z2) {
        List<EntityVillager> villagerList = world.getEntitiesWithinAABB(EntityVillager.class, new AxisAlignedBB(x1, y1, z1, x2, y2, z2));
        for (EntityVillager vil : villagerList) {
            EntityVillagerTek newVillager = TekStructureVillagePieces.generateVillager(world, ran);
            newVillager.copyLocationAndAnglesFrom((Entity)vil);
            newVillager.onInitialSpawn(world.getDifficultyForLocation(newVillager.getPosition()), null);
            world.spawnEntity((Entity)newVillager);
            vil.setDead();
        }
    }

    public static EntityVillagerTek generateVillager(World world, Random ran) {
        EntityVillagerTek newVillager;
        int rnd = ran.nextInt(80);
        if (rnd < 40) {
            newVillager = new EntityFarmer(world);
        } else if (rnd < 60) {
            newVillager = new EntityLumberjack(world);
            newVillager.getInventory().addItem(ModItems.createTaggedItem(Items.STONE_AXE, 1, ItemTagType.VILLAGER));
        } else if (rnd < 70) {
            newVillager = new EntityGuard(world);
            newVillager.getInventory().addItem(ModItems.createTaggedItem(Items.STONE_SWORD, 1, ItemTagType.VILLAGER));
        } else {
            newVillager = rnd == 70 ? new EntityBard(world) : (rnd == 71 ? new EntityCleric(world) : (rnd == 72 ? new EntityBlacksmith(world) : (rnd == 73 ? new EntityDruid(world) : new EntityNitwit(world))));
        }
        return newVillager;
    }
}

