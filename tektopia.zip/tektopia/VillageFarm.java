/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockCrops
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.init.Blocks
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.world.World
 *  net.minecraftforge.event.world.BlockEvent$CropGrowEvent
 */
package net.tangotek.tektopia;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.function.Predicate;
import net.minecraft.block.Block;
import net.minecraft.block.BlockCrops;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraftforge.event.world.BlockEvent;
import net.tangotek.tektopia.Village;

public class VillageFarm {
    private static int nextId = 1;
    private final int farmId;
    private int cropUpdateTick = 0;
    protected final World world;
    private int distanceToVillageCenter = 0;
    protected AxisAlignedBB aabb;
    protected List<BlockPos> fullCrops = new ArrayList<BlockPos>();
    protected Set<BlockPos> activeFarmland = new HashSet<BlockPos>();
    private int blocks = 0;
    private double weightScore;
    public static int MAX_AREA = 1000;

    public VillageFarm(World w, BlockPos startPos, Village v) {
        this.farmId = nextId++;
        this.world = w;
        this.aabb = new AxisAlignedBB(startPos, startPos);
        HashSet<BlockPos> tested = new HashSet<BlockPos>();
        this.testFarmLand(startPos, tested);
        this.blocks = tested.size();
        this.distanceToVillageCenter = (int)this.getFarmCenter().distanceTo(new Vec3d((double)v.getCenter().getX(), (double)v.getCenter().getY(), (double)v.getCenter().getZ()));
        this.cropUpdateTick = 500 + this.world.rand.nextInt(500);
        this.updateWeightScore(v.getSize());
    }

    public int size() {
        return this.blocks;
    }

    public void updateWeightScore(int villageSize) {
        this.weightScore = (double)villageSize / (double)this.distanceToVillageCenter * (double)this.blocks;
    }

    public double getWeightScore() {
        return this.weightScore;
    }

    private Vec3d getFarmCenter() {
        return new Vec3d(this.aabb.minX + (this.aabb.maxX - this.aabb.minX) * 0.5, this.aabb.minY + (this.aabb.maxY - this.aabb.minY) * 0.5, this.aabb.minZ + (this.aabb.maxZ - this.aabb.minZ) * 0.5);
    }

    public boolean isBlockInside(BlockPos pos) {
        if ((double)pos.getX() >= this.aabb.minX && (double)pos.getX() <= this.aabb.maxX && (double)pos.getZ() >= this.aabb.minZ && (double)pos.getZ() <= this.aabb.maxZ) {
            return (double)pos.getY() >= this.aabb.minY && (double)pos.getY() <= this.aabb.maxY;
        }
        return false;
    }

    public BlockPos getMaxAgeCrop() {
        while (!this.fullCrops.isEmpty()) {
            BlockPos pos = this.fullCrops.remove(this.world.rand.nextInt(this.fullCrops.size()));
            if (!VillageFarm.isMaxAgeCrop(this.world, pos)) continue;
            return pos;
        }
        return null;
    }

    public BlockPos getFarmland(Predicate<BlockPos> pred) {
        for (int i = 0; i < 20; ++i) {
            int z;
            int x = MathHelper.getInt((Random)this.world.rand, (int)((int)this.aabb.minX), (int)((int)this.aabb.maxX));
            BlockPos pos = new BlockPos((double)x, this.aabb.minY, (double)(z = MathHelper.getInt((Random)this.world.rand, (int)((int)this.aabb.minZ), (int)((int)this.aabb.maxZ))));
            if (!this.isNearWater(pos) || !this.isFarmlandAdjacent(pos) || !pred.test(pos) || this.activeFarmland.contains(pos)) continue;
            this.activeFarmland.add(pos);
            return pos;
        }
        return null;
    }

    private boolean isFarmlandAdjacent(BlockPos pos) {
        int count = 0;
        if (this.world.getBlockState(pos.west()).getBlock() == Blocks.FARMLAND) {
            ++count;
        }
        if (this.world.getBlockState(pos.north()).getBlock() == Blocks.FARMLAND) {
            ++count;
        }
        if (this.world.getBlockState(pos.south()).getBlock() == Blocks.FARMLAND) {
            ++count;
        }
        if (this.world.getBlockState(pos.east()).getBlock() == Blocks.FARMLAND) {
            ++count;
        }
        return count >= 2;
    }

    private boolean isNearWater(BlockPos cropPos) {
        for (BlockPos testPos : BlockPos.getAllInBox((BlockPos)cropPos.add(-4, 0, -4), (BlockPos)cropPos.add(4, 0, 4))) {
            Block testBlock = this.world.getBlockState(testPos).getBlock();
            if (testBlock != Blocks.WATER && testBlock != Blocks.FLOWING_WATER) continue;
            return true;
        }
        return false;
    }

    public int distanceToVillageCenter() {
        return this.distanceToVillageCenter;
    }

    public void update(BlockPos villageCenter) {
        --this.cropUpdateTick;
        if (this.cropUpdateTick <= 0) {
            this.refreshFullCrops();
            this.activeFarmland.clear();
        }
    }

    private void testFarmLand(BlockPos pos, Set<BlockPos> tested) {
        if (VillageFarm.isFarmLand(this.world, pos) && this.getArea() < MAX_AREA && !tested.contains(pos)) {
            this.aabb = this.aabb.union(new AxisAlignedBB(pos, pos));
            tested.add(pos);
            if (VillageFarm.isMaxAgeCrop(this.world, pos.up())) {
                this.fullCrops.add(pos.up());
            }
            this.testFarmLand(pos.west(), tested);
            this.testFarmLand(pos.east(), tested);
            this.testFarmLand(pos.north(), tested);
            this.testFarmLand(pos.south(), tested);
        }
    }

    public void onCropGrowEvent(BlockEvent.CropGrowEvent event) {
        if (this.isBlockInside(event.getPos().down()) && VillageFarm.isMaxAgeCrop(this.world, event.getPos())) {
            this.fullCrops.add(event.getPos());
        }
    }

    private void refreshFullCrops() {
        this.fullCrops.clear();
        for (int x = (int)this.aabb.minX; x <= (int)this.aabb.maxX; ++x) {
            for (int z = (int)this.aabb.minZ; z <= (int)this.aabb.maxZ; ++z) {
                BlockPos pos = new BlockPos((double)x, this.aabb.minY, (double)z).up();
                if (!VillageFarm.isMaxAgeCrop(this.world, pos)) continue;
                this.fullCrops.add(pos);
            }
        }
        this.cropUpdateTick = 250 + this.world.rand.nextInt(250);
    }

    public AxisAlignedBB getAABB() {
        return this.aabb;
    }

    public Vec3d getCenter() {
        return this.aabb.getCenter();
    }

    public String debug() {
        String result = "Farm #" + this.farmId + "  fullCrops: " + this.fullCrops.size() + " W: " + (int)this.getWeightScore() + "  C: " + new BlockPos(this.getCenter()) + " XZ: " + (this.aabb.maxX - this.aabb.minX) + ", " + (this.aabb.maxZ - this.aabb.minZ);
        return result;
    }

    public int getArea() {
        return (int)(this.aabb.maxX - this.aabb.minX) * (int)(this.aabb.maxZ - this.aabb.minZ);
    }

    public static boolean isFarmLand(World world, BlockPos pos) {
        Block block = world.getBlockState(pos).getBlock();
        return block == Blocks.FARMLAND;
    }

    public static boolean isMaxAgeCrop(World world, BlockPos pos) {
        IBlockState iblockstate = world.getBlockState(pos);
        Block block = iblockstate.getBlock();
        return block instanceof BlockCrops && ((BlockCrops)block).isMaxAge(iblockstate);
    }
}

