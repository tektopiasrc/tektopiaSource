/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockPlanks$EnumType
 *  net.minecraft.init.Blocks
 *  net.minecraft.init.Items
 *  net.minecraft.item.EnumDyeColor
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.nbt.NBTBase
 *  net.minecraft.nbt.NBTTagCompound
 *  net.minecraft.tileentity.TileEntity
 *  net.minecraft.tileentity.TileEntityChest
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.world.World
 *  net.minecraftforge.common.capabilities.Capability
 *  net.minecraftforge.common.capabilities.Capability$IStorage
 */
package net.tangotek.tektopia.caps;

import java.util.Random;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.BlockPlanks;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import net.minecraftforge.common.capabilities.Capability;
import net.tangotek.tektopia.ItemTagType;
import net.tangotek.tektopia.ModItems;
import net.tangotek.tektopia.ProfessionType;
import net.tangotek.tektopia.Village;
import net.tangotek.tektopia.caps.IVillageData;
import net.tangotek.tektopia.economy.ItemEconomy;
import net.tangotek.tektopia.economy.ItemValue;

public class VillageData
implements IVillageData,
Capability.IStorage<IVillageData> {
    private long childSpawnTime = 0L;
    private int totalProfessionSales = 0;
    private boolean checkedMerchants = false;
    private boolean checkedNomads = false;
    private boolean startingGifts = false;
    private boolean isEmpty = true;
    protected ItemEconomy economy = new ItemEconomy();
    private UUID uuid = UUID.randomUUID();

    @Override
    public void initEconomy() {
        if (this.economy.hasItems()) {
            return;
        }
        this.economy.addItem(new ItemValue(new ItemStack(Blocks.LOG, 64, BlockPlanks.EnumType.JUNGLE.getMetadata()), 4, 22, ProfessionType.LUMBERJACK));
        this.economy.addItem(new ItemValue(new ItemStack(Blocks.LOG, 64, BlockPlanks.EnumType.BIRCH.getMetadata()), 4, 22, ProfessionType.LUMBERJACK));
        this.economy.addItem(new ItemValue(new ItemStack(Blocks.LOG, 64, BlockPlanks.EnumType.OAK.getMetadata()), 4, 22, ProfessionType.LUMBERJACK));
        this.economy.addItem(new ItemValue(new ItemStack(Blocks.LOG, 64, BlockPlanks.EnumType.SPRUCE.getMetadata()), 4, 22, ProfessionType.LUMBERJACK));
        this.economy.addItem(new ItemValue(new ItemStack(Items.WHEAT, 64), 4, 20, ProfessionType.FARMER));
        this.economy.addItem(new ItemValue(new ItemStack(Items.POTATO, 64), 4, 20, ProfessionType.FARMER));
        this.economy.addItem(new ItemValue(new ItemStack(Items.BEETROOT, 64), 4, 20, ProfessionType.FARMER));
        this.economy.addItem(new ItemValue(new ItemStack(Items.CARROT, 64), 4, 20, ProfessionType.FARMER));
        this.economy.addItem(new ItemValue(new ItemStack(Items.BREAD, 16), 8, 10, ProfessionType.CHEF));
        this.economy.addItem(new ItemValue(new ItemStack(Items.CAKE, 1), 4, 5, ProfessionType.CHEF));
        this.economy.addItem(new ItemValue(new ItemStack(Items.COOKED_PORKCHOP, 32), 10, 15, ProfessionType.CHEF));
        this.economy.addItem(new ItemValue(new ItemStack(Items.COOKED_BEEF, 32), 10, 15, ProfessionType.CHEF));
        this.economy.addItem(new ItemValue(new ItemStack(Items.COOKED_CHICKEN, 32), 10, 15, ProfessionType.CHEF));
        this.economy.addItem(new ItemValue(new ItemStack(Items.COOKED_MUTTON, 32), 10, 15, ProfessionType.CHEF));
        this.economy.addItem(new ItemValue(new ItemStack(Items.BAKED_POTATO, 32), 4, 15, ProfessionType.CHEF));
        this.economy.addItem(new ItemValue(new ItemStack((Item)Items.LEATHER_HELMET, 1), 2, 10, ProfessionType.BUTCHER));
        this.economy.addItem(new ItemValue(new ItemStack((Item)Items.LEATHER_CHESTPLATE, 1), 3, 10, ProfessionType.BUTCHER));
        this.economy.addItem(new ItemValue(new ItemStack((Item)Items.LEATHER_LEGGINGS, 1), 3, 10, ProfessionType.BUTCHER));
        this.economy.addItem(new ItemValue(new ItemStack((Item)Items.LEATHER_BOOTS, 1), 2, 10, ProfessionType.BUTCHER));
        this.economy.addItem(new ItemValue(new ItemStack(Items.EGG, 16), 2, 20, ProfessionType.RANCHER));
        this.economy.addItem(new ItemValue(new ItemStack(Item.getItemFromBlock((Block)Blocks.WOOL), 64), 7, 20, ProfessionType.RANCHER));
        this.economy.addItem(new ItemValue(new ItemStack(Items.REDSTONE, 64), 5, 20, ProfessionType.MINER));
        this.economy.addItem(new ItemValue(new ItemStack(Items.DIAMOND, 4), 12, 10, ProfessionType.MINER));
        this.economy.addItem(new ItemValue(new ItemStack(Items.DYE, 16, EnumDyeColor.BLUE.getDyeDamage()), 5, 15, ProfessionType.MINER));
        this.economy.addItem(new ItemValue(new ItemStack(Items.GOLD_INGOT, 16), 12, 10, ProfessionType.BLACKSMITH));
        this.economy.addItem(new ItemValue(new ItemStack(Items.IRON_PICKAXE, 1), 5, 5, ProfessionType.BLACKSMITH));
        this.economy.addItem(new ItemValue(new ItemStack(Items.IRON_AXE, 1), 5, 5, ProfessionType.BLACKSMITH));
        this.economy.addItem(new ItemValue(new ItemStack(Items.IRON_SWORD, 1), 4, 5, ProfessionType.BLACKSMITH));
        this.economy.addItem(new ItemValue(new ItemStack((Item)Items.IRON_CHESTPLATE, 1), 10, 5, ProfessionType.BLACKSMITH));
        this.economy.addItem(new ItemValue(new ItemStack((Item)Items.IRON_LEGGINGS, 1), 9, 5, ProfessionType.BLACKSMITH));
        this.economy.addItem(new ItemValue(new ItemStack((Item)Items.IRON_HELMET, 1), 7, 5, ProfessionType.BLACKSMITH));
        this.economy.addItem(new ItemValue(new ItemStack((Item)Items.IRON_BOOTS, 1), 6, 5, ProfessionType.BLACKSMITH));
        this.economy.addItem(new ItemValue(new ItemStack(Items.DIAMOND_PICKAXE, 1), 10, 5, ProfessionType.BLACKSMITH));
        this.economy.addItem(new ItemValue(new ItemStack(Items.DIAMOND_AXE, 1), 10, 5, ProfessionType.BLACKSMITH));
        this.economy.addItem(new ItemValue(new ItemStack(Items.DIAMOND_SWORD, 1), 8, 5, ProfessionType.BLACKSMITH));
        this.economy.addItem(new ItemValue(new ItemStack((Item)Items.DIAMOND_CHESTPLATE, 1), 20, 5, ProfessionType.BLACKSMITH));
        this.economy.addItem(new ItemValue(new ItemStack((Item)Items.DIAMOND_LEGGINGS, 1), 18, 5, ProfessionType.BLACKSMITH));
        this.economy.addItem(new ItemValue(new ItemStack((Item)Items.DIAMOND_HELMET, 1), 14, 5, ProfessionType.BLACKSMITH));
        this.economy.addItem(new ItemValue(new ItemStack((Item)Items.DIAMOND_BOOTS, 1), 12, 5, ProfessionType.BLACKSMITH));
        this.economy.addItem(new ItemValue(new ItemStack(Items.PAPER, 16), 3, 20, ProfessionType.ENCHANTER));
        this.economy.addItem(new ItemValue(new ItemStack(Items.BOOK, 8), 8, 20, ProfessionType.ENCHANTER));
    }

    @Override
    public ItemEconomy getEconomy() {
        return this.economy;
    }

    @Override
    public void setNomadsCheckedToday(boolean checked) {
        this.checkedNomads = checked;
    }

    @Override
    public boolean getNomadsCheckedToday() {
        return this.checkedNomads;
    }

    @Override
    public void setMerchantCheckedToday(boolean checked) {
        this.checkedMerchants = checked;
    }

    @Override
    public boolean getMerchantCheckedToday() {
        return this.checkedMerchants;
    }

    @Override
    public UUID getUUID() {
        return this.uuid;
    }

    @Override
    public boolean isChildReady(long totalWorldTime) {
        return totalWorldTime > this.childSpawnTime;
    }

    @Override
    public void childSpawned(World w) {
        this.childSpawnTime = w.getTotalWorldTime() + (long)MathHelper.getInt((Random)w.rand, (int)20000, (int)30000);
    }

    @Override
    public void incrementProfessionSales() {
        ++this.totalProfessionSales;
    }

    @Override
    public int getProfessionSales() {
        return this.totalProfessionSales;
    }

    @Override
    public boolean completedStartingGifts() {
        return this.startingGifts;
    }

    @Override
    public void skipStartingGifts() {
        this.startingGifts = true;
    }

    @Override
    public void executeStartingGifts(World world, Village village, BlockPos pos) {
        this.startingGifts = true;
        world.setBlockState(pos, Blocks.CHEST.getDefaultState());
        TileEntity tileEntity = world.getTileEntity(pos);
        if (tileEntity instanceof TileEntityChest) {
            TileEntityChest chest = (TileEntityChest)tileEntity;
            this.addGiftItem(chest, village, ModItems.structureStorage, 12);
            this.addGiftItem(chest, village, ModItems.structureHome2, 13);
            this.addGiftItem(chest, village, ModItems.itemFarmer, 14);
            this.addGiftItem(chest, village, ModItems.itemLumberjack, 15);
        }
    }

    private void addGiftItem(TileEntityChest chest, Village village, Item item, int slot) {
        ItemStack itemStack = ModItems.createTaggedItem(item, ItemTagType.VILLAGER);
        ModItems.bindItemToVillage(itemStack, village);
        chest.setInventorySlotContents(slot, itemStack);
    }

    @Override
    public void writeNBT(NBTTagCompound compound) {
        compound.setUniqueId("uuid", this.uuid);
        compound.setLong("childTime", this.childSpawnTime);
        compound.setBoolean("checkedMerchants", this.checkedMerchants);
        compound.setBoolean("checkedNomads", this.checkedNomads);
        compound.setInteger("totalProfessionSales", this.totalProfessionSales);
        compound.setBoolean("startingGifts", this.startingGifts);
        if (this.economy != null) {
            this.economy.writeNBT(compound);
        }
    }

    @Override
    public void readNBT(NBTTagCompound compound) {
        this.uuid = compound.getUniqueId("uuid");
        if (this.uuid.getLeastSignificantBits() == 0L && this.uuid.getMostSignificantBits() == 0L) {
            this.uuid = UUID.randomUUID();
        }
        this.childSpawnTime = compound.getLong("childTime");
        this.checkedMerchants = compound.getBoolean("checkedMerchants");
        this.checkedNomads = compound.getBoolean("checkedNomads");
        this.totalProfessionSales = compound.getInteger("totalProfessionSales");
        this.startingGifts = compound.getBoolean("startingGifts");
        if (compound.hasKey("SalesHistory")) {
            this.initEconomy();
            this.getEconomy().readNBT(compound);
        }
        this.isEmpty = false;
    }

    @Override
    public boolean isEmpty() {
        return this.isEmpty;
    }

    @Nullable
    public NBTBase writeNBT(Capability<IVillageData> capability, IVillageData instance, EnumFacing side) {
        NBTTagCompound compound = new NBTTagCompound();
        instance.writeNBT(compound);
        return compound;
    }

    public void readNBT(Capability<IVillageData> capability, IVillageData instance, EnumFacing side, NBTBase nbt) {
        if (nbt instanceof NBTTagCompound) {
            NBTTagCompound compound = (NBTTagCompound)nbt;
            instance.readNBT(compound);
        }
    }
}

