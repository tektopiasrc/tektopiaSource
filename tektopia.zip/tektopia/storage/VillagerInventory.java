/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.inventory.InventoryBasic
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.nbt.NBTBase
 *  net.minecraft.nbt.NBTTagCompound
 *  net.minecraft.nbt.NBTTagList
 *  net.minecraft.util.Tuple
 *  net.minecraft.util.text.ITextComponent
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 */
package net.tangotek.tektopia.storage;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import net.minecraft.inventory.InventoryBasic;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.Tuple;
import net.minecraft.util.text.ITextComponent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.tangotek.tektopia.ModItems;
import net.tangotek.tektopia.entities.EntityVillagerTek;

public class VillagerInventory
extends InventoryBasic {
    private final EntityVillagerTek owner;

    public VillagerInventory(EntityVillagerTek villager, String title, boolean customName, int slotCount) {
        super(title, customName, slotCount);
        this.owner = villager;
    }

    @SideOnly(value=Side.CLIENT)
    public VillagerInventory(ITextComponent title, int slotCount) {
        this(null, title.getUnformattedText(), true, slotCount);
    }

    public List<ItemStack> removeItems(Function<ItemStack, Integer> func, int itemCount) {
        return this.findItems(func, itemCount, true);
    }

    public List<ItemStack> removeItems(Predicate<ItemStack> pred, int itemCount) {
        return this.findItems(p -> pred.test((ItemStack)p) ? 1 : 0, itemCount, true);
    }

    public List<ItemStack> getItems(Predicate<ItemStack> pred, int itemCount) {
        return this.findItems(p -> pred.test((ItemStack)p) ? 1 : 0, itemCount, false);
    }

    public ItemStack getItem(Function<ItemStack, Integer> func) {
        List<ItemStack> items = this.findItems(func, 1, false);
        if (!items.isEmpty()) {
            return items.get(0);
        }
        return ItemStack.EMPTY;
    }

    public List<ItemStack> getItems(Function<ItemStack, Integer> func, int itemCount) {
        return this.findItems(func, itemCount, false);
    }

    public List<ItemStack> getItemsByStack(Function<ItemStack, Integer> func, int itemCount) {
        return this.findItems(func, itemCount, false);
    }

    public int getItemCount(Predicate<ItemStack> pred) {
        return this.getItemCount((ItemStack item) -> pred.test((ItemStack)item) ? 1 : -1);
    }

    public int getItemCount(Function<ItemStack, Integer> func) {
        List<ItemStack> itemList = this.getItems(func, 0);
        int count = 0;
        for (ItemStack itemStack : itemList) {
            count += itemStack.getCount();
        }
        return count;
    }

    public void cloneFrom(VillagerInventory other) {
        for (int i = 0; i < other.getSizeInventory(); ++i) {
            this.addItem(other.getStackInSlot(i));
        }
    }

    public static int countItems(List<ItemStack> items) {
        return items.stream().mapToInt(ItemStack::getCount).sum();
    }

    private List<ItemStack> findItems(Function<ItemStack, Integer> func, int itemCount, boolean remove) {
        int i;
        ArrayList<ItemStack> outList = new ArrayList<ItemStack>();
        int needed = itemCount > 0 ? itemCount : Integer.MAX_VALUE;
        ArrayList<Tuple> matchedItems = new ArrayList<Tuple>();
        for (i = 0; i < this.getSizeInventory(); ++i) {
            ItemStack itemStack = this.getStackInSlot(i);
            if (!ModItems.canVillagerSee(itemStack) || func.apply(itemStack) <= 0) continue;
            matchedItems.add(new Tuple((Object)itemStack, (Object)i));
        }
        matchedItems.sort(Comparator.comparing(pair -> (Integer)func.apply((ItemStack)pair.getFirst())));
        for (i = matchedItems.size() - 1; i >= 0 && needed > 0; --i) {
            Tuple pair2 = (Tuple)matchedItems.get(i);
            ItemStack itemStack = (ItemStack)pair2.getFirst();
            int slot = (Integer)pair2.getSecond();
            if (remove) {
                if (itemStack.getCount() <= needed) {
                    outList.add(itemStack);
                    this.setInventorySlotContents(slot, ItemStack.EMPTY);
                    needed -= itemStack.getCount();
                    continue;
                }
                itemStack.shrink(needed);
                ItemStack newItem = itemStack.copy();
                newItem.setCount(needed);
                outList.add(newItem);
                needed = 0;
                this.onInventoryUpdated(newItem);
                continue;
            }
            outList.add(itemStack);
            needed -= itemStack.getCount();
        }
        return outList;
    }

    private void onInventoryUpdated(ItemStack itemStack) {
        if (this.owner != null && !this.owner.world.isRemote) {
            this.owner.onInventoryUpdated(itemStack);
        }
    }

    public void deleteOverstock(Item itemOuter, int max) {
        this.deleteOverstock((ItemStack p) -> p.getItem() == itemOuter, max);
    }

    public void deleteOverstock(Predicate<ItemStack> predicate, int max) {
        int count = 0;
        for (int i = 0; i < this.getSizeInventory(); ++i) {
            ItemStack itemStack = this.getStackInSlot(i);
            if (!predicate.test(itemStack)) continue;
            if (count >= max) {
                this.setInventorySlotContents(i, ItemStack.EMPTY);
                continue;
            }
            if (count + itemStack.getCount() > max) {
                itemStack.setCount(max - count);
                this.onInventoryUpdated(itemStack);
                count = max;
                continue;
            }
            count += itemStack.getCount();
        }
    }

    public boolean hasSlotFree() {
        for (int i = 0; i < this.getSizeInventory(); ++i) {
            ItemStack itemStack = this.getStackInSlot(i);
            if (!itemStack.isEmpty()) continue;
            return true;
        }
        return false;
    }

    public void mergeItems(VillagerInventory other) {
        for (int i = 0; i < other.getSizeInventory(); ++i) {
            ItemStack itemStack = other.getStackInSlot(i);
            if (!itemStack.isEmpty()) continue;
            this.addItem(itemStack);
        }
    }

    public ItemStack addItem(ItemStack stack) {
        ItemStack newItem = stack.copy();
        int emptySlot = -1;
        for (int i = 0; i < this.getSizeInventory(); ++i) {
            ItemStack oldItem = this.getStackInSlot(i);
            if (oldItem.isEmpty() && emptySlot < 0) {
                emptySlot = i;
                continue;
            }
            if (!VillagerInventory.areItemsStackable(oldItem, newItem)) continue;
            int j = Math.min(this.getInventoryStackLimit(), oldItem.getMaxStackSize());
            int k = Math.min(newItem.getCount(), j - oldItem.getCount());
            if (k <= 0) continue;
            oldItem.grow(k);
            newItem.shrink(k);
            if (!newItem.isEmpty()) continue;
            this.onInventoryUpdated(oldItem);
            this.markDirty();
            return ItemStack.EMPTY;
        }
        if (emptySlot >= 0 && !newItem.isEmpty()) {
            this.setInventorySlotContents(emptySlot, newItem);
            return ItemStack.EMPTY;
        }
        if (newItem.getCount() != stack.getCount()) {
            this.markDirty();
        }
        return newItem;
    }

    public ItemStack removeStackFromSlot(int index) {
        ItemStack itemStack = super.removeStackFromSlot(index);
        if (!itemStack.isEmpty()) {
            this.onInventoryUpdated(itemStack);
        }
        return itemStack;
    }

    public void setInventorySlotContents(int index, ItemStack stack) {
        ItemStack oldItem = this.getStackInSlot(index);
        super.setInventorySlotContents(index, stack);
        if (!oldItem.isEmpty()) {
            this.onInventoryUpdated(oldItem);
        }
        this.onInventoryUpdated(stack);
    }

    public static boolean areItemsStackable(ItemStack itemStack1, ItemStack itemStack2) {
        return ItemStack.areItemsEqual((ItemStack)itemStack1, (ItemStack)itemStack2) && ItemStack.areItemStackTagsEqual((ItemStack)itemStack1, (ItemStack)itemStack2);
    }

    public void debugSpam() {
        for (int i = 0; i < this.getSizeInventory(); ++i) {
            ItemStack itemStack = this.getStackInSlot(i);
            if (itemStack.isEmpty()) continue;
            System.out.println("    Item: " + itemStack.toString());
        }
    }

    public void writeNBT(NBTTagCompound compound) {
        NBTTagList nbttaglist = new NBTTagList();
        for (int i = 0; i < this.getSizeInventory(); ++i) {
            ItemStack itemstack = this.getStackInSlot(i);
            if (itemstack.isEmpty()) continue;
            nbttaglist.appendTag((NBTBase)itemstack.writeToNBT(new NBTTagCompound()));
        }
        compound.setTag("Inventory", (NBTBase)nbttaglist);
    }

    public void readNBT(NBTTagCompound compound) {
        this.clear();
        NBTTagList nbttaglist = compound.getTagList("Inventory", 10);
        for (int i = 0; i < nbttaglist.tagCount(); ++i) {
            ItemStack itemstack = new ItemStack(nbttaglist.getCompoundTagAt(i));
            if (itemstack.isEmpty()) continue;
            this.addItem(itemstack);
        }
    }
}

