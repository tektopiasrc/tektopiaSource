/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemStack
 *  net.minecraft.tileentity.TileEntityChest
 */
package net.tangotek.tektopia.storage;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntityChest;
import net.tangotek.tektopia.VillageManager;
import net.tangotek.tektopia.entities.EntityVillagerTek;
import net.tangotek.tektopia.entities.crafting.Recipe;
import net.tangotek.tektopia.storage.ItemDesire;
import net.tangotek.tektopia.storage.VillagerInventory;

public class ItemDesireSet {
    protected List<ItemDesire> itemDesires = new ArrayList<ItemDesire>();
    protected boolean deliveryDirty = true;
    protected int deliveryId = 0;
    protected byte deliverySlot = (byte)-1;
    protected short deliveryCount = 0;
    protected int totalDeliverySize = 0;

    public void clear() {
        this.itemDesires.clear();
    }

    public void addItemDesire(ItemDesire desire) {
        this.itemDesires.add(desire);
    }

    public void addRecipeDesire(Recipe r) {
        for (ItemStack need : r.getNeeds()) {
            Predicate<ItemStack> pred = need.getMetadata() == 99 ? p -> p.getItem() == need.getItem() && !p.isItemEnchanted() : p -> ItemStack.areItemsEqual((ItemStack)p, (ItemStack)need) && !p.isItemEnchanted();
            Predicate<EntityVillagerTek> shouldNeed = p -> p.isAIFilterEnabled(r.getAiFilter());
            if (r.shouldCraft != null) {
                shouldNeed = shouldNeed.and(r.shouldCraft);
            }
            this.addItemDesire(new ItemDesire(need.getItem().getUnlocalizedName(), pred, need.getCount(), need.getCount() * r.idealCount, need.getCount() * r.limitCount, shouldNeed));
        }
    }

    public void forceUpdate() {
        this.itemDesires.forEach(d -> d.forceUpdate());
        this.deliveryDirty = true;
    }

    public void onStorageUpdated(EntityVillagerTek villager, ItemStack storageItem) {
        this.itemDesires.forEach(d -> d.onStorageUpdated(villager, storageItem));
    }

    public void onInventoryUpdated(EntityVillagerTek villager, ItemStack updatedItem) {
        this.itemDesires.forEach(d -> d.onInventoryUpdated(villager, updatedItem));
        this.deliveryDirty = true;
    }

    public ItemDesire getNeededDesire(EntityVillagerTek villager) {
        for (ItemDesire d : this.itemDesires) {
            if (!d.shouldPickUp(villager)) continue;
            return d;
        }
        return null;
    }

    private void updateDeliveryList(EntityVillagerTek villager) {
        if (this.deliveryDirty && villager.hasVillage()) {
            this.deliverySlot = (byte)-1;
            this.deliveryCount = 0;
            this.totalDeliverySize = 0;
            int bestValue = 0;
            for (int i = villager.getInventory().getSizeInventory() - 1; i >= 0; --i) {
                ItemStack itemStack = villager.getInventory().getStackInSlot(i);
                if (itemStack.isEmpty()) continue;
                int minDeliver = Integer.MAX_VALUE;
                for (ItemDesire desire : this.itemDesires) {
                    int toDeliver = desire.getDeliverToStorage(villager, itemStack);
                    if (toDeliver <= 0) {
                        minDeliver = Integer.MAX_VALUE;
                        break;
                    }
                    if (toDeliver <= 0 || toDeliver >= minDeliver) continue;
                    minDeliver = toDeliver;
                }
                if (minDeliver >= Integer.MAX_VALUE) continue;
                int value = VillageManager.getItemValue(itemStack.getItem()) * minDeliver;
                if (value > bestValue) {
                    bestValue = value;
                    this.deliveryCount = (short)minDeliver;
                    this.deliverySlot = (byte)i;
                }
                this.totalDeliverySize += value;
            }
            this.deliveryDirty = false;
            ++this.deliveryId;
        }
    }

    public int getDeliveryId(EntityVillagerTek villager, int requiredDeliverSize) {
        this.updateDeliveryList(villager);
        if (this.totalDeliverySize >= requiredDeliverSize) {
            return this.deliveryId;
        }
        return 0;
    }

    public boolean isDeliveryMatch(int id) {
        return this.deliveryId == id;
    }

    public ItemStack getDeliveryItemCopy(EntityVillagerTek villager) {
        this.updateDeliveryList(villager);
        if (this.deliverySlot >= 0) {
            ItemStack deliverItem = villager.getInventory().getStackInSlot(this.deliverySlot).copy();
            deliverItem.setCount((int)this.deliveryCount);
            return deliverItem;
        }
        return ItemStack.EMPTY;
    }

    public boolean deliverItems(EntityVillagerTek villager, TileEntityChest destInv, int deliveryCheckId) {
        if (this.deliveryId != deliveryCheckId) {
            villager.debugOut("Delivery Id mismatch");
            this.deliveryDirty = true;
            return false;
        }
        if (this.deliverySlot < 0) {
            villager.debugOut("Delivery FAILED. No active delivery.");
            this.deliveryDirty = true;
            return false;
        }
        ItemStack removedStack = villager.getInventory().decrStackSize(this.deliverySlot, this.deliveryCount);
        if (removedStack == ItemStack.EMPTY) {
            villager.debugOut("Delivery FAILED. Delivery item not found in villager inventory");
            this.deliveryDirty = true;
            return false;
        }
        if (!this.deliverOneItem(removedStack, destInv, villager)) {
            villager.debugOut("Delivery FAILED. Returning to villager inventory " + removedStack);
            villager.getInventory().addItem(removedStack);
            this.deliveryDirty = true;
            return false;
        }
        return true;
    }

    private boolean deliverOneItem(ItemStack sourceStack, TileEntityChest destChest, EntityVillagerTek villager) {
        int emptySlot = -1;
        for (int d = 0; d < destChest.getSizeInventory(); ++d) {
            int k;
            ItemStack destStack = destChest.getStackInSlot(d);
            if (destStack.isEmpty() && emptySlot < 0) {
                emptySlot = d;
                continue;
            }
            if (!VillagerInventory.areItemsStackable(destStack, sourceStack) || (k = Math.min(sourceStack.getCount(), destStack.getMaxStackSize() - destStack.getCount())) <= 0) continue;
            destStack.grow(k);
            if (villager.hasVillage()) {
                villager.getVillage().onStorageChange(destChest, d, destStack);
            }
            villager.onInventoryUpdated(destStack);
            sourceStack.shrink(k);
            if (!sourceStack.isEmpty()) continue;
            return true;
        }
        if (emptySlot >= 0) {
            destChest.setInventorySlotContents(emptySlot, sourceStack);
            if (villager.hasVillage()) {
                villager.getVillage().onStorageChange(destChest, emptySlot, sourceStack);
            }
            return true;
        }
        return false;
    }
}

