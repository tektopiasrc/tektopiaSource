/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.creativetab.CreativeTabs
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.item.EntityItem
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.Blocks
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.EnumActionResult
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.EnumParticleTypes
 *  net.minecraft.util.SoundCategory
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.world.World
 */
package net.tangotek.tektopia.items;

import java.util.List;
import java.util.Random;
import java.util.UUID;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import net.tangotek.tektopia.ModSoundEvents;
import net.tangotek.tektopia.TekVillager;
import net.tangotek.tektopia.entities.EntityChild;
import net.tangotek.tektopia.entities.EntityVillagerTek;

public class ItemHeart
extends Item {
    private String name;

    public ItemHeart(String name) {
        this.setCreativeTab(CreativeTabs.MISC);
        this.setRegistryName(name);
        this.setUnlocalizedName(name);
        this.name = name;
    }

    public void registerItemModel() {
        TekVillager.proxy.registerItemRenderer(this, 0, this.name);
    }

    public int getEntityLifespan(ItemStack itemStack, World world) {
        return Integer.MAX_VALUE;
    }

    public boolean onEntityItemUpdate(EntityItem entityItem) {
        if (entityItem.world.isRemote) {
            if (entityItem.world.rand.nextInt(17) == 0) {
                entityItem.world.playSound((double)((float)entityItem.posX + 0.5f), (double)((float)entityItem.posY + 0.5f), (double)((float)entityItem.posZ + 0.5f), ModSoundEvents.twinkle, SoundCategory.BLOCKS, MathHelper.nextFloat((Random)entityItem.world.rand, (float)0.8f, (float)1.1f), MathHelper.nextFloat((Random)entityItem.world.rand, (float)0.7f, (float)1.3f), false);
            }
            if (entityItem.world.rand.nextInt(4) == 0) {
                double d0 = (double)((float)entityItem.posX) + MathHelper.nextDouble((Random)itemRand, (double)-3.0, (double)3.0);
                double d1 = (double)((float)entityItem.posY) + MathHelper.nextDouble((Random)itemRand, (double)0.5, (double)2.0);
                double d2 = (double)((float)entityItem.posZ) + MathHelper.nextDouble((Random)itemRand, (double)-3.0, (double)3.0);
                entityItem.world.spawnParticle(EnumParticleTypes.HEART, d0, d1, d2, 0.0, itemRand.nextDouble() * 0.2, 0.0, new int[0]);
            }
        }
        return super.onEntityItemUpdate(entityItem);
    }

    public EnumActionResult onItemUseFirst(EntityPlayer player, World world, BlockPos pos, EnumFacing side, float hitX, float hitY, float hitZ, EnumHand hand) {
        IBlockState iblockstate = world.getBlockState(pos);
        ItemStack itemstack = player.getHeldItem(hand);
        if (player.canPlayerEdit(pos.offset(side), side, itemstack) && iblockstate.getBlock() == Blocks.BED) {
            if (world.isRemote) {
                for (int i = 0; i < 10; ++i) {
                    double d0 = (double)pos.getX() + MathHelper.nextDouble((Random)itemRand, (double)-2.0, (double)2.0);
                    double d1 = (double)pos.getY() + MathHelper.nextDouble((Random)itemRand, (double)0.5, (double)1.5);
                    double d2 = (double)pos.getZ() + MathHelper.nextDouble((Random)itemRand, (double)-2.0, (double)2.0);
                    world.spawnParticle(EnumParticleTypes.HEART, d0, d1, d2, 0.0, itemRand.nextDouble() * 0.2, 0.0, new int[0]);
                    d0 = (double)pos.getX() + MathHelper.nextDouble((Random)itemRand, (double)-1.0, (double)1.0);
                    d1 = (double)pos.getY() + MathHelper.nextDouble((Random)itemRand, (double)0.5, (double)1.5);
                    d2 = (double)pos.getZ() + MathHelper.nextDouble((Random)itemRand, (double)-1.0, (double)1.0);
                    world.spawnParticle(EnumParticleTypes.VILLAGER_HAPPY, d0, d1, d2, 0.0, itemRand.nextDouble() * 0.2, 0.0, new int[0]);
                    d0 = (double)pos.getX() + MathHelper.nextDouble((Random)itemRand, (double)-1.0, (double)1.0);
                    d1 = (double)pos.getY() + MathHelper.nextDouble((Random)itemRand, (double)0.5, (double)1.5);
                    d2 = (double)pos.getZ() + MathHelper.nextDouble((Random)itemRand, (double)-1.0, (double)1.0);
                    world.spawnParticle(EnumParticleTypes.VILLAGER_HAPPY, d0, d1, d2, 0.0, itemRand.nextDouble() * 0.2, 0.0, new int[0]);
                }
                return EnumActionResult.SUCCESS;
            }
            String parentLastName = "";
            if (itemstack.getSubCompound("village").hasUniqueId("parent")) {
                UUID parentUUID = itemstack.getSubCompound("village").getUniqueId("parent");
                List parents = world.getEntitiesWithinAABB(EntityVillagerTek.class, new AxisAlignedBB(pos).grow(200.0, 255.0, 200.0), p -> p.getUniqueID() == parentUUID);
                if (!parents.isEmpty()) {
                    EntityVillagerTek parent = (EntityVillagerTek)((Object)parents.get(0));
                    parentLastName = parent.getLastName();
                }
            }
            itemstack.shrink(1);
            EntityChild child = new EntityChild(world);
            child.setLocationAndAngles((double)pos.getX() + 0.5, pos.getY() + 1, (double)pos.getZ() + 0.5, 0.0f, 0.0f);
            child.onInitialSpawn(world.getDifficultyForLocation(pos), null);
            String childFirstName = child.getFirstName();
            if (!parentLastName.isEmpty() && !childFirstName.isEmpty()) {
                child.setCustomNameTag(childFirstName + " " + parentLastName);
            }
            world.spawnEntity((Entity)child);
            world.playSound((EntityPlayer)null, pos, ModSoundEvents.villagerHeartMagic, SoundCategory.BLOCKS, 1.5f, 1.0f);
            return EnumActionResult.SUCCESS;
        }
        return EnumActionResult.FAIL;
    }
}

