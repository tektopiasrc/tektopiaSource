/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.material.Material
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.item.EntityItemFrame
 *  net.minecraft.init.Blocks
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.world.World
 */
package net.tangotek.tektopia.structures;

import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItemFrame;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.tangotek.tektopia.ProfessionType;
import net.tangotek.tektopia.Village;
import net.tangotek.tektopia.entities.EntityDruid;
import net.tangotek.tektopia.entities.EntityMiner;
import net.tangotek.tektopia.entities.EntityVillagerTek;
import net.tangotek.tektopia.structures.VillageStructure;
import net.tangotek.tektopia.structures.VillageStructureType;
import net.tangotek.tektopia.tickjob.TickJob;

public class VillageStructureMineshaft
extends VillageStructure {
    private EntityVillagerTek currentMiner = null;
    private EntityDruid druid = null;
    private BlockPos miningPos;

    protected VillageStructureMineshaft(World world, Village v, EntityItemFrame itemFrame) {
        super(world, v, itemFrame, VillageStructureType.MINESHAFT, "Mineshaft");
    }

    public int getTunnelLength() {
        return this.floorTiles.size();
    }

    public BlockPos getMiningPos() {
        return this.miningPos;
    }

    public BlockPos getWalkingPos() {
        return this.miningPos.offset(this.signFacing, 1);
    }

    @Override
    public boolean adjustsVillageCenter() {
        return false;
    }

    @Override
    protected void setupServerJobs() {
        this.addJob(new TickJob(20, 10, true, () -> this.updateOccupants()));
        super.setupServerJobs();
    }

    public void updateOccupants() {
        List occupants = this.world.getEntitiesWithinAABB(EntityVillagerTek.class, this.aabb);
        if (occupants.isEmpty()) {
            this.setTunnelMiner(null);
        } else if (this.getTunnelMiner() == null) {
            this.setTunnelMiner((EntityVillagerTek)((Object)occupants.get(0)));
        } else if (!occupants.contains((Object)this.getTunnelMiner())) {
            this.setTunnelMiner(null);
        }
        EntityVillagerTek miner = this.getTunnelMiner();
        if (miner != null) {
            this.tryPlaceTorch(miner);
        }
    }

    public void tryPlaceTorch(EntityVillagerTek miner) {
        BlockPos pos = miner.getPosition();
        if (miner.world.getLightFromNeighbors(pos) < 8 && !miner.getInventory().removeItems(EntityMiner.isTorch(), 1).isEmpty()) {
            miner.world.setBlockState(pos, Blocks.TORCH.getDefaultState());
        }
    }

    public EntityVillagerTek getTunnelMiner() {
        return this.currentMiner;
    }

    private void setTunnelMiner(EntityVillagerTek miner) {
        this.currentMiner = miner;
    }

    public void setDruid(EntityDruid d) {
        this.druid = d;
    }

    public EntityDruid getDruid() {
        return this.druid;
    }

    public void checkExtendTunnel() {
        while (VillageStructureMineshaft.isTunnel(this, this.miningPos)) {
            this.addFloorTile(this.miningPos);
            this.miningPos = this.miningPos.offset(this.signFacing, -1);
        }
    }

    public void regrow(EntityVillagerTek villager) {
        if (this.getTunnelLength() > 3) {
            BlockPos regrowPos = this.getWalkingPos();
            this.regrowColumn(villager, regrowPos);
            this.regrowColumn(villager, regrowPos.offset(this.signFacing.rotateYCCW(), 1));
            this.regrowColumn(villager, regrowPos.offset(this.signFacing.rotateY(), 1));
        }
        this.doFloorScan();
    }

    protected void regrowColumn(EntityVillagerTek villager, BlockPos pos) {
        this.regrowBlock(villager, pos.down());
        this.regrowBlock(villager, pos);
        this.regrowBlock(villager, pos.up());
        this.regrowBlock(villager, pos.up(2));
    }

    protected void regrowBlock(EntityVillagerTek villager, BlockPos pos) {
        if (!VillageStructureMineshaft.isOre(villager.world, pos)) {
            if (villager.getRNG().nextInt(1000) < villager.getSkillLerp(ProfessionType.DRUID, 25, 40)) {
                this.world.setBlockState(pos, VillageStructureMineshaft.getRegrowBlock(villager).getDefaultState(), 2);
            } else {
                this.world.setBlockState(pos, Blocks.STONE.getDefaultState(), 2);
            }
        }
    }

    public static Block getRegrowBlock(EntityVillagerTek villager) {
        int oreRoll = villager.getRNG().nextInt(325);
        if (oreRoll < 10) {
            return Blocks.DIAMOND_ORE;
        }
        if (oreRoll < 20) {
            return Blocks.LAPIS_ORE;
        }
        if (oreRoll < 35) {
            return Blocks.GOLD_ORE;
        }
        if (oreRoll < 100) {
            return Blocks.IRON_ORE;
        }
        if (oreRoll < 200) {
            return Blocks.COAL_ORE;
        }
        if (villager.getRNG().nextInt(3) == 0) {
            return Blocks.REDSTONE_ORE;
        }
        return Blocks.STONE;
    }

    @Override
    protected void onFloorScanStart() {
        this.miningPos = this.door.offset(this.signFacing, -1);
        super.onFloorScanStart();
    }

    public BlockPos findOre(BlockPos pos, int distance, EnumFacing fromDir) {
        if (distance > 3) {
            return null;
        }
        if (this.world.isAirBlock(pos)) {
            BlockPos next = null;
            if (fromDir != EnumFacing.DOWN && (next = this.findOre(pos.up(), distance + 1, EnumFacing.UP)) != null) {
                return next;
            }
            if (fromDir != EnumFacing.UP && (next = this.findOre(pos.down(), distance + 1, EnumFacing.DOWN)) != null) {
                return next;
            }
            if (fromDir != this.signFacing.rotateY() && (next = this.findOre(pos.offset(this.signFacing.rotateYCCW(), 1), distance + 1, this.signFacing.rotateYCCW())) != null) {
                return next;
            }
            if (fromDir != this.signFacing.rotateYCCW() && (next = this.findOre(pos.offset(this.signFacing.rotateY(), 1), distance + 1, this.signFacing.rotateY())) != null) {
                return next;
            }
        } else if (VillageStructureMineshaft.isOre(this.world, pos) && VillageStructureMineshaft.canDig(this.world, pos)) {
            return pos;
        }
        return null;
    }

    public static boolean isOre(World world, BlockPos pos) {
        Block b = world.getBlockState(pos).getBlock();
        return b == Blocks.COAL_ORE || b == Blocks.IRON_ORE || b == Blocks.DIAMOND_ORE || b == Blocks.GOLD_ORE || b == Blocks.LAPIS_ORE || b == Blocks.EMERALD_ORE || b == Blocks.REDSTONE_ORE;
    }

    public static boolean canDig(World world, BlockPos pos) {
        return !world.getBlockState(pos.up()).getMaterial().isLiquid() && !world.getBlockState(pos.west()).getMaterial().isLiquid() && !world.getBlockState(pos.east()).getMaterial().isLiquid() && !world.getBlockState(pos.north()).getMaterial().isLiquid() && !world.getBlockState(pos.south()).getMaterial().isLiquid();
    }

    public boolean canMine() {
        if (this.miningPos == null) {
            return false;
        }
        if (!this.village.isInVillage(this.miningPos.offset(this.signFacing, -1))) {
            return false;
        }
        if (this.world.getBlockState(this.miningPos).getMaterial().isLiquid()) {
            return false;
        }
        if (this.world.getBlockState(this.miningPos.up()).getMaterial().isLiquid()) {
            return false;
        }
        if (VillageStructureMineshaft.isSolid(this, this.miningPos) && !VillageStructureMineshaft.canDig(this.world, this.miningPos)) {
            return false;
        }
        return !VillageStructureMineshaft.isSolid(this, this.miningPos.up()) || VillageStructureMineshaft.canDig(this.world, this.miningPos.up());
    }

    @Override
    protected BlockPos findDoor() {
        BlockPos dp = null;
        dp = this.framePos.offset(this.signFacing, -1).offset(this.signFacing.rotateY(), 1).down();
        if (!VillageStructureMineshaft.isTunnel(this, dp)) {
            dp = this.framePos.offset(this.signFacing, -1).offset(this.signFacing.rotateY(), -1).down();
            if (!VillageStructureMineshaft.isTunnel(this, dp)) {
                dp = this.framePos.offset(this.signFacing, -1).down(2);
            }
            if (!VillageStructureMineshaft.isTunnel(this, dp)) {
                dp = null;
            }
        }
        return dp;
    }

    public static boolean isTunnel(VillageStructureMineshaft mineshaft, BlockPos floorPos) {
        BlockPos upPos = floorPos.up();
        return VillageStructureMineshaft.isAir(mineshaft, upPos) && VillageStructureMineshaft.isAir(mineshaft, floorPos) && VillageStructureMineshaft.isSolid(mineshaft, upPos.up()) && VillageStructureMineshaft.isSolid(mineshaft, floorPos.down()) && VillageStructureMineshaft.isSolid(mineshaft, upPos.offset(mineshaft.signFacing.rotateY(), 1)) && VillageStructureMineshaft.isSolid(mineshaft, upPos.offset(mineshaft.signFacing.rotateY(), -1)) && VillageStructureMineshaft.isSolid(mineshaft, floorPos.offset(mineshaft.signFacing.rotateY(), 1)) && VillageStructureMineshaft.isSolid(mineshaft, floorPos.offset(mineshaft.signFacing.rotateY(), -1));
    }

    public static BlockPos getTunnelFlaw(VillageStructureMineshaft mineshaft, BlockPos pos) {
        BlockPos testPos = pos.down();
        if (!VillageStructureMineshaft.isSolid(mineshaft, testPos)) {
            return testPos;
        }
        testPos = pos.offset(mineshaft.signFacing.rotateY(), 1);
        if (!VillageStructureMineshaft.isSolid(mineshaft, testPos)) {
            return testPos;
        }
        testPos = pos.offset(mineshaft.signFacing.rotateY(), -1);
        if (!VillageStructureMineshaft.isSolid(mineshaft, testPos)) {
            return testPos;
        }
        testPos = pos.up().offset(mineshaft.signFacing.rotateY(), 1);
        if (!VillageStructureMineshaft.isSolid(mineshaft, testPos)) {
            return testPos;
        }
        testPos = pos.up().offset(mineshaft.signFacing.rotateY(), -1);
        if (!VillageStructureMineshaft.isSolid(mineshaft, testPos)) {
            return testPos;
        }
        testPos = pos.up(2);
        if (!VillageStructureMineshaft.isSolid(mineshaft, testPos)) {
            return testPos;
        }
        return null;
    }

    public static boolean isAir(VillageStructureMineshaft mineshaft, BlockPos pos) {
        return mineshaft.world.getBlockState(pos).getMaterial() == Material.AIR || mineshaft.world.getBlockState(pos).getBlock() == Blocks.TORCH;
    }

    public static boolean isSolid(VillageStructureMineshaft mineshaft, BlockPos pos) {
        return mineshaft.world.getBlockState(pos).isFullBlock();
    }

    @Override
    protected void scanFloor(BlockPos pos) {
        if (!this.floorTiles.contains(pos) && VillageStructureMineshaft.isTunnel(this, pos) && this.village.getPathingGraph().isInGraph(pos)) {
            this.miningPos = pos.offset(this.signFacing, -1);
            this.ceilingHeightSum += 2;
            this.addFloorTile(pos);
            this.scanFloor(pos.offset(this.signFacing, -1));
        }
    }

    private void addFloorTile(BlockPos pos) {
        this.floorTiles.add(pos);
        this.aabb = this.aabb.union(new AxisAlignedBB(pos));
    }

    @Override
    public boolean validate() {
        this.isValid = true;
        if (this.door == null) {
            this.isValid = false;
        }
        Entity e = this.world.getEntityByID(this.signEntityId);
        if (this.isValid && (e == null || !(e instanceof EntityItemFrame))) {
            this.debugOut("Mineshaft struct frame is missing or wrong type");
            this.isValid = false;
        }
        EntityItemFrame itemFrame = (EntityItemFrame)e;
        if (this.isValid && itemFrame.getHangingPosition() != this.framePos) {
            this.debugOut("Mineshaft struct center has moved");
            this.isValid = false;
        }
        if (this.isValid && !itemFrame.getDisplayedItem().isItemEqual(this.type.itemStack)) {
            this.debugOut("Mineshaft struct frame item has changed");
            this.isValid = false;
        }
        if (!this.canMine()) {
            this.isValid = false;
        }
        return this.isValid;
    }
}

