/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockBed
 *  net.minecraft.block.properties.IProperty
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.entity.item.EntityItemFrame
 *  net.minecraft.init.Blocks
 *  net.minecraft.item.EnumDyeColor
 *  net.minecraft.tileentity.TileEntity
 *  net.minecraft.tileentity.TileEntityBed
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.world.IBlockAccess
 *  net.minecraft.world.World
 */
package net.tangotek.tektopia.structures;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.ListIterator;
import net.minecraft.block.Block;
import net.minecraft.block.BlockBed;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.item.EntityItemFrame;
import net.minecraft.init.Blocks;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityBed;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.tangotek.tektopia.Village;
import net.tangotek.tektopia.entities.EntityVillagerTek;
import net.tangotek.tektopia.structures.VillageStructure;
import net.tangotek.tektopia.structures.VillageStructureType;
import net.tangotek.tektopia.tickjob.TickJob;

public class VillageStructureHome
extends VillageStructure {
    private List<EntityVillagerTek> residents = new ArrayList<EntityVillagerTek>();
    private final int maxBeds;

    protected VillageStructureHome(World world, Village v, EntityItemFrame itemFrame, VillageStructureType structureType, String name, int maxBeds) {
        super(world, v, itemFrame, structureType, name);
        this.maxBeds = maxBeds;
    }

    @Override
    protected void setupServerJobs() {
        this.addJob(new TickJob(40, 40, true, () -> this.evictResidents()));
        super.setupServerJobs();
    }

    public List<EntityVillagerTek> getResidents() {
        return Collections.unmodifiableList(this.residents);
    }

    @Override
    public void onDestroy() {
        for (EntityVillagerTek resident : this.residents) {
            resident.clearHome();
        }
        ArrayList<BlockPos> beds = new ArrayList<BlockPos>(this.getSpecialBlocks(Blocks.BED));
        for (BlockPos bed : beds) {
            this.setBedColor(bed, EnumDyeColor.RED);
        }
        super.onDestroy();
    }

    public static boolean isBed(World w, BlockPos bp) {
        IBlockState state = w.isBlockLoaded(bp) ? w.getBlockState(bp) : null;
        return state != null && state.getBlock().isBed(state, (IBlockAccess)w, bp, null);
    }

    public boolean isBedFoot(BlockPos bp) {
        if (VillageStructureHome.isBed(this.world, bp)) {
            return Blocks.BED.isBedFoot((IBlockAccess)this.world, bp) && this.world.isAirBlock(bp.up());
        }
        return false;
    }

    @Override
    protected void scanSpecialBlock(BlockPos pos, Block block) {
        if (this.isBedFoot(pos)) {
            ArrayList<BlockPos> existingBeds = new ArrayList<BlockPos>(this.getSpecialBlocks(Blocks.BED));
            if (existingBeds.size() < this.maxBeds) {
                this.addSpecialBlock(Blocks.BED, pos);
                boolean claimed = false;
                for (EntityVillagerTek resident : this.residents) {
                    if (resident.getBedPos() == null || !resident.getBedPos().equals((Object)pos)) continue;
                    this.setBedColor(pos, EnumDyeColor.GREEN);
                    claimed = true;
                }
                if (!claimed) {
                    this.setBedColor(pos, EnumDyeColor.YELLOW);
                }
            } else {
                this.setBedColor(pos, EnumDyeColor.RED);
            }
        }
        super.scanSpecialBlock(pos, block);
    }

    public boolean canSleepAt(BlockPos pos) {
        for (EntityVillagerTek resident : this.residents) {
            BlockPos headPos;
            if (!resident.isSleeping()) continue;
            if (resident.getBedPos().equals((Object)pos)) {
                return false;
            }
            IBlockState blockState = this.village.getWorld().getBlockState(resident.getBedPos());
            EnumFacing facing = (EnumFacing)blockState.getValue((IProperty)BlockBed.FACING);
            if (facing == null || !(headPos = resident.getBedPos().offset(facing)).equals((Object)pos)) continue;
            return false;
        }
        return true;
    }

    public boolean canVillagerSleep(EntityVillagerTek villager) {
        return true;
    }

    public void addResident(EntityVillagerTek villager) {
        if (!this.isFull() && !this.residents.contains((Object)villager)) {
            ArrayList<BlockPos> beds = new ArrayList<BlockPos>(this.getSpecialBlocks(Blocks.BED));
            for (EntityVillagerTek resident : this.residents) {
                ListIterator bedItr = beds.listIterator();
                while (bedItr.hasNext()) {
                    if (!((BlockPos)bedItr.next()).equals((Object)resident.getBedPos())) continue;
                    bedItr.remove();
                }
            }
            if (!beds.isEmpty()) {
                villager.setHome((BlockPos)beds.get(0), this.framePos);
                this.residents.add(villager);
                if (this.village != null && this.village.isValid()) {
                    this.setBedColor((BlockPos)beds.get(0), EnumDyeColor.GREEN);
                }
            }
        }
    }

    private void setBedColor(BlockPos footPos, EnumDyeColor color) {
        TileEntityBed bed;
        TileEntity tileEntity = this.village.getWorld().getTileEntity(footPos);
        if (tileEntity instanceof TileEntityBed && (bed = (TileEntityBed)tileEntity).getColor() != color) {
            bed.setColor(color);
            IBlockState blockState = this.village.getWorld().getBlockState(footPos);
            EnumFacing facing = (EnumFacing)blockState.getValue((IProperty)BlockBed.FACING);
            BlockPos headPos = footPos.offset(facing);
            IBlockState headState = this.village.getWorld().getBlockState(headPos);
            tileEntity = this.village.getWorld().getTileEntity(headPos);
            if (tileEntity instanceof TileEntityBed) {
                bed = (TileEntityBed)tileEntity;
                bed.setColor(color);
            }
            this.village.getWorld().markAndNotifyBlock(footPos, null, blockState, blockState, 3);
            this.village.getWorld().markAndNotifyBlock(headPos, null, headState, headState, 3);
        }
    }

    public void evictResidents() {
        ListIterator<EntityVillagerTek> itr = this.residents.listIterator();
        while (itr.hasNext()) {
            EntityVillagerTek resident = itr.next();
            if (!resident.isEntityAlive()) {
                itr.remove();
                continue;
            }
            if (resident.getBedPos() != null && this.isBedFoot(resident.getBedPos())) continue;
            resident.clearHome();
            itr.remove();
        }
    }

    public int getMaxResidents() {
        return this.getSpecialBlocks(Blocks.BED).size();
    }

    public int getCurResidents() {
        return this.residents.size();
    }

    public boolean isFull() {
        return this.getCurResidents() >= this.getMaxResidents();
    }

    @Override
    protected boolean shouldVillagerSit(EntityVillagerTek villager) {
        return this.world.rand.nextInt(2) == 0;
    }

    @Override
    public int getSitTime(EntityVillagerTek villager) {
        return 100 + villager.getRNG().nextInt(300);
    }

    public void villageReport(StringBuilder builder) {
        builder.append("        Home: " + this.getDoor() + "     " + this.getCurResidents() + " residents\n");
        for (EntityVillagerTek resident : this.residents) {
            builder.append("            " + ((Object)((Object)resident)).getClass().getSimpleName() + "|" + resident.getDisplayName().getFormattedText() + "|" + resident.getEntityId() + "        Happy: " + resident.getHappy() + "   Hunger: " + resident.getHunger() + "\n");
        }
    }
}

