/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.IEntityLivingData
 *  net.minecraft.entity.item.EntityItemFrame
 *  net.minecraft.entity.passive.EntityAnimal
 *  net.minecraft.entity.passive.EntityChicken
 *  net.minecraft.init.Items
 *  net.minecraft.init.SoundEvents
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.world.World
 */
package net.tangotek.tektopia.structures;

import java.util.function.Predicate;
import net.minecraft.entity.Entity;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.item.EntityItemFrame;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityChicken;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.tangotek.tektopia.EntityTagType;
import net.tangotek.tektopia.ItemTagType;
import net.tangotek.tektopia.ModEntities;
import net.tangotek.tektopia.ModItems;
import net.tangotek.tektopia.Village;
import net.tangotek.tektopia.entities.EntityVillagerTek;
import net.tangotek.tektopia.structures.VillageStructureRancherPen;
import net.tangotek.tektopia.structures.VillageStructureType;

public class VillageStructureChickenCoop
extends VillageStructureRancherPen {
    protected VillageStructureChickenCoop(World world, Village v, EntityItemFrame itemFrame) {
        super(world, v, itemFrame, VillageStructureType.CHICKEN_COOP, 1, "Chicken Coop");
    }

    @Override
    public EntityAnimal spawnAnimal(BlockPos pos) {
        EntityChicken animal = new EntityChicken(this.world);
        animal.setLocationAndAngles((double)pos.getX() + 0.5, (double)pos.getY(), (double)pos.getZ() + 0.5, 0.0f, 0.0f);
        animal.onInitialSpawn(this.world.getDifficultyForLocation(pos), (IEntityLivingData)null);
        this.world.spawnEntity((Entity)animal);
        ModEntities.makeTaggedEntity((Entity)animal, EntityTagType.VILLAGER);
        return animal;
    }

    @Override
    public Class getAnimalClass() {
        return EntityChicken.class;
    }

    public static Predicate<ItemStack> isFood() {
        return p -> p.getItem() == Items.WHEAT_SEEDS || p.getItem() == Items.BEETROOT_SEEDS;
    }

    @Override
    public EntityVillagerTek.VillagerThought getNoFoodThought() {
        return EntityVillagerTek.VillagerThought.CHICKEN_FOOD;
    }

    @Override
    public EntityVillagerTek.VillagerThought getNoHarvestThought() {
        return EntityVillagerTek.VillagerThought.BUCKET;
    }

    @Override
    protected void updateAnimal(EntityAnimal animal) {
        if (animal instanceof EntityChicken) {
            EntityChicken chicken = (EntityChicken)animal;
            chicken.timeUntilNextEgg = 9999999;
            if (!(this.world.isRemote || chicken.isChild() || chicken.isChickenJockey() || chicken.getRNG().nextInt(500) != 0)) {
                chicken.playSound(SoundEvents.ENTITY_CHICKEN_EGG, 1.0f, (chicken.getRNG().nextFloat() - chicken.getRNG().nextFloat()) * 0.2f + 1.0f);
                chicken.entityDropItem(ModItems.makeTaggedItem(new ItemStack(Items.EGG), ItemTagType.VILLAGER), 0.0f);
            }
        }
        super.updateAnimal(animal);
    }
}

