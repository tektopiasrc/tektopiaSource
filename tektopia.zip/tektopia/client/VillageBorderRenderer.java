/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.client.multiplayer.WorldClient
 *  net.minecraft.client.renderer.BufferBuilder
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.GlStateManager$DestFactor
 *  net.minecraft.client.renderer.GlStateManager$SourceFactor
 *  net.minecraft.client.renderer.Tessellator
 *  net.minecraft.client.renderer.vertex.DefaultVertexFormats
 *  net.minecraft.entity.Entity
 *  net.minecraft.util.ResourceLocation
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.MathHelper
 *  net.minecraftforge.client.event.RenderWorldLastEvent
 *  net.minecraftforge.common.MinecraftForge
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package net.tangotek.tektopia.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.tangotek.tektopia.VillageClient;

public class VillageBorderRenderer {
    private static final ResourceLocation FORCEFIELD_TEXTURES = new ResourceLocation("textures/misc/forcefield.png");
    private VillageClient villageClient = null;

    public VillageBorderRenderer() {
        MinecraftForge.EVENT_BUS.register((Object)this);
    }

    @SubscribeEvent
    public void renderWorldLast(RenderWorldLastEvent event) {
        if (this.villageClient == null) {
            return;
        }
        Minecraft minecraft = Minecraft.getMinecraft();
        WorldClient world = minecraft.world;
        EntityPlayerSP player = minecraft.player;
        if (world == null || player == null) {
            return;
        }
        this.renderBorder((Entity)player, event.getPartialTicks());
    }

    public void updateVillage(VillageClient vc) {
        this.villageClient = vc;
    }

    private int getBorderDistance(BlockPos pos) {
        int dist = Integer.MAX_VALUE;
        dist = Math.min(dist, Math.abs(pos.getX() - this.villageClient.getMaxX()));
        dist = Math.min(dist, Math.abs(pos.getX() - this.villageClient.getMinX()));
        dist = Math.min(dist, Math.abs(pos.getZ() - this.villageClient.getMaxZ()));
        dist = Math.min(dist, Math.abs(pos.getZ() - this.villageClient.getMinZ()));
        return dist;
    }

    public void renderBorder(Entity entityIn, float partialTicks) {
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bufferbuilder = tessellator.getBuffer();
        double RENDER_DISTANCE = 8.0;
        double RENDER_Y_DELTA = 2.0;
        double RENDER_WALL_WIDTH = 10.0;
        int borderDistance = this.getBorderDistance(entityIn.getPosition());
        if ((double)borderDistance < 8.0) {
            double colorAlpha = 1.0 - (double)borderDistance / 8.0;
            colorAlpha = Math.pow(colorAlpha, 2.0);
            double entityX = entityIn.lastTickPosX + (entityIn.posX - entityIn.lastTickPosX) * (double)partialTicks;
            double entityY = entityIn.lastTickPosY + (entityIn.posY - entityIn.lastTickPosY) * (double)partialTicks;
            double entityZ = entityIn.lastTickPosZ + (entityIn.posZ - entityIn.lastTickPosZ) * (double)partialTicks;
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
            Minecraft.getMinecraft().getTextureManager().bindTexture(FORCEFIELD_TEXTURES);
            GlStateManager.depthMask((boolean)false);
            GlStateManager.pushMatrix();
            int color = 2138367;
            float colorR = (float)(color >> 16 & 0xFF) / 255.0f;
            float colorG = (float)(color >> 8 & 0xFF) / 255.0f;
            float colorB = (float)(color & 0xFF) / 255.0f;
            GlStateManager.color((float)colorR, (float)colorG, (float)colorB, (float)((float)colorAlpha));
            GlStateManager.doPolygonOffset((float)-3.0f, (float)-3.0f);
            GlStateManager.enablePolygonOffset();
            GlStateManager.alphaFunc((int)516, (float)0.1f);
            GlStateManager.enableAlpha();
            GlStateManager.disableCull();
            float f3 = (float)(Minecraft.getSystemTime() % 3000L) / 3000.0f;
            float f4 = 0.0f;
            float f5 = 0.0f;
            float f6 = 128.0f;
            bufferbuilder.begin(7, DefaultVertexFormats.POSITION_TEX);
            bufferbuilder.setTranslation(-entityX, -entityY, -entityZ);
            double d8 = Math.max((double)MathHelper.floor((double)(entityZ - 10.0)), (double)this.villageClient.getMinZ());
            double d9 = Math.min((double)MathHelper.ceil((double)(entityZ + 10.0)), (double)this.villageClient.getMaxZ());
            if (Math.abs(entityX - (double)this.villageClient.getMaxX()) < 8.0) {
                float f7 = 0.0f;
                double d10 = d8;
                while (d10 < d9) {
                    double d11 = Math.min(1.0, d9 - d10);
                    float f8 = (float)d11 * 0.5f;
                    bufferbuilder.pos((double)this.villageClient.getMaxX(), entityY + 2.0, d10).tex((double)(f3 + f7), (double)(f3 + 0.0f)).endVertex();
                    bufferbuilder.pos((double)this.villageClient.getMaxX(), entityY + 2.0, d10 + d11).tex((double)(f3 + f8 + f7), (double)(f3 + 0.0f)).endVertex();
                    bufferbuilder.pos((double)this.villageClient.getMaxX(), entityY - 2.0, d10 + d11).tex((double)(f3 + f8 + f7), (double)(f3 + 128.0f)).endVertex();
                    bufferbuilder.pos((double)this.villageClient.getMaxX(), entityY - 2.0, d10).tex((double)(f3 + f7), (double)(f3 + 128.0f)).endVertex();
                    d10 += 1.0;
                    f7 += 0.5f;
                }
            }
            if (Math.abs(entityX - (double)this.villageClient.getMinX()) < 8.0) {
                float f9 = 0.0f;
                double d12 = d8;
                while (d12 < d9) {
                    double d15 = Math.min(1.0, d9 - d12);
                    float f12 = (float)d15 * 0.5f;
                    bufferbuilder.pos((double)this.villageClient.getMinX(), entityY + 2.0, d12).tex((double)(f3 + f9), (double)(f3 + 0.0f)).endVertex();
                    bufferbuilder.pos((double)this.villageClient.getMinX(), entityY + 2.0, d12 + d15).tex((double)(f3 + f12 + f9), (double)(f3 + 0.0f)).endVertex();
                    bufferbuilder.pos((double)this.villageClient.getMinX(), entityY - 2.0, d12 + d15).tex((double)(f3 + f12 + f9), (double)(f3 + 128.0f)).endVertex();
                    bufferbuilder.pos((double)this.villageClient.getMinX(), entityY - 2.0, d12).tex((double)(f3 + f9), (double)(f3 + 128.0f)).endVertex();
                    d12 += 1.0;
                    f9 += 0.5f;
                }
            }
            d8 = Math.max((double)MathHelper.floor((double)(entityX - 10.0)), (double)this.villageClient.getMinX());
            d9 = Math.min((double)MathHelper.ceil((double)(entityX + 10.0)), (double)this.villageClient.getMaxX());
            if (Math.abs(entityZ - (double)this.villageClient.getMaxZ()) < 8.0) {
                float f10 = 0.0f;
                double d13 = d8;
                while (d13 < d9) {
                    double d16 = Math.min(1.0, d9 - d13);
                    float f13 = (float)d16 * 0.5f;
                    bufferbuilder.pos(d13, entityY + 2.0, (double)this.villageClient.getMaxZ()).tex((double)(f3 + f10), (double)(f3 + 0.0f)).endVertex();
                    bufferbuilder.pos(d13 + d16, entityY + 2.0, (double)this.villageClient.getMaxZ()).tex((double)(f3 + f13 + f10), (double)(f3 + 0.0f)).endVertex();
                    bufferbuilder.pos(d13 + d16, entityY - 2.0, (double)this.villageClient.getMaxZ()).tex((double)(f3 + f13 + f10), (double)(f3 + 128.0f)).endVertex();
                    bufferbuilder.pos(d13, entityY - 2.0, (double)this.villageClient.getMaxZ()).tex((double)(f3 + f10), (double)(f3 + 128.0f)).endVertex();
                    d13 += 1.0;
                    f10 += 0.5f;
                }
            }
            if (Math.abs(entityZ - (double)this.villageClient.getMinZ()) < 8.0) {
                float f11 = 0.0f;
                double d14 = d8;
                while (d14 < d9) {
                    double d17 = Math.min(1.0, d9 - d14);
                    float f14 = (float)d17 * 0.5f;
                    bufferbuilder.pos(d14, entityY + 2.0, (double)this.villageClient.getMinZ()).tex((double)(f3 + f11), (double)(f3 + 0.0f)).endVertex();
                    bufferbuilder.pos(d14 + d17, entityY + 2.0, (double)this.villageClient.getMinZ()).tex((double)(f3 + f14 + f11), (double)(f3 + 0.0f)).endVertex();
                    bufferbuilder.pos(d14 + d17, entityY - 2.0, (double)this.villageClient.getMinZ()).tex((double)(f3 + f14 + f11), (double)(f3 + 128.0f)).endVertex();
                    bufferbuilder.pos(d14, entityY - 2.0, (double)this.villageClient.getMinZ()).tex((double)(f3 + f11), (double)(f3 + 128.0f)).endVertex();
                    d14 += 1.0;
                    f11 += 0.5f;
                }
            }
            tessellator.draw();
            bufferbuilder.setTranslation(0.0, 0.0, 0.0);
            GlStateManager.enableCull();
            GlStateManager.disableAlpha();
            GlStateManager.doPolygonOffset((float)0.0f, (float)0.0f);
            GlStateManager.disablePolygonOffset();
            GlStateManager.enableAlpha();
            GlStateManager.disableBlend();
            GlStateManager.popMatrix();
            GlStateManager.depthMask((boolean)true);
        }
    }
}

