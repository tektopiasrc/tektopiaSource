/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.leviathanstudio.craftstudio.client.model.ModelCraftStudio
 *  net.minecraft.client.model.ModelBiped
 *  net.minecraft.client.model.ModelRenderer
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.item.EntityArmorStand
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 */
package net.tangotek.tektopia.client;

import com.leviathanstudio.craftstudio.client.model.ModelCraftStudio;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(value=Side.CLIENT)
public class ModelRancherHat
extends ModelBiped {
    private final ModelCraftStudio modelHat = new ModelCraftStudio("tektopia", "rancher_hat", 64, 64);

    public ModelRancherHat() {
        super(0.0f, 0.0f, 64, 64);
    }

    public void render(Entity entityIn, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scale) {
        GlStateManager.pushMatrix();
        float rotateAngleY = netHeadYaw * ((float)Math.PI / 180);
        float rotateAngleX = headPitch * ((float)Math.PI / 180);
        if (entityIn.isSneaking()) {
            GlStateManager.translate((float)0.0f, (float)0.25f, (float)0.0f);
        }
        GlStateManager.rotate((float)(rotateAngleY * 57.295776f), (float)0.0f, (float)1.0f, (float)0.0f);
        GlStateManager.rotate((float)(rotateAngleX * 57.295776f), (float)1.0f, (float)0.0f, (float)0.0f);
        this.modelHat.render();
        GlStateManager.popMatrix();
    }

    public void setRotationAngles(float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scaleFactor, Entity entityIn) {
        if (entityIn instanceof EntityArmorStand) {
            this.bipedHead.rotateAngleX = headPitch * ((float)Math.PI / 180);
            this.bipedHead.rotateAngleY = netHeadYaw * ((float)Math.PI / 180);
            this.bipedHead.setRotationPoint(0.0f, 1.0f, 0.0f);
            ModelRancherHat.copyModelAngles((ModelRenderer)this.bipedHead, (ModelRenderer)this.bipedHeadwear);
        }
    }
}

