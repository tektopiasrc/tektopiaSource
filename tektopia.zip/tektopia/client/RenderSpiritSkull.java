/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.model.ModelSkeletonHead
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.entity.Render
 *  net.minecraft.client.renderer.entity.RenderManager
 *  net.minecraft.entity.Entity
 *  net.minecraft.util.ResourceLocation
 *  net.minecraftforge.fml.client.registry.IRenderFactory
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 */
package net.tangotek.tektopia.client;

import net.minecraft.client.model.ModelSkeletonHead;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.client.registry.IRenderFactory;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.tangotek.tektopia.entities.EntitySpiritSkull;

@SideOnly(value=Side.CLIENT)
public class RenderSpiritSkull
extends Render<EntitySpiritSkull> {
    private static final ResourceLocation SKULL_TEXTURE = new ResourceLocation("tektopia", "textures/entity/spirit_skull.png");
    public static final Factory FACTORY = new Factory();
    private final ModelSkeletonHead skeletonHeadModel = new ModelSkeletonHead();

    public RenderSpiritSkull(RenderManager renderManagerIn) {
        super(renderManagerIn);
    }

    private float getRenderYaw(float p_82400_1_, float p_82400_2_, float p_82400_3_) {
        float f;
        for (f = p_82400_2_ - p_82400_1_; f < -180.0f; f += 360.0f) {
        }
        while (f >= 180.0f) {
            f -= 360.0f;
        }
        return p_82400_1_ + p_82400_3_ * f;
    }

    public void doRender(EntitySpiritSkull entity, double x, double y, double z, float entityYaw, float partialTicks) {
        if (entity.isInvisible()) {
            return;
        }
        GlStateManager.pushMatrix();
        GlStateManager.disableCull();
        float f = this.getRenderYaw(entity.prevRotationYaw, entity.rotationYaw, partialTicks);
        float f1 = entity.prevRotationPitch + (entity.rotationPitch - entity.prevRotationPitch) * partialTicks;
        GlStateManager.translate((float)((float)x), (float)((float)y), (float)((float)z));
        if (entity.getSkullMode() == EntitySpiritSkull.SkullMode.PROTECTING) {
            float radius = entity.getSpinRadius();
            float speed = entity.getSpinSpeed();
            float xAxis = entity.getSpinAxis();
            GlStateManager.rotate((float)(((float)entity.ticksExisted + partialTicks) * speed), (float)xAxis, (float)1.0f, (float)0.0f);
            GlStateManager.translate((float)0.0f, (float)0.0f, (float)radius);
        }
        float f2 = 0.0625f;
        GlStateManager.enableRescaleNormal();
        float scale = 0.6f;
        GlStateManager.scale((float)(-scale), (float)(-scale), (float)scale);
        GlStateManager.enableAlpha();
        this.bindEntityTexture(entity);
        if (this.renderOutlines) {
            GlStateManager.enableColorMaterial();
            GlStateManager.enableOutlineMode((int)this.getTeamColor(entity));
        }
        this.skeletonHeadModel.render((Entity)entity, 0.0f, 0.0f, 0.0f, f, f1, 0.0625f);
        if (this.renderOutlines) {
            GlStateManager.disableOutlineMode();
            GlStateManager.disableColorMaterial();
        }
        GlStateManager.popMatrix();
        super.doRender(entity, x, y, z, entityYaw, partialTicks);
    }

    protected ResourceLocation getEntityTexture(EntitySpiritSkull entity) {
        return SKULL_TEXTURE;
    }

    public static class Factory<T extends EntitySpiritSkull>
    implements IRenderFactory<T> {
        public Render<? super T> createRenderFor(RenderManager manager) {
            return new RenderSpiritSkull(manager);
        }
    }
}

