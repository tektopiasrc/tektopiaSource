/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.particle.Particle
 *  net.minecraft.client.renderer.BufferBuilder
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.entity.Entity
 *  net.minecraft.item.Item
 *  net.minecraft.world.World
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 */
package net.tangotek.tektopia.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.item.Item;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(value=Side.CLIENT)
public class ParticleItemThought
extends Particle {
    private final int lifeTime;
    private final Entity ent;

    public ParticleItemThought(World worldIn, Entity ent, Item item) {
        super(worldIn, ent.posX, ent.getEntityBoundingBox().maxY + 0.8, ent.posZ, 0.0, 0.0, 0.0);
        this.setParticleTexture(Minecraft.getMinecraft().getRenderItem().getItemModelMesher().getParticleIcon(item));
        this.ent = ent;
        this.lifeTime = 40;
        this.particleRed = 1.0f;
        this.particleGreen = 1.0f;
        this.particleBlue = 1.0f;
        this.motionX = 0.0;
        this.motionY = 0.013;
        this.motionZ = 0.0;
        this.particleGravity = 0.0f;
        this.particleMaxAge = 40;
        this.particleScale = 0.2f;
        this.multipleParticleScaleBy(0.15f);
        this.canCollide = false;
    }

    public int getFXLayer() {
        return 1;
    }

    public void onUpdate() {
        this.particleAlpha -= 0.02f;
        super.onUpdate();
        this.prevPosX = this.posX;
        this.prevPosY = this.posY;
        this.prevPosZ = this.posZ;
        this.move(this.ent.posX - this.prevPosX, this.motionY, this.ent.posZ - this.prevPosZ);
    }

    public void renderParticle(BufferBuilder buffer, Entity entityIn, float partialTicks, float rotationX, float rotationZ, float rotationYZ, float rotationXY, float rotationXZ) {
        GlStateManager.pushMatrix();
        float f = this.particleTexture.getMinU();
        float f1 = this.particleTexture.getMaxU();
        float f2 = this.particleTexture.getMinV();
        float f3 = this.particleTexture.getMaxV();
        float f4 = 0.5f;
        float f5 = (float)(this.prevPosX + (this.posX - this.prevPosX) * (double)partialTicks - interpPosX);
        float f6 = (float)(this.prevPosY + (this.posY - this.prevPosY) * (double)partialTicks - interpPosY);
        float f7 = (float)(this.prevPosZ + (this.posZ - this.prevPosZ) * (double)partialTicks - interpPosZ);
        int i = this.getBrightnessForRender(partialTicks);
        int j = i >> 16 & 0xFFFF;
        int k = i & 0xFFFF;
        float scale = 0.3f;
        buffer.pos((double)(f5 - rotationX * scale - rotationXY * scale), (double)(f6 - rotationZ * scale), (double)(f7 - rotationYZ * scale - rotationXZ * scale)).tex((double)f1, (double)f3).color(this.particleRed, this.particleGreen, this.particleBlue, 1.0f).lightmap(j, k).endVertex();
        buffer.pos((double)(f5 - rotationX * scale + rotationXY * scale), (double)(f6 + rotationZ * scale), (double)(f7 - rotationYZ * scale + rotationXZ * scale)).tex((double)f1, (double)f2).color(this.particleRed, this.particleGreen, this.particleBlue, 1.0f).lightmap(j, k).endVertex();
        buffer.pos((double)(f5 + rotationX * scale + rotationXY * scale), (double)(f6 + rotationZ * scale), (double)(f7 + rotationYZ * scale + rotationXZ * scale)).tex((double)f, (double)f2).color(this.particleRed, this.particleGreen, this.particleBlue, 1.0f).lightmap(j, k).endVertex();
        buffer.pos((double)(f5 + rotationX * scale - rotationXY * scale), (double)(f6 - rotationZ * scale), (double)(f7 + rotationYZ * scale - rotationXZ * scale)).tex((double)f, (double)f3).color(this.particleRed, this.particleGreen, this.particleBlue, 1.0f).lightmap(j, k).endVertex();
        GlStateManager.popMatrix();
    }
}

