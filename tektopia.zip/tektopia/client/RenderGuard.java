/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.leviathanstudio.craftstudio.client.model.CSModelRenderer
 *  com.leviathanstudio.craftstudio.client.model.ModelCraftStudio
 *  net.minecraft.client.model.ModelRenderer
 *  net.minecraft.client.renderer.entity.Render
 *  net.minecraft.client.renderer.entity.RenderManager
 *  net.minecraft.inventory.EntityEquipmentSlot
 *  net.minecraft.item.ItemArmor
 *  net.minecraft.item.ItemStack
 *  net.minecraftforge.fml.client.registry.IRenderFactory
 */
package net.tangotek.tektopia.client;

import com.leviathanstudio.craftstudio.client.model.CSModelRenderer;
import com.leviathanstudio.craftstudio.client.model.ModelCraftStudio;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.client.registry.IRenderFactory;
import net.tangotek.tektopia.client.RenderVillager;
import net.tangotek.tektopia.entities.EntityGuard;

public class RenderGuard<T extends EntityGuard>
extends RenderVillager<T> {
    public static final Factory FACTORY = new Factory();

    public RenderGuard(RenderManager manager) {
        super(manager, "guard", false, 128, 64, "guard");
    }

    private void updateArmorSlot(CSModelRenderer modelRenderer, EntityGuard entityGuard, String modelPrefix, EntityEquipmentSlot slot) {
        ItemArmor itemArmor;
        ItemStack itemStack;
        if (modelRenderer.boxName.startsWith(modelPrefix) && (itemStack = entityGuard.getItemStackFromSlot(slot)).getItem() instanceof ItemArmor && (itemArmor = (ItemArmor)itemStack.getItem()).getEquipmentSlot() == slot) {
            String matName = itemArmor.getArmorMaterial().getName();
            String modelMat = modelRenderer.boxName.substring(modelPrefix.length());
            modelRenderer.showModel = modelMat.toLowerCase().startsWith(matName);
            if (modelRenderer.showModel && modelRenderer.boxName.substring(modelPrefix.length() + matName.length()).startsWith("Capt")) {
                modelRenderer.showModel = entityGuard.isCaptain();
            }
        }
    }

    private void updateArmor(CSModelRenderer modelRenderer, EntityGuard entityGuard) {
        boolean bl = modelRenderer.showModel = !modelRenderer.boxName.startsWith("Armor");
        if (!entityGuard.isSleeping()) {
            this.updateArmorSlot(modelRenderer, entityGuard, "ArmorChest", EntityEquipmentSlot.CHEST);
            if (!modelRenderer.showModel) {
                this.updateArmorSlot(modelRenderer, entityGuard, "ArmorLeg", EntityEquipmentSlot.LEGS);
            }
            if (!modelRenderer.showModel) {
                this.updateArmorSlot(modelRenderer, entityGuard, "ArmorHead", EntityEquipmentSlot.HEAD);
            }
            if (!modelRenderer.showModel) {
                this.updateArmorSlot(modelRenderer, entityGuard, "ArmorFeet", EntityEquipmentSlot.FEET);
            }
        }
        if (modelRenderer.childModels != null) {
            for (ModelRenderer child : modelRenderer.childModels) {
                this.updateArmor((CSModelRenderer)child, entityGuard);
            }
        }
    }

    protected void preRenderCallback(EntityGuard entityGuard, float partialTickTime) {
        ModelCraftStudio model = (ModelCraftStudio)this.getMainModel();
        for (CSModelRenderer parent : model.getParentBlocks()) {
            this.updateArmor(parent, entityGuard);
        }
    }

    public static class Factory<T extends EntityGuard>
    implements IRenderFactory<T> {
        public Render<? super T> createRenderFor(RenderManager manager) {
            return new RenderGuard(manager);
        }
    }
}

