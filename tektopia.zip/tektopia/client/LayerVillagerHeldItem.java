/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.leviathanstudio.craftstudio.client.model.CSModelRenderer
 *  com.leviathanstudio.craftstudio.client.model.ModelCraftStudio
 *  com.leviathanstudio.craftstudio.client.util.MathHelper
 *  javax.vecmath.Matrix4f
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.model.ModelBook
 *  net.minecraft.client.model.ModelRenderer
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.block.model.ItemCameraTransforms$TransformType
 *  net.minecraft.client.renderer.entity.RenderLivingBase
 *  net.minecraft.client.renderer.entity.layers.LayerRenderer
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.init.Items
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.EnumHandSide
 *  net.minecraft.util.ResourceLocation
 *  net.minecraft.util.math.MathHelper
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 */
package net.tangotek.tektopia.client;

import com.leviathanstudio.craftstudio.client.model.CSModelRenderer;
import com.leviathanstudio.craftstudio.client.model.ModelCraftStudio;
import java.nio.FloatBuffer;
import java.util.ArrayDeque;
import java.util.Deque;
import javax.vecmath.Matrix4f;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBook;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.client.renderer.entity.RenderLivingBase;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHandSide;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.tangotek.tektopia.ModItems;
import net.tangotek.tektopia.entities.EntityVillagerTek;

@SideOnly(value=Side.CLIENT)
public class LayerVillagerHeldItem
implements LayerRenderer<EntityLivingBase> {
    protected final RenderLivingBase<?> livingEntityRenderer;
    private static final ResourceLocation TEXTURE_BOOK = new ResourceLocation("textures/entity/enchanting_table_book.png");
    private final ModelBook modelBook = new ModelBook();

    public LayerVillagerHeldItem(RenderLivingBase<?> livingEntityRendererIn) {
        this.livingEntityRenderer = livingEntityRendererIn;
    }

    public void doRenderLayer(EntityLivingBase entitylivingbaseIn, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch, float scale) {
        boolean flag = entitylivingbaseIn.getPrimaryHand() == EnumHandSide.RIGHT;
        ItemStack leftHandItem = flag ? entitylivingbaseIn.getHeldItemOffhand() : entitylivingbaseIn.getHeldItemMainhand();
        ItemStack rightHandItem = flag ? entitylivingbaseIn.getHeldItemMainhand() : entitylivingbaseIn.getHeldItemOffhand();
        boolean showLayer = true;
        if (entitylivingbaseIn instanceof EntityVillagerTek) {
            EntityVillagerTek villager = (EntityVillagerTek)entitylivingbaseIn;
            boolean bl = showLayer = !villager.isSleeping();
            if (!villager.getActionItem().isEmpty() && (rightHandItem = villager.getActionItem()).getItem() == ModItems.EMPTY_HAND_ITEM.getItem()) {
                rightHandItem = ItemStack.EMPTY;
            }
        }
        if (!(!showLayer || leftHandItem.isEmpty() && rightHandItem.isEmpty())) {
            GlStateManager.pushMatrix();
            if (this.livingEntityRenderer.getMainModel().isChild) {
                float f = 0.5f;
                GlStateManager.translate((float)0.0f, (float)0.75f, (float)0.0f);
                GlStateManager.scale((float)0.5f, (float)0.5f, (float)0.5f);
            }
            this.renderHeldItem(entitylivingbaseIn, rightHandItem, ItemCameraTransforms.TransformType.THIRD_PERSON_RIGHT_HAND, EnumHandSide.RIGHT, ageInTicks, scale);
            this.renderHeldItem(entitylivingbaseIn, leftHandItem, ItemCameraTransforms.TransformType.THIRD_PERSON_LEFT_HAND, EnumHandSide.LEFT, ageInTicks, scale);
            GlStateManager.popMatrix();
        }
    }

    private void renderHeldItem(EntityLivingBase entity, ItemStack itemStack, ItemCameraTransforms.TransformType transformType, EnumHandSide handSide, float ageInTicks, float scale) {
        if (!itemStack.isEmpty()) {
            boolean flag;
            GlStateManager.pushMatrix();
            if (entity.isSneaking()) {
                GlStateManager.translate((float)0.0f, (float)0.2f, (float)0.0f);
            }
            this.translateToHand(handSide, scale);
            GlStateManager.rotate((float)-90.0f, (float)1.0f, (float)0.0f, (float)0.0f);
            GlStateManager.rotate((float)180.0f, (float)0.0f, (float)1.0f, (float)0.0f);
            boolean bl = flag = handSide == EnumHandSide.LEFT;
            if (itemStack.getItem() == Items.BOOK) {
                this.renderBook(ageInTicks);
            } else {
                Minecraft.getMinecraft().getItemRenderer().renderItemSide(entity, itemStack, transformType, flag);
            }
            GlStateManager.popMatrix();
        }
    }

    protected void translateToHand(EnumHandSide handSide, float scale) {
        ModelCraftStudio model = (ModelCraftStudio)this.livingEntityRenderer.getMainModel();
        ArrayDeque<CSModelRenderer> stack = new ArrayDeque<CSModelRenderer>();
        for (CSModelRenderer parent : model.getParentBlocks()) {
            if (!this.findChildChain("ArmRightWrist", parent, stack)) continue;
            stack.push(parent);
            while (!stack.isEmpty()) {
                CSModelRenderer modelRenderer = (CSModelRenderer)stack.pop();
                GlStateManager.translate((float)(modelRenderer.rotationPointX * scale), (float)(modelRenderer.rotationPointY * scale), (float)(modelRenderer.rotationPointZ * scale));
                FloatBuffer buf = com.leviathanstudio.craftstudio.client.util.MathHelper.makeFloatBuffer((Matrix4f)modelRenderer.getRotationMatrix());
                GlStateManager.multMatrix((FloatBuffer)buf);
                GlStateManager.translate((float)(modelRenderer.offsetX * scale), (float)(modelRenderer.offsetY * scale), (float)(modelRenderer.offsetZ * scale));
            }
        }
    }

    private boolean findChildChain(String name, CSModelRenderer modelRenderer, Deque<CSModelRenderer> stack) {
        if (modelRenderer.boxName.equals(name)) {
            return true;
        }
        if (modelRenderer.childModels != null) {
            for (ModelRenderer child : modelRenderer.childModels) {
                CSModelRenderer csModel = (CSModelRenderer)child;
                if (!this.findChildChain(name, csModel, stack)) continue;
                stack.push(csModel);
                return true;
            }
        }
        return false;
    }

    protected void renderBook(float ageInTicks) {
        GlStateManager.pushMatrix();
        float f = 25.5f;
        GlStateManager.rotate((float)90.0f, (float)0.0f, (float)0.0f, (float)1.0f);
        float rot = 80.0f;
        GlStateManager.rotate((float)rot, (float)1.0f, (float)0.0f, (float)0.0f);
        GlStateManager.rotate((float)40.0f, (float)0.0f, (float)0.0f, (float)1.0f);
        GlStateManager.translate((double)0.0, (double)-0.2, (double)-0.3);
        this.livingEntityRenderer.bindTexture(TEXTURE_BOOK);
        float f3 = f + 0.25f;
        float f4 = f + 0.75f;
        f3 = (f3 - (float)MathHelper.fastFloor((double)f3)) * 1.6f - 0.3f;
        f4 = (f4 - (float)MathHelper.fastFloor((double)f4)) * 1.6f - 0.3f;
        if (f3 < 0.0f) {
            f3 = 0.0f;
        }
        if (f4 < 0.0f) {
            f4 = 0.0f;
        }
        if (f3 > 1.0f) {
            f3 = 1.0f;
        }
        if (f4 > 1.0f) {
            f4 = 1.0f;
        }
        float f5 = 12.2f;
        GlStateManager.enableCull();
        this.modelBook.render((Entity)null, 1500.0f, 0.17f, 0.9f, 1.0f, 0.0f, 0.0625f);
        GlStateManager.popMatrix();
    }

    public boolean shouldCombineTextures() {
        return false;
    }
}

