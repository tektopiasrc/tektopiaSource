/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.command.CommandException
 *  net.minecraft.command.ICommandSender
 *  net.minecraft.command.WrongUsageException
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.EntityPlayerMP
 *  net.minecraft.server.MinecraftServer
 *  net.minecraft.util.math.BlockPos
 */
package net.tangotek.tektopia.commands;

import java.util.List;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.command.WrongUsageException;
import net.minecraft.entity.Entity;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.math.BlockPos;
import net.tangotek.tektopia.Village;
import net.tangotek.tektopia.VillageManager;
import net.tangotek.tektopia.commands.CommandVillageBase;
import net.tangotek.tektopia.entities.EntityBard;
import net.tangotek.tektopia.entities.EntityBlacksmith;
import net.tangotek.tektopia.entities.EntityButcher;
import net.tangotek.tektopia.entities.EntityChef;
import net.tangotek.tektopia.entities.EntityChild;
import net.tangotek.tektopia.entities.EntityCleric;
import net.tangotek.tektopia.entities.EntityDruid;
import net.tangotek.tektopia.entities.EntityEnchanter;
import net.tangotek.tektopia.entities.EntityFarmer;
import net.tangotek.tektopia.entities.EntityGuard;
import net.tangotek.tektopia.entities.EntityLumberjack;
import net.tangotek.tektopia.entities.EntityMiner;
import net.tangotek.tektopia.entities.EntityRancher;
import net.tangotek.tektopia.entities.EntityTeacher;
import net.tangotek.tektopia.entities.EntityVillagerTek;
import net.tangotek.tektopia.structures.VillageStructure;
import net.tangotek.tektopia.structures.VillageStructureRancherPen;
import net.tangotek.tektopia.structures.VillageStructureType;

class CommandPopulate
extends CommandVillageBase {
    public CommandPopulate() {
        super("populate");
    }

    public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        if (args.length > 1) {
            throw new WrongUsageException("commands.village.populate.usage", new Object[0]);
        }
        EntityPlayerMP entityPlayer = CommandPopulate.getCommandSenderAsPlayer((ICommandSender)sender);
        VillageManager vm = VillageManager.get(entityPlayer.world);
        Village village = vm.getVillageAt(entityPlayer.getPosition());
        if (village != null) {
            int skill = 1;
            if (args.length == 1) {
                skill = Math.min(Integer.valueOf(args[0]), 100);
            }
            this.populateVillagers(village, skill);
            this.populateAnimals(village);
        }
    }

    private void populateAnimals(Village village) {
        this.populateAnimalPen(village, VillageStructureType.COW_PEN);
        this.populateAnimalPen(village, VillageStructureType.PIG_PEN);
        this.populateAnimalPen(village, VillageStructureType.CHICKEN_COOP);
        this.populateAnimalPen(village, VillageStructureType.SHEEP_PEN);
    }

    private void populateAnimalPen(Village v, VillageStructureType penType) {
        List<VillageStructure> pens = v.getStructures(penType);
        for (VillageStructure pen : pens) {
            if (!(pen instanceof VillageStructureRancherPen)) continue;
            VillageStructureRancherPen rancherPen = (VillageStructureRancherPen)pen;
            List<EntityAnimal> animals = rancherPen.getEntitiesInside(rancherPen.getAnimalClass());
            animals.stream().forEach(a -> a.setDead());
            for (int i = 0; i < 12; ++i) {
                rancherPen.spawnAnimal(rancherPen.getDoorInside());
            }
        }
    }

    private void populateVillagers(Village village, int skill) {
        List<EntityVillagerTek> villagers = village.getWorld().getEntitiesWithinAABB(EntityVillagerTek.class, village.getAABB().grow(100.0, 100.0, 100.0));
        for (EntityVillagerTek villager : villagers) {
            villager.setDead();
        }
        List<VillageStructure> structs = village.getStructures(VillageStructureType.TOWNHALL);
        if (!structs.isEmpty()) {
            this.spawnVillager(village, skill, new EntityFarmer(village.getWorld()), structs.get(0).getRandomFloorTile());
            this.spawnVillager(village, skill, new EntityFarmer(village.getWorld()), structs.get(0).getRandomFloorTile());
            this.spawnVillager(village, skill, new EntityFarmer(village.getWorld()), structs.get(0).getRandomFloorTile());
            this.spawnVillager(village, skill, new EntityFarmer(village.getWorld()), structs.get(0).getRandomFloorTile());
            this.spawnVillager(village, skill, new EntityFarmer(village.getWorld()), structs.get(0).getRandomFloorTile());
            this.spawnVillager(village, skill, new EntityFarmer(village.getWorld()), structs.get(0).getRandomFloorTile());
            this.spawnVillager(village, skill, new EntityRancher(village.getWorld()), structs.get(0).getRandomFloorTile());
            this.spawnVillager(village, skill, new EntityRancher(village.getWorld()), structs.get(0).getRandomFloorTile());
            this.spawnVillager(village, skill, new EntityRancher(village.getWorld()), structs.get(0).getRandomFloorTile());
            this.spawnVillager(village, skill, new EntityButcher(village.getWorld()), structs.get(0).getRandomFloorTile());
            this.spawnVillager(village, skill, new EntityBlacksmith(village.getWorld()), structs.get(0).getRandomFloorTile());
            this.spawnVillager(village, skill, new EntityMiner(village.getWorld()), structs.get(0).getRandomFloorTile());
            this.spawnVillager(village, skill, new EntityMiner(village.getWorld()), structs.get(0).getRandomFloorTile());
            this.spawnVillager(village, skill, new EntityMiner(village.getWorld()), structs.get(0).getRandomFloorTile());
            this.spawnVillager(village, skill, new EntityTeacher(village.getWorld()), structs.get(0).getRandomFloorTile());
            this.spawnVillager(village, skill, new EntityChild(village.getWorld()), structs.get(0).getRandomFloorTile());
            this.spawnVillager(village, skill, new EntityChild(village.getWorld()), structs.get(0).getRandomFloorTile());
            this.spawnVillager(village, skill, new EntityChild(village.getWorld()), structs.get(0).getRandomFloorTile());
            this.spawnVillager(village, skill, new EntityGuard(village.getWorld()), structs.get(0).getRandomFloorTile());
            this.spawnVillager(village, skill, new EntityGuard(village.getWorld()), structs.get(0).getRandomFloorTile());
            this.spawnVillager(village, skill, new EntityGuard(village.getWorld()), structs.get(0).getRandomFloorTile());
            this.spawnVillager(village, skill, new EntityGuard(village.getWorld()), structs.get(0).getRandomFloorTile());
            this.spawnVillager(village, skill, new EntityGuard(village.getWorld()), structs.get(0).getRandomFloorTile());
            this.spawnVillager(village, skill, new EntityBard(village.getWorld()), structs.get(0).getRandomFloorTile());
            this.spawnVillager(village, skill, new EntityChef(village.getWorld()), structs.get(0).getRandomFloorTile());
            this.spawnVillager(village, skill, new EntityEnchanter(village.getWorld()), structs.get(0).getRandomFloorTile());
            this.spawnVillager(village, skill, new EntityDruid(village.getWorld()), structs.get(0).getRandomFloorTile());
            this.spawnVillager(village, skill, new EntityCleric(village.getWorld()), structs.get(0).getRandomFloorTile());
            this.spawnVillager(village, skill, new EntityLumberjack(village.getWorld()), structs.get(0).getRandomFloorTile());
        }
    }

    private void spawnVillager(Village v, int skill, EntityVillagerTek villager, BlockPos spawnPos) {
        villager.setLocationAndAngles((double)spawnPos.getX() + 0.5, spawnPos.getY(), (double)spawnPos.getZ() + 0.5, 0.0f, 0.0f);
        villager.onInitialSpawn(v.getWorld().getDifficultyForLocation(spawnPos), null);
        if (villager.getProfessionType().canCopy) {
            villager.setSkill(villager.getProfessionType(), skill + (int)(villager.getRNG().nextGaussian() * 30.0));
        }
        villager.setIntelligence(skill);
        v.getWorld().spawnEntity((Entity)villager);
    }
}

