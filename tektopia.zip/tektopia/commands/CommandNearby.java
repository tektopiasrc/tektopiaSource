/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.command.CommandException
 *  net.minecraft.command.ICommand
 *  net.minecraft.command.ICommandSender
 *  net.minecraft.command.WrongUsageException
 *  net.minecraft.entity.player.EntityPlayerMP
 *  net.minecraft.server.MinecraftServer
 *  net.minecraft.util.math.BlockPos
 */
package net.tangotek.tektopia.commands;

import java.util.List;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommand;
import net.minecraft.command.ICommandSender;
import net.minecraft.command.WrongUsageException;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.math.BlockPos;
import net.tangotek.tektopia.Village;
import net.tangotek.tektopia.VillageManager;
import net.tangotek.tektopia.commands.CommandVillageBase;

class CommandNearby
extends CommandVillageBase {
    public CommandNearby() {
        super("nearby");
    }

    public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        if (args.length > 0) {
            throw new WrongUsageException("commands.village.nearby.usage", new Object[0]);
        }
        EntityPlayerMP entityplayer = CommandNearby.getCommandSenderAsPlayer((ICommandSender)sender);
        Integer range = 360;
        List<Village> villages = VillageManager.get(entityplayer.world).getVillagesNear(entityplayer.getPosition(), range);
        if (villages.isEmpty()) {
            CommandNearby.notifyCommandListener((ICommandSender)sender, (ICommand)this, (String)"commands.nearby.none", (Object[])new Object[]{range});
        } else {
            BlockPos p = entityplayer.getPosition();
            villages.stream().forEach(v -> CommandNearby.notifyCommandListener((ICommandSender)sender, (ICommand)this, (String)"commands.nearby.set", (Object[])new Object[]{range, v.getOrigin(), v.getOrigin().getDistance(p.getX(), p.getY(), p.getZ())}));
        }
    }
}

