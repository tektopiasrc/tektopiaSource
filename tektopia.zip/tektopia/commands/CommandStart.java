/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.command.CommandException
 *  net.minecraft.command.ICommandSender
 *  net.minecraft.command.WrongUsageException
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.entity.player.EntityPlayerMP
 *  net.minecraft.init.SoundEvents
 *  net.minecraft.server.MinecraftServer
 *  net.minecraft.util.SoundCategory
 */
package net.tangotek.tektopia.commands;

import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.command.WrongUsageException;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.SoundEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.SoundCategory;
import net.tangotek.tektopia.commands.CommandVillageBase;
import net.tangotek.tektopia.structures.VillageStructureType;

class CommandStart
extends CommandVillageBase {
    public CommandStart() {
        super("start");
    }

    public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        if (args.length > 0) {
            throw new WrongUsageException("commands.village.start.usage", new Object[0]);
        }
        EntityPlayerMP entityplayer = CommandStart.getCommandSenderAsPlayer((ICommandSender)sender);
        boolean flag = entityplayer.inventory.addItemStackToInventory(VillageStructureType.TOWNHALL.itemStack.copy());
        if (flag |= entityplayer.inventory.addItemStackToInventory(VillageStructureType.STORAGE.itemStack.copy())) {
            entityplayer.world.playSound((EntityPlayer)null, entityplayer.posX, entityplayer.posY, entityplayer.posZ, SoundEvents.ENTITY_ITEM_PICKUP, SoundCategory.PLAYERS, 0.2f, ((entityplayer.getRNG().nextFloat() - entityplayer.getRNG().nextFloat()) * 0.7f + 1.0f) * 2.0f);
            entityplayer.inventoryContainer.detectAndSendChanges();
        }
    }
}

